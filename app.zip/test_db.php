<?php
// Test database connection
require_once 'vendor/autoload.php';

try {
    $pdo = new PDO('mysql:host=127.0.0.1;dbname=saium_shilpigosthi', 'root', '');
    echo "Database connection successful!\n";
    
    // Check if admins table exists and has data
    $stmt = $pdo->query("SELECT COUNT(*) FROM admins");
    $count = $stmt->fetchColumn();
    echo "Number of admins in database: " . $count . "\n";
    
    // Get first admin
    $stmt = $pdo->query("SELECT * FROM admins LIMIT 1");
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($admin) {
        echo "First admin found:\n";
        print_r($admin);
    } else {
        echo "No admins found in database\n";
    }
} catch (Exception $e) {
    echo "Database connection failed: " . $e->getMessage() . "\n";
}