<?php
require_once 'vendor/autoload.php';

// Bootstrap Laravel
$app = require_once 'bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

// Create a subject
$subject = \App\Models\Subject::factory()->create([
    'name' => 'Test Subject',
    'code' => 'TEST001',
    'fee' => 500
]);

$admin = \App\Models\Admin::factory()->create();

$form = \App\Models\Form::create([
    'name' => 'Legacy Desired Subject Form',
    'description' => 'Form with legacy field name',
    'status' => 'active',
    'created_by' => $admin->id,
    'template' => 'legacy_test',
    'fields' => [
        'elements' => [
            [
                'id' => 'element_1',
                'type' => 'text',
                'label' => 'ভর্তিচ্ছু বিষয়/বিভাগ',
                'fieldName' => 'desired_subject_or_department',
                'required' => true,
                'order' => 1,
            ],
        ],
    ],
]);

// Get the form HTML
$response = app('Illuminate\Http\Request');
$response = app(\App\Http\Controllers\FormController::class)->show($form);

echo "Form HTML:\n";
echo $response->getContent();