<?php
// Simple script to verify payment feature is working

require_once 'vendor/autoload.php';

// Bootstrap Laravel
$app = require_once 'bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\Form;
use App\Models\Admin;
use Illuminate\Support\Facades\Config;

// Enable payment feature
Config::set('payment.enabled', true);

// Create admin
$admin = Admin::factory()->create();

// Create a form with payment required and fixed amount
$form = Form::create([
    'name' => 'Test Form with Fixed Payment',
    'description' => 'A test form with fixed payment amount',
    'status' => 'active',
    'created_by' => $admin->id,
    'fields' => [
        'elements' => [
            [
                'id' => 'element_1',
                'type' => 'text',
                'label' => 'Full Name',
                'fieldName' => 'name',
                'required' => true,
                'options' => []
            ],
            [
                'id' => 'element_2',
                'type' => 'text',
                'label' => 'Email',
                'fieldName' => 'email',
                'required' => true,
                'options' => []
            ]
        ],
        'settings' => [
            'paymentRequired' => true,
            'paymentAmount' => 500 // 500 BDT fixed payment
        ]
    ]
]);

echo "Form created successfully!\n";
echo "Form Name: " . $form->name . "\n";
echo "Payment Required: " . ($form->isPaymentRequired() ? 'Yes' : 'No') . "\n";
echo "Payment Amount: " . $form->getPaymentAmount() . " BDT\n";

// Test the form model methods
echo "\nTesting Form Model Methods:\n";
echo "isPaymentRequired(): " . ($form->isPaymentRequired() ? 'true' : 'false') . "\n";
echo "getPaymentAmount(): " . $form->getPaymentAmount() . "\n";

echo "\nPayment feature verification completed successfully!\n";