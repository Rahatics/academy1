<?php
// Test admin user and authentication
require_once 'vendor/autoload.php';

use Illuminate\Database\Capsule\Manager as Capsule;

// Configure database connection
$capsule = new Capsule;
$capsule->addConnection([
    'driver'    => 'mysql',
    'host'      => '127.0.0.1',
    'database'  => 'saium_shilpigosthi',
    'username'  => 'root',
    'password'  => '',
    'charset'   => 'utf8',
    'collation' => 'utf8_unicode_ci',
    'prefix'    => '',
]);

$capsule->setAsGlobal();
$capsule->bootEloquent();

echo "Database connection established.\n";

// Check if admins table exists
try {
    $tables = Capsule::select("SHOW TABLES LIKE 'admins'");
    if (empty($tables)) {
        echo "Admins table does not exist!\n";
        exit;
    }
    echo "Admins table exists.\n";
    
    // Check if there are any admins
    $admins = Capsule::table('admins')->get();
    echo "Number of admins: " . count($admins) . "\n";
    
    if (count($admins) > 0) {
        foreach ($admins as $admin) {
            echo "Admin ID: " . $admin->id . "\n";
            echo "Admin Email: " . $admin->email . "\n";
            echo "Admin Name: " . $admin->name . "\n";
            echo "-------------------\n";
        }
    } else {
        echo "No admins found in the database.\n";
        echo "You need to run: php artisan migrate --seed\n";
    }
} catch (Exception $e) {
    echo "Error querying database: " . $e->getMessage() . "\n";
}