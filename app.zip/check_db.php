<?php
// Simple database connection test
echo "Testing database connection...\n";

// Get database config from .env file
$env = file('.env');
$config = [];
foreach ($env as $line) {
    if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
        list($key, $value) = explode('=', trim($line), 2);
        $config[$key] = trim($value, '"\'');
    }
}

try {
    $dsn = "mysql:host={$config['DB_HOST']};port={$config['DB_PORT']};dbname={$config['DB_DATABASE']}";
    $pdo = new PDO($dsn, $config['DB_USERNAME'], $config['DB_PASSWORD']);
    echo "Database connection successful!\n";
    
    // Try to query admins table
    $stmt = $pdo->query("SELECT COUNT(*) FROM admins");
    $count = $stmt->fetchColumn();
    echo "Found $count admin records in database\n";
    
    if ($count > 0) {
        $stmt = $pdo->query("SELECT * FROM admins LIMIT 1");
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "Sample admin record:\n";
        print_r($admin);
    }
    
} catch (Exception $e) {
    echo "Database connection failed: " . $e->getMessage() . "\n";
}