<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card">
                    <div class="card-header">
                        <h3>Test Login Form</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('admin.login.post') }}">
                            @csrf
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" value="admin@saimum.org" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" value="password123" required>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">Test Login</button>
                        </form>
                        
                        <hr>
                        
                        <h4>Debug Information:</h4>
                        <p><strong>Form Action:</strong> {{ route('admin.login.post') }}</p>
                        <p><strong>CSRF Token:</strong> {{ csrf_token() }}</p>
                        
                        @if (session('error'))
                            <div class="alert alert-danger mt-3">
                                <strong>Error:</strong> {{ session('error') }}
                            </div>
                        @endif
                        
                        @if ($errors->any())
                            <div class="alert alert-danger mt-3">
                                <strong>Validation Errors:</strong>
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>