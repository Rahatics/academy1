<!DOCTYPE html>
<html lang="bn" dir="ltr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>অ্যাডমিন লগইন - সাইমুম শিল্পীগোষ্ঠী</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    
    <!-- Google Fonts - Bengali -->
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #2350c2;
            --primary-hover: #1d45a5;
            --primary-light: #4a90e2;
            --secondary-color: #6c757d;
            --light-color: #f8f9fa;
            --dark-color: #343a40;
            --border-color: #e9ecef;
            --body-bg: #f5f6fa;
            --card-bg: #ffffff;
            --text-color: #212529; /* Improved contrast */
            --text-muted: #6c757d;
        }
        
        :root.dark-mode {
            --body-bg: #0f172a;
            --card-bg: #1e293b;
            --text-color: #f1f5f9; /* Improved contrast */
            --text-muted: #94a3b8;
            --border-color: #334155;
        }
        
        body {
            font-family: 'Hind Siliguri', sans-serif;
            background: linear-gradient(135deg, var(--primary-color), var(--primary-light));
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            padding: 1rem;
            transition: background 0.5s ease;
            color: var(--text-color);
        }
        
        :root.dark-mode body {
            background: linear-gradient(135deg, #1e3a8a, #2350c2);
        }
        
        .login-container {
            width: 100%;
            max-width: 400px;
        }
        
        .login-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
            overflow: hidden;
            background: var(--card-bg);
            transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            transform: translateY(0);
        }
        
        .login-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 30px 60px rgba(0, 0, 0, 0.3);
        }
        
        .login-header {
            background: linear-gradient(90deg, var(--primary-color), var(--primary-light));
            color: white;
            text-align: center;
            padding: 2rem 1rem;
            position: relative;
            overflow: hidden;
        }
        
        .login-header::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 70%);
            transform: rotate(30deg);
        }
        
        .login-header h3 {
            margin: 0;
            font-weight: 700;
            position: relative;
            z-index: 2;
        }
        
        .login-body {
            padding: 2rem;
            background: var(--card-bg);
        }
        
        .form-control, .form-select {
            border-radius: 10px;
            padding: 0.75rem 1rem;
            border: 2px solid var(--border-color);
            transition: all 0.3s ease;
            background: var(--card-bg);
            color: var(--text-color);
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(35, 80, 194, 0.25);
        }
        
        .input-group-text {
            background: rgba(35, 80, 194, 0.1);
            border: 2px solid var(--border-color);
            border-right: none;
            border-radius: 10px 0 0 10px;
            color: var(--primary-color);
            transition: all 0.3s ease;
        }
        
        :root.dark-mode .input-group-text {
            background: rgba(35, 80, 194, 0.2);
        }
        
        .form-control:focus ~ .input-group-text {
            border-color: var(--primary-color);
            background: rgba(35, 80, 194, 0.2);
        }
        
        .btn-primary {
            background: var(--primary-color);
            border-color: var(--primary-color);
            border-radius: 10px;
            padding: 0.75rem;
            font-weight: 600;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(35, 80, 194, 0.3);
            color: white;
        }
        
        .btn-primary::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s;
        }
        
        .btn-primary:hover {
            background: var(--primary-hover);
            border-color: var(--primary-hover);
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(35, 80, 194, 0.4);
        }
        
        .btn-primary:hover::before {
            left: 100%;
        }
        
        .btn-primary:active {
            transform: translateY(-1px);
        }
        
        .form-check-input:checked {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .alert {
            border-radius: 10px;
            animation: slideIn 0.5s ease;
        }
        
        .alert-danger {
            background: linear-gradient(90deg, #f8d7da, #f1b0b7);
            border: none;
            color: #721c24;
        }
        
        .logo-img {
            height: 50px;
            margin-bottom: 1rem;
            filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.2));
            transition: transform 0.3s ease;
        }
        
        .logo-img:hover {
            transform: scale(1.1);
        }
        
        /* Theme Toggle */
        .theme-toggle {
            position: absolute;
            top: 15px;
            right: 15px;
            background: rgba(255, 255, 255, 0.2);
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            color: white;
            cursor: pointer;
            transition: all 0.3s ease;
            z-index: 10;
        }
        
        .theme-toggle:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: rotate(30deg);
        }
        
        /* Animations */
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .fade-in {
            animation: fadeIn 0.8s ease forwards;
        }
        
        .slide-in {
            animation: slideIn 0.6s ease forwards;
        }
        
        .slide-in:nth-child(1) { animation-delay: 0.1s; }
        .slide-in:nth-child(2) { animation-delay: 0.2s; }
        .slide-in:nth-child(3) { animation-delay: 0.3s; }
        .slide-in:nth-child(4) { animation-delay: 0.4s; }
        
        /* Loading spinner */
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .bx-spin {
            animation: spin 1s linear infinite;
        }
        
        /* Smooth cursor effect */
        * {
            cursor: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4" fill="rgba(35, 80, 194, 0.5)"/></svg>') 12 12, auto;
        }
        
        button, .btn, .theme-toggle {
            cursor: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><circle cx="12" cy="12" r="6" fill="rgba(35, 80, 194, 0.8)"/></svg>') 12 12, pointer;
        }
        
        /* Text contrast improvements */
        .text-muted {
            color: var(--text-muted) !important;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-card fade-in">
            <div class="login-header">
                <button class="theme-toggle" id="themeToggle">
                    <i class='bx bx-sun' id="themeIcon"></i>
                </button>
                @if(file_exists(public_path('images/logo.png')))
                    <img src="{{ asset('images/logo.png') }}" alt="Logo" class="logo-img">
                @endif
                <h3>সাইমুম শিল্পীগোষ্ঠী</h3>
                <p class="mb-0">অ্যাডমিন প্যানেল</p>
            </div>
            <div class="login-body">
                @if ($errors->any())
                    <div class="alert alert-danger slide-in">
                        <ul class="mb-0">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif
                
                <form method="POST" action="{{ route('admin.login.post') }}" id="loginForm">
                    @csrf
                    <div class="mb-3 slide-in">
                        <label for="email" class="form-label">ইমেইল</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class='bx bx-envelope'></i>
                            </span>
                            <input type="email" class="form-control" id="email" name="email" value="{{ old('email', 'admin@saimum.org') }}" placeholder="আপনার ইমেইল" required>
                        </div>
                    </div>
                    
                    <div class="mb-3 slide-in">
                        <label for="password" class="form-label">পাসওয়ার্ড</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class='bx bx-lock-alt'></i>
                            </span>
                            <input type="password" class="form-control" id="password" name="password" value="password123" placeholder="আপনার পাসওয়ার্ড" required>
                        </div>
                    </div>
                    
                    <div class="mb-3 form-check slide-in">
                        <input type="checkbox" class="form-check-input" id="remember" name="remember">
                        <label class="form-check-label" for="remember">আমাকে মনে রাখুন</label>
                    </div>
                    
                    <div class="d-grid slide-in">
                        <button type="submit" class="btn btn-primary" id="loginButton">
                            <i class='bx bx-log-in-circle me-1'></i>লগইন
                        </button>
                    </div>
                </form>
                
                <div class="text-center mt-3 slide-in">
                    <small class="text-muted">
                        ডিফল্ট ক্রেডেনশিয়ালস:<br>
                        ইমেইল: admin@saimum.org<br>
                        পাসওয়ার্ড: password123
                    </small>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Theme toggle
        function toggleTheme() {
            const root = document.documentElement;
            const isDark = root.classList.contains('dark-mode');
            
            if (isDark) {
                root.classList.remove('dark-mode');
                localStorage.setItem('theme', 'light');
                document.getElementById('themeIcon').className = 'bx bx-sun';
            } else {
                root.classList.add('dark-mode');
                localStorage.setItem('theme', 'dark');
                document.getElementById('themeIcon').className = 'bx bx-moon';
            }
            
            // Add animation
            const themeToggle = document.getElementById('themeToggle');
            themeToggle.style.transform = 'rotate(360deg)';
            setTimeout(() => {
                themeToggle.style.transform = '';
            }, 300);
        }
        
        // Load saved theme
        document.addEventListener('DOMContentLoaded', function() {
            const savedTheme = localStorage.getItem('theme');
            const root = document.documentElement;
            
            if (savedTheme === 'dark') {
                root.classList.add('dark-mode');
                document.getElementById('themeIcon').className = 'bx bx-moon';
            } else {
                root.classList.remove('dark-mode');
                document.getElementById('themeIcon').className = 'bx bx-sun';
            }
        });
        
        // Add event listener to theme toggle
        document.addEventListener('DOMContentLoaded', function() {
            const themeToggle = document.getElementById('themeToggle');
            if (themeToggle) {
                themeToggle.addEventListener('click', toggleTheme);
            }
        });
        
        // Form submission with loading state
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('loginForm');
            const button = document.getElementById('loginButton');
            
            form.addEventListener('submit', function(e) {
                // Change button text to show loading
                button.innerHTML = '<i class="bx bx-loader-alt bx-spin me-1"></i>লগইন হচ্ছে...';
                button.disabled = true;
                
                // Add subtle animation to button
                button.style.transform = 'scale(0.98)';
                setTimeout(() => {
                    button.style.transform = '';
                }, 100);
            });
        });
        
        // Add smooth hover effects to form elements
        document.addEventListener('DOMContentLoaded', function() {
            const inputs = document.querySelectorAll('.form-control, .form-select');
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.parentElement.parentElement.style.transform = 'translateY(-2px)';
                });
                
                input.addEventListener('blur', function() {
                    this.parentElement.parentElement.style.transform = '';
                });
            });
        });
    </script>
</body>
</html>