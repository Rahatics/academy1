@extends('admin.layouts.app')

@section('title', 'নতুন ফর্ম - অ্যাডমিন প্যানেল')

@section('content')
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex align-items-center mb-4 fade-in">
        <h4 class="mb-0">নতুন ফর্ম</h4>
        <div class="ms-auto">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">হোম</a></li>
                <li class="breadcrumb-item"><a href="{{ route('admin.forms.index') }}">ফর্মসমূহ</a></li>
                <li class="breadcrumb-item active" aria-current="page">নতুন ফর্ম</li>
            </ol>
        </div>
    </div>

    <div class="row">
        <div class="col-12 fade-in">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">ফর্ম তৈরি করুন</h5>
                </div>
                <div class="card-body">
                    @if($errors->any())
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <ul class="mb-0">
                                @foreach($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    @endif

                    <form action="{{ route('admin.forms.store') }}" method="POST">
                        @csrf
                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <label for="name" class="form-label">ফর্মের নাম *</label>
                                <input type="text" class="form-control" id="name" name="name" value="{{ old('name') }}" required>
                            </div>
                            
                            <div class="col-md-12 mb-3">
                                <label for="description" class="form-label">বর্ণনা</label>
                                <textarea class="form-control" id="description" name="description" rows="4">{{ old('description') }}</textarea>
                            </div>
                            
                            <div class="col-md-12 mb-3">
                                <label for="status" class="form-label">স্ট্যাটাস *</label>
                                <select class="form-select" id="status" name="status" required>
                                    <option value="active" {{ old('status') == 'active' ? 'selected' : '' }}>সক্রিয়</option>
                                    <option value="inactive" {{ old('status') == 'inactive' ? 'selected' : '' }}>নিষ্ক্রিয়</option>
                                </select>
                            </div>
                            
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary">
                                    <i class='bx bx-save me-1'></i>সংরক্ষণ করুন
                                </button>
                                <a href="{{ route('admin.forms.index') }}" class="btn btn-secondary">
                                    <i class='bx bx-arrow-back me-1'></i>বাতিল করুন
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Add specific animations for forms elements */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .fade-in {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    .fade-in:nth-child(1) { animation-delay: 0.1s; }
    .fade-in:nth-child(2) { animation-delay: 0.2s; }
    .fade-in:nth-child(3) { animation-delay: 0.3s; }
    .fade-in:nth-child(4) { animation-delay: 0.4s; }
    
    /* Dark mode fixes for form elements */
    :root.dark-mode .form-control,
    :root.dark-mode .form-select {
        background-color: #1e293b !important;
        color: #f1f5f9 !important;
        border-color: #334155 !important;
    }
    
    :root.dark-mode .form-label {
        color: #f1f5f9 !important;
    }
    
    :root.dark-mode .form-control::placeholder {
        color: #94a3b8 !important;
    }
</style>
@endsection