@extends('admin.layouts.app')

@section('title', 'ফর্ম দেখুন - অ্যাডমিন প্যানেল')

@section('content')
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex align-items-center mb-4 fade-in">
        <h4 class="mb-0">ফর্ম দেখুন</h4>
        <div class="ms-auto">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">হোম</a></li>
                <li class="breadcrumb-item"><a href="{{ route('admin.forms.index') }}">ফর্মসমূহ</a></li>
                <li class="breadcrumb-item active" aria-current="page">ফর্ম দেখুন</li>
            </ol>
        </div>
    </div>

    <div class="row">
        <div class="col-12 fade-in">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">{{ $form->name }}</h5>
                    <div>
                        <a href="{{ route('admin.forms.edit', $form) }}" class="btn btn-warning btn-sm">
                            <i class='bx bx-edit me-1'></i>সম্পাদনা
                        </a>
                        <form action="{{ route('admin.forms.destroy', $form) }}" method="POST" class="d-inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('আপনি কি নিশ্চিত যে আপনি এই ফর্মটি মুছে ফেলতে চান?')">
                                <i class='bx bx-trash me-1'></i>মুছুন
                            </button>
                        </form>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 fade-in">
                            <table class="table table-borderless">
                                <tr>
                                    <th width="20%">নাম:</th>
                                    <td>{{ $form->name }}</td>
                                </tr>
                                <tr>
                                    <th>বর্ণনা:</th>
                                    <td>{{ $form->description ?? 'নেই' }}</td>
                                </tr>
                                <tr>
                                    <th>স্ট্যাটাস:</th>
                                    <td>
                                        @if($form->status == 'active')
                                            <span class="badge bg-success">সক্রিয়</span>
                                        @else
                                            <span class="badge bg-secondary">নিষ্ক্রিয়</span>
                                        @endif
                                    </td>
                                </tr>
                                <tr>
                                    <th>তৈরিকারক:</th>
                                    <td>{{ $form->admin->name ?? 'অজানা' }}</td>
                                </tr>
                                <tr>
                                    <th>তৈরির তারিখ:</th>
                                    <td>{{ $form->created_at->format('d/m/Y H:i:s') }}</td>
                                </tr>
                                <tr>
                                    <th>আপডেটের তারিখ:</th>
                                    <td>{{ $form->updated_at->format('d/m/Y H:i:s') }}</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    
                    <div class="row mt-4">
                        <div class="col-12 fade-in">
                            <div class="card bg-light">
                                <div class="card-header">
                                    <h5 class="mb-0">ফর্ম ফিল্ডসমূহ</h5>
                                </div>
                                <div class="card-body">
                                    @if($form->fields)
                                        <pre>{{ json_encode($form->fields, JSON_PRETTY_PRINT) }}</pre>
                                    @else
                                        <p class="text-muted">এখনও কোন ফিল্ড যুক্ত করা হয়নি।</p>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Add specific animations for forms elements */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .fade-in {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    .fade-in:nth-child(1) { animation-delay: 0.1s; }
    .fade-in:nth-child(2) { animation-delay: 0.2s; }
    .fade-in:nth-child(3) { animation-delay: 0.3s; }
    .fade-in:nth-child(4) { animation-delay: 0.4s; }
    .fade-in:nth-child(5) { animation-delay: 0.5s; }
    .fade-in:nth-child(6) { animation-delay: 0.6s; }
    
    /* Card hover effect */
    .card {
        transition: all 0.3s ease;
    }
    
    .card:hover {
        transform: translateY(-3px);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
    }
    
    /* Table styling */
    .table-borderless th {
        font-weight: 600;
        color: var(--text-color);
    }
    
    .table-borderless td {
        color: var(--text-muted);
    }
    
    /* Dark mode fixes */
    :root.dark-mode .table-borderless th {
        color: #f1f5f9 !important;
    }
    
    :root.dark-mode .table-borderless td {
        color: #94a3b8 !important;
    }
    
    :root.dark-mode .card.bg-light {
        background-color: #1e293b !important;
    }
</style>
@endsection