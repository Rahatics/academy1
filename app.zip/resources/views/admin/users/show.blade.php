@extends('admin.layouts.app')

@section('title', 'ইউজার বিস্তারিত - অ্যাডমিন প্যানেল')

@section('content')
<div class="container-fluid">
    <!-- Modern Page Header -->
    <div class="d-flex align-items-center justify-content-between mb-4 fade-in py-3 px-4 rounded page-header shadow-sm" style="background-color: var(--card-bg); border: 1px solid var(--border-color);">
        <div>
            <h4 class="mb-1 fw-bold" style="color: var(--text-color);">ইউজার বিস্তারিত</h4>
            <p class="mb-0 small" style="color: var(--text-muted);">ইউজারের সম্পূর্ণ তথ্য</p>
        </div>
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 bg-transparent p-0">
                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}" class="text-decoration-none" style="color: var(--primary-color);">হোম</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('admin.users.index') }}" class="text-decoration-none" style="color: var(--primary-color);">ইউজার ম্যানেজমেন্ট</a></li>
                    <li class="breadcrumb-item active" style="color: var(--text-muted);" aria-current="page">ইউজার বিস্তারিত</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="row">
        <div class="col-12 fade-in">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4">
                    <!-- User Profile Header -->
                    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4 pb-4" style="border-bottom: 1px solid var(--border-color);">
                        <div class="d-flex align-items-center mb-4 mb-md-0">
                            <div class="avatar avatar-xl bg-primary bg-opacity-10 text-primary rounded-circle me-4">
                                <i class='bx bx-user fs-1'></i>
                            </div>
                            <div>
                                <h5 class="mb-1 fw-bold text-dark">{{ $user->name }}</h5>
                                <p class="text-muted mb-2">{{ $user->email }}</p>
                                <span class="badge {{ $user->email_verified_at ? 'bg-success bg-opacity-10 text-success' : 'bg-warning bg-opacity-10 text-warning' }} px-3 py-2 rounded-pill">
                                    @if($user->email_verified_at)
                                        <i class='bx bx-check-circle me-1'></i>Verified
                                    @else
                                        <i class='bx bx-time me-1'></i>Pending
                                    @endif
                                </span>
                            </div>
                        </div>
                        <div class="d-flex gap-2">
                            <a href="{{ route('admin.users.edit', $user) }}" class="btn btn-warning btn-sm d-flex align-items-center">
                                <i class='bx bx-edit me-1'></i>সম্পাদনা
                            </a>
                            <button class="btn btn-danger btn-sm d-flex align-items-center delete-user-btn" 
                                    data-id="{{ $user->id }}" 
                                    data-name="{{ $user->name }}">
                                <i class='bx bx-trash me-1'></i>মুছুন
                            </button>
                        </div>
                    </div>
                    
                    <!-- User Details Grid -->
                    <div class="row g-4">
                        <div class="col-lg-6">
                            <div class="card border-0 shadow-sm h-100" style="background-color: var(--card-bg);">
                                <div class="card-body">
                                    <h6 class="card-title fw-bold mb-4" style="color: var(--text-color);">
                                        <i class='bx bx-user-circle text-primary me-2'></i>পার্সোনাল তথ্য
                                    </h6>
                                    <div class="row g-3">
                                        <div class="col-sm-4">
                                            <p class="text-muted mb-1 small">নাম:</p>
                                        </div>
                                        <div class="col-sm-8">
                                            <p class="mb-1 fw-medium">{{ $user->name }}</p>
                                        </div>
                                        
                                        <div class="col-sm-4">
                                            <p class="text-muted mb-1 small">ইমেইল:</p>
                                        </div>
                                        <div class="col-sm-8">
                                            <p class="mb-1 fw-medium">{{ $user->email }}</p>
                                        </div>
                                        
                                        <div class="col-sm-4">
                                            <p class="text-muted mb-1 small">ইউজার আইডি:</p>
                                        </div>
                                        <div class="col-sm-8">
                                            <p class="mb-1 fw-medium">#{{ $user->id }}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-lg-6">
                            <div class="card border-0 shadow-sm h-100" style="background-color: var(--card-bg);">
                                <div class="card-body">
                                    <h6 class="card-title fw-bold mb-4" style="color: var(--text-color);">
                                        <i class='bx bx-time text-primary me-2'></i>অ্যাকাউন্ট তথ্য
                                    </h6>
                                    <div class="row g-3">
                                        <div class="col-sm-5">
                                            <p class="text-muted mb-1 small">রেজিস্টারেশন:</p>
                                        </div>
                                        <div class="col-sm-7">
                                            <p class="mb-1 fw-medium">{{ $user->created_at->format('d M, Y') }}</p>
                                            <p class="text-muted small mb-0">{{ $user->created_at->format('h:i A') }}</p>
                                        </div>
                                        
                                        <div class="col-sm-5">
                                            <p class="text-muted mb-1 small">শেষ আপডেট:</p>
                                        </div>
                                        <div class="col-sm-7">
                                            <p class="mb-1 fw-medium">{{ $user->updated_at->format('d M, Y') }}</p>
                                            <p class="text-muted small mb-0">{{ $user->updated_at->format('h:i A') }}</p>
                                        </div>
                                        
                                        @if($user->email_verified_at)
                                        <div class="col-sm-5">
                                            <p class="text-muted mb-1 small">ভেরিফিকেশন:</p>
                                        </div>
                                        <div class="col-sm-7">
                                            <p class="mb-1 fw-medium">{{ $user->email_verified_at->format('d M, Y') }}</p>
                                            <p class="text-muted small mb-0">{{ $user->email_verified_at->format('h:i A') }}</p>
                                        </div>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-lg-12">
                            <div class="card border-0 shadow-sm" style="background-color: var(--card-bg);">
                                <div class="card-body">
                                    <h6 class="card-title fw-bold mb-4" style="color: var(--text-color);">
                                        <i class='bx bx-bar-chart-alt text-primary me-2'></i>ইউজার অ্যাক্টিভিটি
                                    </h6>
                                    <div class="row g-3">
                                        <div class="col-md-3 col-6">
                                            <div class="text-center p-3 bg-white rounded shadow-sm">
                                                <div class="avatar avatar-md bg-primary bg-opacity-10 text-primary rounded-circle mx-auto mb-2">
                                                    <i class='bx bx-log-in fs-4'></i>
                                                </div>
                                                <h6 class="mb-0 fw-bold text-dark">12</h6>
                                                <p class="text-muted mb-0 small">লগইন</p>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-6">
                                            <div class="text-center p-3 bg-white rounded shadow-sm">
                                                <div class="avatar avatar-md bg-success bg-opacity-10 text-success rounded-circle mx-auto mb-2">
                                                    <i class='bx bx-file fs-4'></i>
                                                </div>
                                                <h6 class="mb-0 fw-bold text-dark">3</h6>
                                                <p class="text-muted mb-0 small">আবেদন</p>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-6">
                                            <div class="text-center p-3 bg-white rounded shadow-sm">
                                                <div class="avatar avatar-md bg-warning bg-opacity-10 text-warning rounded-circle mx-auto mb-2">
                                                    <i class='bx bx-credit-card fs-4'></i>
                                                </div>
                                                <h6 class="mb-0 fw-bold text-dark">1</h6>
                                                <p class="text-muted mb-0 small">পেমেন্ট</p>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-6">
                                            <div class="text-center p-3 bg-white rounded shadow-sm">
                                                <div class="avatar avatar-md bg-info bg-opacity-10 text-info rounded-circle mx-auto mb-2">
                                                    <i class='bx bx-calendar fs-4'></i>
                                                </div>
                                                <h6 class="mb-0 fw-bold text-dark">7</h6>
                                                <p class="text-muted mb-0 small">দিন আগে</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="d-flex justify-content-between">
                <a href="{{ route('admin.users.index') }}" class="btn btn-outline-secondary">
                    <i class='bx bx-arrow-back me-1'></i>ইউজার তালিকায় ফিরে যান
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Modern Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold text-dark">ইউজার মুছে ফেলুন</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body py-3">
                <div class="d-flex align-items-center mb-3">
                    <div class="avatar avatar-lg bg-danger bg-opacity-10 text-danger rounded-circle me-3">
                        <i class='bx bx-error fs-4'></i>
                    </div>
                    <div>
                        <p class="mb-0">আপনি কি নিশ্চিত যে আপনি <strong id="deleteUserName"></strong> নামের ইউজারটি মুছে ফেলতে চান?</p>
                        <p class="text-muted mb-0 small">এই ক্রিয়াটি পূর্বাবস্থায় ফেরানো যাবে না।</p>
                    </div>
                </div>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">বাতিল</button>
                <button type="button" class="btn btn-danger" id="confirmDeleteBtn">মুছে ফেলুন</button>
            </div>
        </div>
    </div>
</div>

<style>
    /* Modern Card Styling */
    .card {
        border-radius: 16px;
        overflow: hidden;
    }
    
    .card-header {
        border-bottom: 1px solid #e9ecef;
    }
    
    /* Modern Avatar */
    .avatar {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .avatar-sm {
        width: 36px;
        height: 36px;
        font-size: 0.875rem;
    }
    
    .avatar-md {
        width: 50px;
        height: 50px;
        font-size: 1.25rem;
    }
    
    .avatar-xl {
        width: 100px;
        height: 100px;
        font-size: 2.5rem;
    }
    
    /* Modern Badges */
    .badge {
        font-weight: 500;
        padding: 0.5em 1em;
    }
    
    /* Modern Buttons */
    .btn {
        border-radius: 10px;
        padding: 0.6rem 1.25rem;
        font-weight: 500;
        transition: all 0.3s ease;
    }
    
    .btn-sm {
        padding: 0.375rem 0.75rem;
        font-size: 0.875rem;
    }
    
    .btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    
    /* Modern Breadcrumb */
    .breadcrumb-item + .breadcrumb-item::before {
        content: ">";
        color: #adb5bd;
    }
    
    /* Modern Animations */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .fade-in {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    /* Dark Mode Support */
    :root.dark-mode .card {
        background-color: #1e293b;
        border-color: #334155;
    }
    
    :root.dark-mode .card-header {
        background-color: #1e293b;
        border-color: #334155;
    }
    
    :root.dark-mode .bg-light-subtle {
        background-color: #334155 !important;
    }
    
    :root.dark-mode .text-dark {
        color: #f1f5f9 !important;
    }
    
    :root.dark-mode .text-muted {
        color: #94a3b8 !important;
    }
    
    :root.dark-mode .border-bottom {
        border-color: #334155 !important;
    }
    
    :root.dark-mode .page-header {
        background-color: #1e293b;
    }
    
    :root.dark-mode .breadcrumb-item a {
        color: #93c5fd;
    }
    
    :root.dark-mode .breadcrumb-item.active {
        color: #cbd5e1;
    }
    
    :root.dark-mode .btn-close {
        filter: invert(1) grayscale(100%) brightness(200%);
    }
    
    :root.dark-mode .modal-content {
        background-color: #1e293b;
    }
    
    :root.dark-mode .modal-header {
        border-color: #334155;
    }
    
    :root.dark-mode .modal-footer {
        border-color: #334155;
    }
    
    .fw-medium {
        font-weight: 500;
    }
    
    :root.dark-mode .fw-medium {
        color: #f1f5f9;
    }
    
    :root.dark-mode .table td, 
    :root.dark-mode .table th {
        color: #f1f5f9;
    }
    
    :root.dark-mode .form-check-input {
        background-color: #1e293b;
        border-color: #334155;
    }
    
    :root.dark-mode .form-check-input:checked {
        background-color: #3b82f6;
        border-color: #3b82f6;
    }
    
    :root.dark-mode .card .bg-white {
        background-color: #334155 !important;
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Delete user functionality
        const deleteButtons = document.querySelectorAll('.delete-user-btn');
        const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
        let currentUserId = null;
        
        deleteButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                
                currentUserId = this.getAttribute('data-id');
                const userName = this.getAttribute('data-name');
                
                // Set user name in modal
                document.getElementById('deleteUserName').textContent = userName;
                
                // Show delete confirmation modal
                deleteModal.show();
            });
        });
        
        // Confirm delete button in modal
        document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
            if (!currentUserId) return;
            
            // Create a form dynamically and submit it
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = `/admin/users/${currentUserId}`;
            
            const methodInput = document.createElement('input');
            methodInput.type = 'hidden';
            methodInput.name = '_method';
            methodInput.value = 'DELETE';
            
            const tokenInput = document.createElement('input');
            tokenInput.type = 'hidden';
            tokenInput.name = '_token';
            tokenInput.value = '{{ csrf_token() }}';
            
            form.appendChild(methodInput);
            form.appendChild(tokenInput);
            document.body.appendChild(form);
            form.submit();
        });
    });
</script>
@endsection