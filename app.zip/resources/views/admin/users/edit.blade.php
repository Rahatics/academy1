@extends('admin.layouts.app')

@section('title', 'ইউজার সম্পাদনা - অ্যাডমিন প্যানেল')

@section('content')
<div class="container-fluid">
    <!-- Modern Page Header -->
    <div class="d-flex align-items-center justify-content-between mb-4 fade-in py-3 px-4 rounded page-header shadow-sm" style="background-color: var(--card-bg); border: 1px solid var(--border-color);">
        <div>
            <h4 class="mb-1 fw-bold" style="color: var(--text-color);">ইউজার সম্পাদনা</h4>
            <p class="mb-0 small" style="color: var(--text-muted);">ইউজারের তথ্য সম্পাদনা করুন</p>
        </div>
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 bg-transparent p-0">
                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}" class="text-decoration-none" style="color: var(--primary-color);">হোম</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('admin.users.index') }}" class="text-decoration-none" style="color: var(--primary-color);">ইউজার ম্যানেজমেন্ট</a></li>
                    <li class="breadcrumb-item active" style="color: var(--text-muted);" aria-current="page">ইউজার সম্পাদনা</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="row">
        <div class="col-12 fade-in">
            <div class="card border-0 shadow-sm">
                <div class="card-header border-0 py-3 px-4" style="background-color: var(--card-bg); border-bottom: 1px solid var(--border-color);">
                    <h5 class="mb-0 fw-bold" style="color: var(--text-color);">ইউজারের তথ্য</h5>
                    <p class="mb-0 small" style="color: var(--text-muted);">ইউজারের তথ্য সম্পাদনা করুন</p>
                </div>
                <div class="card-body p-4">
                    <form action="{{ route('admin.users.update', $user) }}" method="POST" class="row">
                        @csrf
                        @method('PUT')
                        
                        <div class="col-lg-8">
                            <div class="row">
                                <div class="col-md-12 mb-4">
                                    <label class="form-label fw-medium text-dark">নাম <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-white border-end-0">
                                            <i class='bx bx-user text-muted'></i>
                                        </span>
                                        <input type="text" class="form-control border-start-0 @error('name') is-invalid @enderror" name="name" value="{{ old('name', $user->name) }}" placeholder="ইউজারের নাম লিখুন" required>
                                    </div>
                                    @error('name')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                
                                <div class="col-md-12 mb-4">
                                    <label class="form-label fw-medium text-dark">ইমেইল <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-white border-end-0">
                                            <i class='bx bx-envelope text-muted'></i>
                                        </span>
                                        <input type="email" class="form-control border-start-0 @error('email') is-invalid @enderror" name="email" value="{{ old('email', $user->email) }}" placeholder="ইউজারের ইমেইল লিখুন" required>
                                    </div>
                                    @error('email')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                
                                <div class="col-md-12 mb-4">
                                    <label class="form-label fw-medium text-dark">পাসওয়ার্ড</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-white border-end-0">
                                            <i class='bx bx-lock text-muted'></i>
                                        </span>
                                        <input type="password" class="form-control border-start-0" name="password" placeholder="নতুন পাসওয়ার্ড লিখুন (ঐচ্ছিক)">
                                    </div>
                                    <div class="form-text text-muted">পাসওয়ার্ড পরিবর্তন করতে চাইলে নতুন পাসওয়ার্ড লিখুন</div>
                                </div>
                                
                                <div class="col-md-12 mb-4">
                                    <label class="form-label fw-medium text-dark">পাসওয়ার্ড নিশ্চিত করুন</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-white border-end-0">
                                            <i class='bx bx-lock text-muted'></i>
                                        </span>
                                        <input type="password" class="form-control border-start-0" name="password_confirmation" placeholder="পাসওয়ার্ড পুনরায় লিখুন">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-lg-4">
                            <div class="card border-0 bg-light-subtle shadow-sm">
                                <div class="card-body">
                                    <h6 class="card-title fw-bold text-dark mb-3">ইউজার প্রোফাইল</h6>
                                    <div class="text-center mb-4">
                                        <div class="avatar avatar-xl bg-primary bg-opacity-10 text-primary rounded-circle mx-auto mb-3">
                                            <i class='bx bx-user fs-1'></i>
                                        </div>
                                        <p class="text-muted small mb-0">ইউজারের প্রোফাইল ছবি</p>
                                        <p class="text-muted small">সুপারিশকৃত সাইজ: 200x200 পিক্সেল</p>
                                    </div>
                                    
                                    <div class="alert alert-warning d-flex align-items-center" role="alert">
                                        <i class='bx bx-error-circle me-2'></i>
                                        <div>
                                            <h6 class="alert-heading fw-bold mb-1">গুরুত্বপূর্ণ তথ্য</h6>
                                            <p class="mb-0 small">ইউজারের তথ্য সম্পাদনা করুন। ইমেইল পরিবর্তন করলে নিশ্চিত করুন যে এটি অন্য কোন ইউজার ব্যবহার করছে না।</p>
                                        </div>
                                    </div>
                                    
                                    <div class="d-grid gap-2 mt-3">
                                        <button type="button" class="btn btn-outline-danger">
                                            <i class='bx bx-trash me-1'></i>ইউজার মুছে ফেলুন
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-12 mt-4">
                            <div class="d-flex justify-content-between">
                                <a href="{{ route('admin.users.index') }}" class="btn btn-outline-secondary">
                                    <i class='bx bx-arrow-back me-1'></i>বাতিল
                                </a>
                                <button type="submit" class="btn btn-primary">
                                    <i class='bx bx-save me-1'></i>আপডেট করুন
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Modern Form Styling */
    .form-control, .form-select {
        border-radius: 10px;
        padding: 0.75rem 1rem;
        border: 1px solid #e9ecef;
        transition: all 0.3s ease;
    }
    
    .form-control:focus, .form-select:focus {
        border-color: #4a90e2;
        box-shadow: 0 0 0 0.25rem rgba(74, 144, 226, 0.15);
    }
    
    .input-group-text {
        border-radius: 10px 0 0 10px;
        border: 1px solid #e9ecef;
        background-color: #f8f9fa;
    }
    
    .form-label {
        margin-bottom: 0.5rem;
        font-weight: 500;
    }
    
    /* Modern Card Styling */
    .card {
        border-radius: 16px;
        overflow: hidden;
    }
    
    .card-header {
        border-bottom: 1px solid #e9ecef;
    }
    
    /* Modern Avatar */
    .avatar {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .avatar-xl {
        width: 100px;
        height: 100px;
        font-size: 2.5rem;
    }
    
    /* Modern Alert */
    .alert {
        border-radius: 10px;
        border: none;
    }
    
    /* Modern Buttons */
    .btn {
        border-radius: 10px;
        padding: 0.6rem 1.25rem;
        font-weight: 500;
        transition: all 0.3s ease;
    }
    
    .btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    
    /* Modern Breadcrumb */
    .breadcrumb-item + .breadcrumb-item::before {
        content: ">";
        color: #adb5bd;
    }
    
    /* Dark Mode Support */
    :root.dark-mode .card {
        background-color: #1e293b;
        border-color: #334155;
    }
    
    :root.dark-mode .card-header {
        background-color: #1e293b;
        border-color: #334155;
    }
    
    :root.dark-mode .form-control, 
    :root.dark-mode .form-select,
    :root.dark-mode .input-group-text {
        background-color: #1e293b;
        border-color: #334155;
        color: #f1f5f9;
    }
    
    :root.dark-mode .form-control:focus, 
    :root.dark-mode .form-select:focus {
        border-color: #3b82f6;
        box-shadow: 0 0 0 0.25rem rgba(59, 130, 246, 0.15);
    }
    
    :root.dark-mode .input-group-text {
        background-color: #334155;
    }
    
    :root.dark-mode .bg-white {
        background-color: #1e293b !important;
    }
    
    :root.dark-mode .text-dark {
        color: #f1f5f9 !important;
    }
    
    :root.dark-mode .text-muted {
        color: #94a3b8 !important;
    }
    
    :root.dark-mode .border-bottom {
        border-color: #334155 !important;
    }
    
    :root.dark-mode .page-header {
        background-color: #1e293b;
    }
    
    :root.dark-mode .breadcrumb-item a {
        color: #93c5fd;
    }
    
    :root.dark-mode .breadcrumb-item.active {
        color: #cbd5e1;
    }
    
    :root.dark-mode .alert-warning {
        background-color: #f59e0b;
        border-color: #f59e0b;
        color: #0f172a;
    }
    
    :root.dark-mode .btn-close {
        filter: invert(1) grayscale(100%) brightness(200%);
    }
    
    :root.dark-mode .form-label {
        color: #f1f5f9;
    }
    
    :root.dark-mode .form-check-input {
        background-color: #1e293b;
        border-color: #334155;
    }
    
    :root.dark-mode .form-check-input:checked {
        background-color: #3b82f6;
        border-color: #3b82f6;
    }
</style>
@endsection