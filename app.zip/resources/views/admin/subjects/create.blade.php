@extends('admin.layouts.app')

@section('title', 'নতুন বিষয় - সাইমুম শিল্পীগোষ্ঠী')

@section('content')
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex align-items-center mb-4 fade-in">
        <div>
            <h4 class="mb-1">নতুন বিষয়</h4>
            <p class="mb-0 text-muted">একটি নতুন বিষয় তৈরি করুন</p>
        </div>
        <div class="ms-auto d-flex align-items-center">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">হোম</a></li>
                <li class="breadcrumb-item"><a href="{{ route('admin.subjects.index') }}">বিষয়সমূহ</a></li>
                <li class="breadcrumb-item active" aria-current="page">নতুন বিষয়</li>
            </ol>
        </div>
    </div>

    <div class="row">
        <div class="col-12 fade-in">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">বিষয়ের তথ্য</h5>
                </div>
                <div class="card-body">
                    @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            {{ session('success') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    @endif

                    @if($errors->any())
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <ul class="mb-0">
                                @foreach($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    @endif

                    <form action="{{ route('admin.subjects.store') }}" method="POST">
                        @csrf
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="name" class="form-label">বিষয়ের নাম <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="name" name="name" value="{{ old('name') }}" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="code" class="form-label">বিষয় কোড <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="code" name="code" value="{{ old('code') }}" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">বর্ণনা</label>
                            <textarea class="form-control" id="description" name="description" rows="4">{{ old('description') }}</textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="fee" class="form-label">ফি (৳) <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="fee" name="fee" value="{{ old('fee', 0) }}" step="0.01" min="0" required>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="1" checked>
                                <label class="form-check-label" for="is_active">
                                    বিষয়টি সক্রিয় রাখুন
                                </label>
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <a href="{{ route('admin.subjects.index') }}" class="btn btn-secondary">
                                <i class='bx bx-arrow-back me-1'></i>বাতিল
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class='bx bx-save me-1'></i>বিষয় তৈরি করুন
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Add specific animations for form elements */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .fade-in {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    .fade-in:nth-child(1) { animation-delay: 0.1s; }
    .fade-in:nth-child(2) { animation-delay: 0.2s; }
    
    /* Form styling */
    .form-control {
        border-radius: 8px;
        padding: 0.85rem 1.25rem;
    }
    
    .form-label {
        font-weight: 500;
        margin-bottom: 0.5rem;
    }
    
    .btn {
        padding: 0.6rem 1.25rem;
        border-radius: 8px;
    }
    
    /* Dark mode fixes */
    :root.dark-mode .form-control {
        background-color: #1e293b !important;
        border-color: #334155 !important;
        color: #f1f5f9 !important;
    }
    
    :root.dark-mode .form-label {
        color: #f1f5f9 !important;
    }
    
    :root.dark-mode .form-check-label {
        color: #f1f5f9 !important;
    }
</style>
@endsection