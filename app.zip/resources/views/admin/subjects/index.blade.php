@extends('admin.layouts.app')

@section('title', 'বিষয়সমূহ - সাইমুম শিল্পীগোষ্ঠী')

@section('content')
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex align-items-center mb-4 fade-in">
        <div>
            <h4 class="mb-1">বিষয় ব্যবস্থাপনা</h4>
            <p class="mb-0 text-muted">সকল বিষয়ের তালিকা এবং ব্যবস্থাপনা</p>
        </div>
        <div class="ms-auto d-flex align-items-center">
            <div class="me-3">
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0">
                        <i class='bx bx-search'></i>
                    </span>
                    <input type="text" class="form-control border-start-0" id="subjectSearch" placeholder="বিষয় অনুসন্ধান..." style="min-width: 200px;">
                </div>
            </div>
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">হোম</a></li>
                <li class="breadcrumb-item active" aria-current="page">বিষয়সমূহ</li>
            </ol>
        </div>
    </div>

    <div class="row">
        <div class="col-12 fade-in">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">সকল বিষয়</h5>
                    <a href="{{ route('admin.subjects.create') }}" class="btn btn-primary">
                        <i class='bx bx-plus me-1'></i>নতুন বিষয়
                    </a>
                </div>
                <div class="card-body">
                    @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            {{ session('success') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    @endif

                    <div class="table-responsive">
                        <table class="table table-hover" id="subjectsTable">
                            <thead>
                                <tr>
                                    <th>নাম</th>
                                    <th>কোড</th>
                                    <th>বর্ণনা</th>
                                    <th>স্ট্যাটাস</th>
                                    <th>তৈরির তারিখ</th>
                                    <th class="text-end">অ্যাকশন</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($subjects as $subject)
                                <tr class="fade-in" data-subject-name="{{ strtolower($subject->name) }}" data-subject-code="{{ strtolower($subject->code) }}">
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="me-2">
                                                <i class='bx bx-book bx-sm text-primary'></i>
                                            </div>
                                            <div>
                                                <div class="fw-semibold">{{ $subject->name }}</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark">{{ $subject->code }}</span>
                                    </td>
                                    <td>
                                        <div class="text-muted" data-bs-toggle="tooltip" data-bs-title="{{ $subject->description }}">
                                            {{ Str::limit($subject->description, 50) }}
                                        </div>
                                    </td>
                                    <td>
                                        <div class="form-check form-switch form-check-inline">
                                            <input class="form-check-input status-toggle" type="checkbox" role="switch" 
                                                   data-id="{{ $subject->id }}" {{ $subject->is_active ? 'checked' : '' }}>
                                            <label class="form-check-label">
                                                <span class="badge {{ $subject->is_active ? 'bg-success' : 'bg-secondary' }}">
                                                    {{ $subject->is_active ? 'সক্রিয়' : 'নিষ্ক্রিয়' }}
                                                </span>
                                            </label>
                                        </div>
                                    </td>
                                    <td>
                                        <small class="text-muted">{{ $subject->created_at->format('d/m/Y') }}</small>
                                    </td>
                                    <td class="text-end">
                                        <div class="btn-group" role="group">
                                            <a href="{{ route('admin.subjects.edit', $subject) }}" class="btn btn-sm btn-warning" title="সম্পাদনা">
                                                <i class='bx bx-edit'></i>
                                            </a>
                                            
                                            @if($subject->associatedForms->count() > 0)
                                            <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#formFeesModal{{ $subject->id }}" title="ফি সেটিং">
                                                <i class='bx bx-cog'></i>
                                            </button>
                                            @else
                                            <button type="button" class="btn btn-sm btn-secondary" title="ফি সেটিং (কোন ফর্ম নেই)" disabled>
                                                <i class='bx bx-cog'></i>
                                            </button>
                                            @endif
                                            
                                            <form action="{{ route('admin.subjects.destroy', $subject) }}" method="POST" class="d-inline">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('আপনি কি নিশ্চিত যে আপনি এই বিষয়টি মুছে ফেলতে চান?')" title="মুছুন">
                                                    <i class='bx bx-trash'></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="6" class="text-center py-5 fade-in">
                                        <i class='bx bx-book bx-lg text-muted mb-3'></i>
                                        <h5 class="text-muted">কোন বিষয় পাওয়া যায়নি</h5>
                                        <p class="text-muted mb-0">এখনও কোন বিষয় তৈরি করা হয়নি।</p>
                                        <a href="{{ route('admin.subjects.create') }}" class="btn btn-primary mt-3">
                                            <i class='bx bx-plus me-1'></i>প্রথম বিষয় তৈরি করুন
                                        </a>
                                    </td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                    
                    @if($subjects->hasPages())
                    <div class="d-flex justify-content-center mt-4 fade-in">
                        {{ $subjects->links() }}
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Form Fees Modals -->
@forelse($subjects as $subject)
@if($subject->associatedForms->count() > 0)
<div class="modal fade" id="formFeesModal{{ $subject->id }}" tabindex="-1" aria-labelledby="formFeesModalLabel{{ $subject->id }}" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="formFeesModalLabel{{ $subject->id }}">{{ $subject->name }} - ফর্ম ফি সেটিং</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <p><strong>বিষয় কোড:</strong> <span class="badge bg-light text-dark">{{ $subject->code }}</span></p>
                    <p><strong>ডিফল্ট ফি:</strong> <span class="fw-bold">{{ number_format($subject->fee, 2) }}৳</span></p>
                </div>
                
                <form>
                    @csrf
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="table-light">
                                <tr>
                                    <th>ফর্মের নাম</th>
                                    <th>বর্তমান ফি (৳)</th>
                                    <th>নতুন ফি (৳)</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($subject->associatedForms as $form)
                                <tr>
                                    <td>{{ $form['name'] }}</td>
                                    <td>{{ number_format($form['fee'], 2) }}৳</td>
                                    <td>
                                        <input type="number" 
                                               id="form_fee_{{ $form['id'] }}"
                                               class="form-control form-control-sm" 
                                               value="{{ $form['fee'] != $subject->fee ? $form['fee'] : '' }}" 
                                               step="0.01" 
                                               min="0"
                                               placeholder="ডিফল্ট ফি: {{ number_format($subject->fee, 2) }}৳">
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-end">
                        <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">বাতিল</button>
                        <button type="button" class="btn btn-primary save-form-fees" data-subject-id="{{ $subject->id }}" data-save-url="{{ route('admin.subjects.save-form-fees', $subject) }}">
                            <i class='bx bx-save me-1'></i>সংরক্ষণ
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endif
@empty
@endforelse

<style>
    /* Add specific animations for subjects elements */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .fade-in {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    .fade-in:nth-child(1) { animation-delay: 0.1s; }
    .fade-in:nth-child(2) { animation-delay: 0.2s; }
    .fade-in:nth-child(3) { animation-delay: 0.3s; }
    .fade-in:nth-child(4) { animation-delay: 0.4s; }
    
    /* Ensure table rows have proper fade-in */
    .table tbody tr.fade-in {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    .table tbody tr.fade-in:nth-child(1) { animation-delay: 0.1s; }
    .table tbody tr.fade-in:nth-child(2) { animation-delay: 0.2s; }
    .table tbody tr.fade-in:nth-child(3) { animation-delay: 0.3s; }
    .table tbody tr.fade-in:nth-child(4) { animation-delay: 0.4s; }
    .table tbody tr.fade-in:nth-child(5) { animation-delay: 0.5s; }
    .table tbody tr.fade-in:nth-child(6) { animation-delay: 0.6s; }
    .table tbody tr.fade-in:nth-child(7) { animation-delay: 0.7s; }
    .table tbody tr.fade-in:nth-child(8) { animation-delay: 0.8s; }
    .table tbody tr.fade-in:nth-child(9) { animation-delay: 0.9s; }
    .table tbody tr.fade-in:nth-child(10) { animation-delay: 1.0s; }
    
    /* Dark mode fixes for table data */
    :root.dark-mode .table tbody td {
        color: #f1f5f9 !important;
    }
    
    :root.dark-mode .table thead th {
        color: #f1f5f9 !important;
    }
    
    /* Dark mode fix for empty table cell */
    :root.dark-mode .table tbody tr td[colspan="7"] {
        background-color: #1e293b !important;
    }
    
    /* Hover effect for table rows */
    .table-hover tbody tr {
        transition: all 0.3s ease;
    }
    
    .table-hover tbody tr:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }
    
    /* Status toggle switch */
    .form-check-input:checked {
        background-color: var(--success-color);
        border-color: var(--success-color);
    }
    
    .form-check-input:focus {
        border-color: var(--primary-color);
        box-shadow: 0 0 0 0.2rem rgba(74, 144, 226, 0.25);
    }
    
    /* Button group improvements */
    .btn-group {
        display: inline-flex;
        gap: 0.25rem;
    }
    
    .btn-group .btn {
        border-radius: 0.375rem !important;
    }
    
    .btn-group .btn:first-child {
        border-top-right-radius: 0 !important;
        border-bottom-right-radius: 0 !important;
    }
    
    .btn-group .btn:not(:first-child):not(:last-child) {
        border-radius: 0 !important;
    }
    
    .btn-group .btn:last-child {
        border-top-left-radius: 0 !important;
        border-bottom-left-radius: 0 !important;
    }
    
    /* Search input focus */
    .form-control:focus {
        border-color: var(--primary-color);
        box-shadow: 0 0 0 0.2rem rgba(74, 144, 226, 0.25);
    }
</style>

<script>
    // Handle status toggle
    document.addEventListener('DOMContentLoaded', function() {
        // Check if we're on the correct page
        if (!document.getElementById('subjectsTable')) {
            return;
        }
        
        // Initialize tooltips
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
        
        const statusToggles = document.querySelectorAll('.status-toggle');
        
        statusToggles.forEach(toggle => {
            toggle.addEventListener('change', function() {
                const subjectId = this.getAttribute('data-id');
                const isActive = this.checked ? 1 : 0;
                
                fetch(`/admin/subjects/${subjectId}/status`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                    },
                    body: JSON.stringify({
                        is_active: isActive
                    })
                })
                .then(response => {
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        // Update the label text and badge
                        const label = this.nextElementSibling;
                        const badge = label.querySelector('.badge');
                        if (this.checked) {
                            badge.className = 'badge bg-success';
                            badge.textContent = 'সক্রিয়';
                        } else {
                            badge.className = 'badge bg-secondary';
                            badge.textContent = 'নিষ্ক্রিয়';
                        }
                        
                        // Show success message
                        showNotification('success', 'বিষয়ের স্ট্যাটাস সফলভাবে আপডেট হয়েছে');
                    }
                })
                .catch(error => {
                    console.error('Error updating subject status:', error);
                    // Revert the toggle
                    this.checked = !this.checked;
                    showNotification('error', 'স্ট্যাটাস আপডেট করতে সমস্যা হয়েছে');
                });
            });
        });
        
        // Handle form fees saving for modals
        document.addEventListener('click', function(e) {
            if (e.target && e.target.classList.contains('save-form-fees')) {
                e.preventDefault();
                
                const button = e.target;
                const subjectId = button.getAttribute('data-subject-id');
                const saveUrl = button.getAttribute('data-save-url');
                const modalId = button.closest('.modal').id;
                saveFormFees(subjectId, saveUrl, modalId);
            }
        });
        
        function saveFormFees(subjectId, saveUrl, modalId) {
            // Show loading state
            const button = document.querySelector(`#${modalId} .save-form-fees`);
            const originalText = button.innerHTML;
            button.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> সংরক্ষণ হচ্ছে...';
            button.disabled = true;
            
            // Collect form fees
            const formFees = {};
            const feeInputs = document.querySelectorAll(`#${modalId} input[id^="form_fee_"]`);
            
            feeInputs.forEach(input => {
                const formId = input.id.replace('form_fee_', '');
                const value = input.value.trim();
                
                // Only send non-empty values
                if (value !== '') {
                    formFees[formId] = parseFloat(value);
                } else {
                    formFees[formId] = null; // Use default fee
                }
            });
            
            // Get CSRF token
            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
            
            // Debug: Check if CSRF token is available
            if (!csrfToken) {
                showNotification('error', 'CSRF token not found');
                button.innerHTML = originalText;
                button.disabled = false;
                return;
            }
            
            // Debug: Log the request details
            console.log('Sending request to:', saveUrl);
            console.log('CSRF Token:', csrfToken);
            console.log('Form Fees:', formFees);
            
            // Send request
            fetch(saveUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken,
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    form_fees: formFees,
                    _token: csrfToken
                })
            })
            .then(response => {
                if (!response.ok) {
                    return response.text().then(text => {
                        try {
                            const data = JSON.parse(text);
                            throw new Error(data.message || `HTTP error! status: ${response.status}`);
                        } catch (e) {
                            throw new Error(`HTTP error! status: ${response.status}. Response: ${text}`);
                        }
                    });
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    showNotification('success', 'ফর্ম ফি সফলভাবে আপডেট হয়েছে');
                    // Close modal and reload after 2 seconds
                    setTimeout(() => {
                        const modalElement = document.getElementById(modalId);
                        if (modalElement) {
                            const modal = bootstrap.Modal.getInstance(modalElement);
                            if (modal) {
                                modal.hide();
                            }
                        }
                        location.reload();
                    }, 2000);
                } else {
                    showNotification('error', data.message || 'ফি আপডেট করতে সমস্যা হয়েছে');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('error', 'ত্রুটি দেখা দিয়েছে: ' + error.message);
            })
            .finally(() => {
                // Restore button state
                button.innerHTML = originalText;
                button.disabled = false;
            });
        }
        
        function showNotification(type, message) {
            // Remove existing notifications
            const existing = document.querySelector('.form-fee-notification');
            if (existing) {
                existing.remove();
            }
            
            const alertDiv = document.createElement('div');
            alertDiv.className = `alert alert-${type === 'success' ? 'success' : 'danger'} alert-dismissible fade show position-fixed form-fee-notification`;
            alertDiv.style.top = '20px';
            alertDiv.style.right = '20px';
            alertDiv.style.zIndex = '9999';
            alertDiv.style.maxWidth = '400px';
            alertDiv.innerHTML = `
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            `;
            
            document.body.appendChild(alertDiv);
            
            // Auto remove after 3 seconds
            setTimeout(() => {
                if (alertDiv.parentNode) {
                    alertDiv.remove();
                }
            }, 3000);
        }
    });
</script>
@endsection