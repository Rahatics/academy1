@extends('admin.layouts.app')

@section('title', 'বিষয় সম্পাদনা - সাইমুম শিল্পীগোষ্ঠী')

@section('content')
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex align-items-center mb-4 fade-in">
        <div>
            <h4 class="mb-1">বিষয় সম্পাদনা</h4>
            <p class="mb-0 text-muted">বিষয়ের তথ্য সম্পাদনা করুন</p>
        </div>
        <div class="ms-auto d-flex align-items-center">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">হোম</a></li>
                <li class="breadcrumb-item"><a href="{{ route('admin.subjects.index') }}">বিষয়সমূহ</a></li>
                <li class="breadcrumb-item active" aria-current="page">বিষয় সম্পাদনা</li>
            </ol>
        </div>
    </div>

    <div class="row">
        <div class="col-12 fade-in">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">বিষয়ের তথ্য</h5>
                </div>
                <div class="card-body">
                    @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            {{ session('success') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    @endif

                    @if($errors->any())
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <ul class="mb-0">
                                @foreach($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    @endif

                    <form action="{{ route('admin.subjects.update', $subject) }}" method="POST">
                        @csrf
                        @method('PUT')
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="name" class="form-label">বিষয়ের নাম <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="name" name="name" value="{{ old('name', $subject->name) }}" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="code" class="form-label">বিষয় কোড <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="code" name="code" value="{{ old('code', $subject->code) }}" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">বর্ণনা</label>
                            <textarea class="form-control" id="description" name="description" rows="4">{{ old('description', $subject->description) }}</textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="fee" class="form-label">ফি (৳) <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="fee" name="fee" value="{{ old('fee', $subject->fee) }}" step="0.01" min="0" required>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="1" {{ old('is_active', $subject->is_active) ? 'checked' : '' }}>
                                <label class="form-check-label" for="is_active">
                                    বিষয়টি সক্রিয় রাখুন
                                </label>
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <a href="{{ route('admin.subjects.index') }}" class="btn btn-secondary">
                                <i class='bx bx-arrow-back me-1'></i>বাতিল
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class='bx bx-save me-1'></i>আপডেট করুন
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Form Fee Settings Card -->
            <div class="card mt-4">
                <div class="card-header">
                    <h5 class="mb-0">ফর্ম ফি সেটিং</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <p><strong>বিষয় কোড:</strong> {{ $subject->code }}</p>
                        <p><strong>ডিফল্ট ফি:</strong> {{ number_format($subject->fee, 2) }}৳</p>
                    </div>
                    
                    @if($subject->associatedForms->count() > 0)
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>ফর্মের নাম</th>
                                    <th>বর্তমান ফি (৳)</th>
                                    <th>নতুন ফি (৳)</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($subject->associatedForms as $form)
                                <tr>
                                    <td>{{ $form['name'] }}</td>
                                    <td>{{ number_format($form['fee'], 2) }}৳</td>
                                    <td>
                                        <input type="number" 
                                               id="form_fee_{{ $form['id'] }}"
                                               class="form-control form-control-sm" 
                                               value="{{ $form['fee'] != $subject->fee ? $form['fee'] : '' }}" 
                                               step="0.01" 
                                               min="0"
                                               placeholder="ডিফল্ট ফি: {{ number_format($subject->fee, 2) }}৳">
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-end">
                        <button type="button" class="btn btn-primary" id="saveFormFeesBtn" data-subject-id="{{ $subject->id }}" data-save-url="{{ route('admin.subjects.save-form-fees', $subject) }}">ফি সংরক্ষণ</button>
                    </div>
                    @else
                    <div class="alert alert-info">
                        <i class='bx bx-info-circle'></i> এই বিষয়টি কোনো ফর্মে ব্যবহার করা হচ্ছে না।
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Add specific animations for form elements */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .fade-in {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    .fade-in:nth-child(1) { animation-delay: 0.1s; }
    .fade-in:nth-child(2) { animation-delay: 0.2s; }
    
    /* Form styling */
    .form-control {
        border-radius: 8px;
        padding: 0.85rem 1.25rem;
    }
    
    .form-label {
        font-weight: 500;
        margin-bottom: 0.5rem;
    }
    
    .btn {
        padding: 0.6rem 1.25rem;
        border-radius: 8px;
    }
    
    /* Dark mode fixes */
    :root.dark-mode .form-control {
        background-color: #1e293b !important;
        border-color: #334155 !important;
        color: #f1f5f9 !important;
    }
    
    :root.dark-mode .form-label {
        color: #f1f5f9 !important;
    }
    
    :root.dark-mode .form-check-label {
        color: #f1f5f9 !important;
    }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle form fees saving
    const saveButton = document.getElementById('saveFormFeesBtn');
    
    if (saveButton) {
        saveButton.addEventListener('click', function() {
            const subjectId = this.getAttribute('data-subject-id');
            const saveUrl = this.getAttribute('data-save-url');
            saveFormFees(subjectId, saveUrl);
        });
    }
    
    function saveFormFees(subjectId, saveUrl) {
        // Show loading state
        const button = saveButton;
        const originalText = button.innerHTML;
        button.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> সংরক্ষণ হচ্ছে...';
        button.disabled = true;
        
        // Collect form fees
        const formFees = {};
        const feeInputs = document.querySelectorAll('input[id^="form_fee_"]');
        
        feeInputs.forEach(input => {
            const formId = input.id.replace('form_fee_', '');
            const value = input.value.trim();
            
            // Only send non-empty values
            if (value !== '') {
                formFees[formId] = parseFloat(value);
            } else {
                formFees[formId] = null; // Use default fee
            }
        });
        
        // Get CSRF token
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        
        // Debug: Check if CSRF token is available
        if (!csrfToken) {
            showNotification('error', 'CSRF token not found');
            button.innerHTML = originalText;
            button.disabled = false;
            return;
        }
        
        // Debug: Log the request details
        console.log('Sending request to:', saveUrl);
        console.log('CSRF Token:', csrfToken);
        console.log('Form Fees:', formFees);
        
        // Send request
        fetch(saveUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': csrfToken,
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({
                form_fees: formFees,
                _token: csrfToken
            })
        })
        .then(response => {
            if (!response.ok) {
                return response.text().then(text => {
                    try {
                        const data = JSON.parse(text);
                        throw new Error(data.message || `HTTP error! status: ${response.status}`);
                    } catch (e) {
                        throw new Error(`HTTP error! status: ${response.status}. Response: ${text}`);
                    }
                });
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                showNotification('success', 'ফর্ম ফি সফলভাবে আপডেট হয়েছে');
                // Reload after 2 seconds
                setTimeout(() => {
                    location.reload();
                }, 2000);
            } else {
                showNotification('error', data.message || 'ফি আপডেট করতে সমস্যা হয়েছে');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showNotification('error', 'ত্রুটি দেখা দিয়েছে: ' + error.message);
        })
        .finally(() => {
            // Restore button state
            button.innerHTML = originalText;
            button.disabled = false;
        });
    }
    
    function showNotification(type, message) {
        // Remove existing notifications
        const existing = document.querySelector('.form-fee-notification');
        if (existing) {
            existing.remove();
        }
        
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type === 'success' ? 'success' : 'danger'} alert-dismissible fade show position-fixed form-fee-notification`;
        alertDiv.style.top = '20px';
        alertDiv.style.right = '20px';
        alertDiv.style.zIndex = '9999';
        alertDiv.style.maxWidth = '400px';
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        
        document.body.appendChild(alertDiv);
        
        // Auto remove after 3 seconds
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 3000);
    }
});
</script>
@endsection