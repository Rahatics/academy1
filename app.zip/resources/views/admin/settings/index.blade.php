@extends('admin.layouts.app')

@section('title', 'সেটিংস - অ্যাডমিন প্যানেল')

@section('content')
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex align-items-center justify-content-between mb-4 fade-in py-2 px-3 rounded page-header">
        <div>
            <h4 class="mb-0 fw-bold">সেটিংস</h4>
            <p class="text-muted mb-0 small">সিস্টেম কনফিগারেশন এবং সেটিংস পরিচালনা</p>
        </div>
        <div>
            <ol class="breadcrumb mb-0 bg-transparent">
                <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}" class="text-decoration-none">হোম</a></li>
                <li class="breadcrumb-item active" aria-current="page">সেটিংস</li>
            </ol>
        </div>
    </div>

    <!-- Settings Content -->
    <div class="row">
        <div class="col-12 fade-in">
            <div class="card border-0 shadow-sm">
                <div class="card-body p-0">
                    <!-- Settings Tabs -->
                    <div class="border-bottom">
                        <ul class="nav nav-tabs border-0 px-4 pt-4" id="settingsTabs" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="general-tab" data-bs-toggle="tab" data-bs-target="#general" type="button" role="tab">
                                    <i class='bx bx-cog me-2'></i>সাধারণ
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="appearance-tab" data-bs-toggle="tab" data-bs-target="#appearance" type="button" role="tab">
                                    <i class='bx bx-palette me-2'></i>অ্যাপিয়ারেন্স
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="notifications-tab" data-bs-toggle="tab" data-bs-target="#notifications" type="button" role="tab">
                                    <i class='bx bx-bell me-2'></i>বিজ্ঞপ্তি
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="advanced-tab" data-bs-toggle="tab" data-bs-target="#advanced" type="button" role="tab">
                                    <i class='bx bx-code-curly me-2'></i>অ্যাডভান্সড
                                </button>
                            </li>
                        </ul>
                    </div>

                    <!-- Tab Content -->
                    <form action="{{ route('admin.settings.update') }}" method="POST">
                        @csrf
                        @method('PUT')
                        <div class="tab-content p-4" id="settingsTabContent">
                            <!-- General Settings Tab -->
                            <div class="tab-pane fade show active" id="general" role="tabpanel">
                                <div class="row">
                                    <div class="col-md-8">
                                        <h5 class="mb-4">সাধারণ সেটিংস</h5>
                                        
                                        <div class="mb-4">
                                            <label class="form-label fw-bold">সাইটের নাম</label>
                                            <input type="text" class="form-control" name="site_name" value="{{ $settings['site_name'] }}" placeholder="সাইটের নাম লিখুন">
                                            <div class="form-text text-muted">আপনার সাইটের প্রদর্শিত নাম</div>
                                        </div>
                                        
                                        <div class="mb-4">
                                            <label class="form-label fw-bold">সাইটের বর্ণনা</label>
                                            <textarea class="form-control" name="site_description" rows="3" placeholder="সাইটের সংক্ষিপ্ত বর্ণনা">{{ $settings['site_description'] }}</textarea>
                                            <div class="form-text text-muted">সার্চ ইঞ্জিন এবং সোশ্যাল মিডিয়াতে প্রদর্শিত বর্ণনা</div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-6 mb-4">
                                                <label class="form-label fw-bold">যোগাযোগ ইমেইল</label>
                                                <input type="email" class="form-control" name="contact_email" value="{{ $settings['contact_email'] }}" placeholder="contact@example.com">
                                            </div>
                                            <div class="col-md-6 mb-4">
                                                <label class="form-label fw-bold">যোগাযোগ ফোন</label>
                                                <input type="text" class="form-control" name="contact_phone" value="{{ $settings['contact_phone'] }}" placeholder="+880 XXX XXX XXXX">
                                            </div>
                                        </div>
                                        
                                        <div class="mb-4">
                                            <label class="form-label fw-bold">ঠিকানা</label>
                                            <textarea class="form-control" name="address" rows="2" placeholder="পূর্ণ ঠিকানা">{{ $settings['address'] }}</textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="card border-0 bg-light-subtle">
                                            <div class="card-body">
                                                <h6 class="card-title">সেটিংস তথ্য</h6>
                                                <p class="card-text small text-muted">
                                                    সাধারণ সেটিংস আপনার সাইটের মৌলিক তথ্য নিয়ন্ত্রণ করে। 
                                                    এই তথ্য সাইটের বিভিন্ন স্থানে প্রদর্শিত হবে।
                                                </p>
                                                <div class="d-grid gap-2 mt-3">
                                                    <button type="submit" class="btn btn-primary">
                                                        <i class='bx bx-save me-1'></i>সেটিংস সংরক্ষণ
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Appearance Settings Tab -->
                            <div class="tab-pane fade" id="appearance" role="tabpanel">
                                <div class="row">
                                    <div class="col-md-8">
                                        <h5 class="mb-4">অ্যাপিয়ারেন্স সেটিংস</h5>
                                        
                                        <div class="mb-4">
                                            <label class="form-label fw-bold">প্রাইমারি রঙ</label>
                                            <div class="input-group">
                                                <input type="color" class="form-control form-control-color" name="primary_color" value="{{ $settings['primary_color'] }}" title="প্রাইমারি রঙ নির্বাচন করুন">
                                                <input type="text" class="form-control" name="primary_color_text" value="{{ $settings['primary_color'] }}" maxlength="7" placeholder="#4a90e2">
                                            </div>
                                            <div class="form-text text-muted">সাইটের প্রধান রঙ নির্বাচন করুন</div>
                                        </div>
                                        
                                        <div class="mb-4">
                                            <label class="form-label fw-bold">থিম</label>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="card border-0 shadow-sm mb-3">
                                                        <div class="card-body text-center">
                                                            <div class="mb-3">
                                                                <div class="bg-primary rounded mx-auto" style="width: 60px; height: 40px;"></div>
                                                            </div>
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="radio" name="theme" id="lightTheme" checked>
                                                                <label class="form-check-label" for="lightTheme">
                                                                    লাইট থিম
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="card border-0 shadow-sm mb-3">
                                                        <div class="card-body text-center">
                                                            <div class="mb-3">
                                                                <div class="bg-dark rounded mx-auto" style="width: 60px; height: 40px;"></div>
                                                            </div>
                                                            <div class="form-check">
                                                                <input class="form-check-input" type="radio" name="theme" id="darkTheme">
                                                                <label class="form-check-label" for="darkTheme">
                                                                    ডার্ক থিম
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="mb-4">
                                            <label class="form-label fw-bold">লোগো</label>
                                            <div class="border rounded p-3 text-center">
                                                <div class="mb-3">
                                                    @if(file_exists(public_path('images/logo.png')))
                                                        <img src="{{ asset('images/logo.png') }}" alt="Logo" class="img-fluid" style="max-height: 80px;">
                                                    @else
                                                        <div class="bg-light rounded d-inline-flex align-items-center justify-content-center" style="width: 120px; height: 80px;">
                                                            <i class='bx bx-image-alt fs-1 text-muted'></i>
                                                        </div>
                                                    @endif
                                                </div>
                                                <button type="button" class="btn btn-outline-primary btn-sm">
                                                    <i class='bx bx-upload me-1'></i>নতুন লোগো আপলোড
                                                </button>
                                                <div class="form-text text-muted">সুপারিশকৃত সাইজ: 200x100 পিক্সেল</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="card border-0 bg-light-subtle">
                                            <div class="card-body">
                                                <h6 class="card-title">থিম প্রিভিউ</h6>
                                                <p class="card-text small text-muted">
                                                    অ্যাপিয়ারেন্স সেটিংস আপনার সাইটের দৃশ্যমান রূপ নিয়ন্ত্রণ করে।
                                                </p>
                                                <div class="d-grid gap-2 mt-3">
                                                    <button type="submit" class="btn btn-primary">
                                                        <i class='bx bx-save me-1'></i>সেটিংস সংরক্ষণ
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Notifications Settings Tab -->
                            <div class="tab-pane fade" id="notifications" role="tabpanel">
                                <div class="row">
                                    <div class="col-md-8">
                                        <h5 class="mb-4">বিজ্ঞপ্তি সেটিংস</h5>
                                        
                                        <div class="card border-0 shadow-sm mb-4">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div>
                                                        <h6 class="mb-1">ইমেইল বিজ্ঞপ্তি</h6>
                                                        <p class="text-muted mb-0 small">নতুন আবেদন এবং গুরুত্বপূর্ণ ঘটনার জন্য ইমেইল পান</p>
                                                    </div>
                                                    <div class="form-check form-switch">
                                                        <input class="form-check-input" type="checkbox" name="enable_notifications" id="enableNotifications" {{ $settings['enable_notifications'] ? 'checked' : '' }}>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="card border-0 shadow-sm mb-4">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div>
                                                        <h6 class="mb-1">পুশ বিজ্ঞপ্তি</h6>
                                                        <p class="text-muted mb-0 small">ব্রাউজারে পুশ বিজ্ঞপ্তি প্রদর্শন</p>
                                                    </div>
                                                    <div class="form-check form-switch">
                                                        <input class="form-check-input" type="checkbox" name="enable_push_notifications" id="enablePushNotifications">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="card border-0 shadow-sm mb-4">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div>
                                                        <h6 class="mb-1">SMS বিজ্ঞপ্তি</h6>
                                                        <p class="text-muted mb-0 small">গুরুত্বপূর্ণ তথ্য SMS এর মাধ্যমে পান</p>
                                                    </div>
                                                    <div class="form-check form-switch">
                                                        <input class="form-check-input" type="checkbox" name="enable_sms_notifications" id="enableSmsNotifications">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="mb-4">
                                            <label class="form-label fw-bold">বিজ্ঞপ্তি টেমপ্লেট</label>
                                            <textarea class="form-control" name="notification_template" rows="4" placeholder="বিজ্ঞপ্তি টেমপ্লেট এখানে লিখুন...">{!! "{আবেদনকারীর নাম} একটি নতুন আবেদন জমা দিয়েছেন। আবেদন নম্বর: {আবেদন_নম্বর}" !!}</textarea>
                                            <div class="form-text text-muted">
                                                বিজ্ঞপ্তি টেমপ্লেটে ব্যবহার করুন: {আবেদনকারীর নাম}, {আবেদন_নম্বর}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="card border-0 bg-light-subtle">
                                            <div class="card-body">
                                                <h6 class="card-title">বিজ্ঞপ্তি পরিচালনা</h6>
                                                <p class="card-text small text-muted">
                                                    বিজ্ঞপ্তি সেটিংস আপনাকে নিয়ন্ত্রণ করতে দেয় যে কোন ঘটনার জন্য আপনি বিজ্ঞপ্তি পাবেন।
                                                </p>
                                                <div class="d-grid gap-2 mt-3">
                                                    <button type="submit" class="btn btn-primary">
                                                        <i class='bx bx-save me-1'></i>সেটিংস সংরক্ষণ
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Advanced Settings Tab -->
                            <div class="tab-pane fade" id="advanced" role="tabpanel">
                                <div class="row">
                                    <div class="col-md-8">
                                        <h5 class="mb-4">অ্যাডভান্সড সেটিংস</h5>
                                        
                                        <div class="card border-0 shadow-sm mb-4">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div>
                                                        <h6 class="mb-1">মেইনটেনেন্স মোড</h6>
                                                        <p class="text-muted mb-0 small">সাইট মেইনটেনেন্সের জন্য অস্থায়ীভাবে বন্ধ করুন</p>
                                                    </div>
                                                    <div class="form-check form-switch">
                                                        <input class="form-check-input" type="checkbox" name="maintenance_mode" id="maintenanceMode" {{ $settings['maintenance_mode'] ? 'checked' : '' }}>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="card border-0 shadow-sm mb-4">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div>
                                                        <h6 class="mb-1">সিকিউরিটি লগিং</h6>
                                                        <p class="text-muted mb-0 small">সিকিউরিটি ইভেন্টগুলি লগ করুন</p>
                                                    </div>
                                                    <div class="form-check form-switch">
                                                        <input class="form-check-input" type="checkbox" name="security_logging" id="securityLogging" checked>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="card border-0 shadow-sm mb-4">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div>
                                                        <h6 class="mb-1">অটো ব্যাকআপ</h6>
                                                        <p class="text-muted mb-0 small">স্বয়ংক্রিয়ভাবে ডেটা ব্যাকআপ নিন</p>
                                                    </div>
                                                    <div class="form-check form-switch">
                                                        <input class="form-check-input" type="checkbox" name="auto_backup" id="autoBackup">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="mb-4">
                                            <label class="form-label fw-bold">সিকিউরিটি কী</label>
                                            <div class="input-group">
                                                <input type="password" class="form-control" name="security_key" placeholder="সিকিউরিটি কী লিখুন">
                                                <button class="btn btn-outline-secondary" type="button" id="generateKey">
                                                    <i class='bx bx-key'></i>
                                                </button>
                                            </div>
                                            <div class="form-text text-muted">API এবং অন্যান্য সিকিউরিটি ফিচারের জন্য</div>
                                        </div>
                                        
                                        <div class="mb-4">
                                            <label class="form-label fw-bold">কাস্টম CSS</label>
                                            <textarea class="form-control font-monospace" name="custom_css" rows="6" placeholder="/* কাস্টম CSS এখানে লিখুন */"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="card border-0 bg-light-subtle">
                                            <div class="card-body">
                                                <h6 class="card-title">উন্নত কনফিগারেশন</h6>
                                                <p class="card-text small text-muted">
                                                    অ্যাডভান্সড সেটিংস আপনাকে সাইটের উন্নত কনফিগারেশন পরিচালনা করতে দেয়।
                                                </p>
                                                <div class="alert alert-warning small mb-3">
                                                    <i class='bx bx-error-circle me-1'></i>সতর্কতার সাথে পরিবর্তন করুন
                                                </div>
                                                <div class="d-grid gap-2 mt-3">
                                                    <button type="submit" class="btn btn-primary">
                                                        <i class='bx bx-save me-1'></i>সেটিংস সংরক্ষণ
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Settings Tab Styles */
    .nav-tabs .nav-link {
        border: none;
        border-bottom: 3px solid transparent;
        color: var(--text-muted);
        font-weight: 500;
        padding: 0.75rem 1.25rem;
        transition: all 0.3s ease;
    }
    
    .nav-tabs .nav-link:hover {
        color: var(--primary-color);
        background-color: rgba(74, 144, 226, 0.05);
    }
    
    .nav-tabs .nav-link.active {
        color: var(--primary-color);
        border-bottom: 3px solid var(--primary-color);
        background-color: transparent;
    }
    
    .nav-tabs .nav-link i {
        font-size: 1.1rem;
    }
    
    /* Card Styles */
    .card.border-0.shadow-sm {
        border-radius: 12px;
        overflow: hidden;
    }
    
    /* Form Styles */
    .form-control, .form-select {
        border-radius: 8px;
        padding: 0.85rem 1.25rem;
    }
    
    .form-label {
        margin-bottom: 0.5rem;
    }
    
    /* Color Picker */
    .form-control-color {
        height: calc(2.5rem + 4px);
        padding: 0.5rem;
    }
    
    /* Switch Styles */
    .form-switch .form-check-input {
        height: 1.5rem;
        width: 2.75rem;
        border-radius: 2rem;
        margin-top: 0;
    }
    
    /* Tab Content Animation */
    .tab-pane {
        animation: fadeIn 0.5s ease;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    /* Responsive Adjustments */
    @media (max-width: 768px) {
        .nav-tabs .nav-link {
            padding: 0.75rem 1rem;
            font-size: 0.9rem;
        }
        
        .tab-content {
            padding: 1.5rem !important;
        }
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Color picker sync
        const colorPicker = document.querySelector('input[type="color"][name="primary_color"]');
        const colorText = document.querySelector('input[name="primary_color_text"]');
        
        if (colorPicker && colorText) {
            colorPicker.addEventListener('input', function() {
                colorText.value = this.value;
            });
            
            colorText.addEventListener('input', function() {
                if (/^#[0-9A-F]{6}$/i.test(this.value)) {
                    colorPicker.value = this.value;
                }
            });
        }
        
        // Generate security key
        const generateKeyBtn = document.getElementById('generateKey');
        if (generateKeyBtn) {
            generateKeyBtn.addEventListener('click', function() {
                const securityKeyInput = document.querySelector('input[name="security_key"]');
                if (securityKeyInput) {
                    // Generate a random key
                    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()';
                    let key = '';
                    for (let i = 0; i < 32; i++) {
                        key += chars.charAt(Math.floor(Math.random() * chars.length));
                    }
                    securityKeyInput.value = key;
                }
            });
        }
        
        // Tab navigation enhancement
        const tabButtons = document.querySelectorAll('[data-bs-toggle="tab"]');
        tabButtons.forEach(button => {
            button.addEventListener('click', function() {
                // Remove active class from all tabs
                tabButtons.forEach(btn => btn.classList.remove('active'));
                // Add active class to clicked tab
                this.classList.add('active');
            });
        });
    });
</script>
@endsection