@extends('admin.layouts.app')

@section('content')
<div class="app-content">
    <div class="container-fluid">
        <!-- Page Header -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h1 class="h3 mb-0 fw-bold">
                            <i class='bx bx-slider-alt me-2'></i>
                            {{ ucfirst($setting->gateway) }} Gateway Settings
                        </h1>
                        <p class="mb-0">Configure payment gateway credentials and operational settings</p>
                    </div>
                    <div>
                        <a href="{{ route('admin.payment-gateways.index') }}" class="btn btn-light">
                            <i class='bx bx-arrow-back me-1'></i> Back to Gateways
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Validation Errors -->
        @if ($errors->any())
        <div class="row mb-4">
            <div class="col-12">
                <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert">
                    <div class="d-flex align-items-center">
                        <i class='bx bx-error-circle me-2 fs-4'></i>
                        <div>
                            <strong>Whoops! Something went wrong.</strong>
                            <ul class="mb-0 mt-2">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
        </div>
        @endif

        <!-- Success Message -->
        @if(session('status'))
        <div class="row mb-4">
            <div class="col-12">
                <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
                    <div class="d-flex align-items-center">
                        <i class='bx bx-check-circle me-2 fs-4'></i>
                        <div>
                            <strong>Success!</strong> {{ session('status') }}
                        </div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
        </div>
        @endif

        <div class="row">
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-header py-3">
                        <h5 class="mb-0">
                            <i class='bx bx-cog me-2'></i>
                            Configuration
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('admin.payment-gateways.update', $setting->gateway) }}">
                            @csrf
                            @method('POST')
                            
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <div class="form-check form-switch mb-3">
                                        <input type="hidden" name="active" value="0">
                                        <input class="form-check-input" type="checkbox" id="active" name="active" value="1"
                                               {{ $setting->active ? 'checked' : '' }}>
                                        <label class="form-check-label fw-medium" for="active">Enable Gateway</label>
                                        <div class="form-text">Toggle to enable or disable this payment gateway</div>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <label class="form-label fw-medium">Mode</label>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="mode" id="sandbox" 
                                               value="sandbox" {{ $setting->mode === 'sandbox' || old('mode', $setting->mode) === 'sandbox' ? 'checked' : '' }}>
                                        <label class="form-check-label" for="sandbox">Sandbox (Testing)</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="mode" id="live" 
                                               value="live" {{ $setting->mode === 'live' || old('mode', $setting->mode) === 'live' ? 'checked' : '' }}>
                                        <label class="form-check-label" for="live">Live (Production)</label>
                                    </div>
                                    <div class="form-text">Select the environment for this gateway</div>
                                </div>
                            </div>
                            
                            <!-- Gateway Specific Fields -->
                            <div class="gateway-section p-4 rounded-3 mb-4">
                                <h5 class="mb-4">
                                    @if($setting->gateway === 'easypay')
                                        <i class='bx bx-credit-card me-2'></i>
                                    @elseif($setting->gateway === 'dummy')
                                        <i class='bx bx-test-tube me-2'></i>
                                    @endif
                                    {{ ucfirst($setting->gateway) }} Credentials
                                </h5>
                                
                                @if($setting->gateway === 'easypay')
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="merchant_id" class="form-label">Merchant ID</label>
                                            <input type="text" class="form-control" id="merchant_id" name="merchant_id" 
                                                   value="{{ old('merchant_id', $setting->merchant_id) }}">
                                            <div class="form-text">Your unique merchant identifier</div>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="app_key" class="form-label">API Key</label>
                                            <input type="text" class="form-control" id="app_key" name="app_key" 
                                                   value="{{ old('app_key', $setting->app_key) }}">
                                            <div class="form-text">Provided by Easypay for your application</div>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="app_secret" class="form-label">Secret Key</label>
                                            <input type="password" class="form-control" id="app_secret" name="app_secret" 
                                                   value="{{ old('app_secret', $setting->app_secret) }}">
                                            <div class="form-text">Secret key provided by Easypay</div>
                                        </div>
                                        <div class="col-md-12 mb-3">
                                            <label for="callback_url" class="form-label">Callback URL</label>
                                            <input type="url" class="form-control" id="callback_url" name="callback_url" 
                                                   value="{{ old('callback_url', $setting->callback_url) }}" 
                                                   placeholder="https://yourdomain.com/callback">
                                            <div class="form-text">The URL where Easypay will send payment notifications</div>
                                        </div>
                                    </div>
                                @elseif($setting->gateway === 'dummy')
                                    <div class="gateway-info-box p-4 rounded-3">
                                        <div class="d-flex align-items-center mb-3">
                                            <i class='bx bx-info-circle fs-4 me-2'></i>
                                            <h6 class="mb-0">Dummy Gateway Information</h6>
                                        </div>
                                        <p class="mb-0">The dummy gateway is used for testing purposes and does not require any credentials. Payments will be automatically approved.</p>
                                    </div>
                                @endif
                            </div>
                            
                            <div class="d-flex justify-content-end">
                                <a href="{{ route('admin.payment-gateways.index') }}" class="btn btn-light me-2">
                                    <i class='bx bx-x me-1'></i> Cancel
                                </a>
                                <button type="submit" class="btn btn-primary">
                                    <i class='bx bx-save me-1'></i> Save Settings
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Gateway Information -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-header py-3">
                        <h5 class="mb-0">
                            <i class='bx bx-info-circle me-2'></i>
                            Gateway Information
                        </h5>
                    </div>
                    <div class="card-body">
                        @if($setting->gateway === 'easypay')
                            <p>The Easypay payment gateway allows applicants to pay using various payment methods. You need to obtain your credentials from the Easypay business portal.</p>
                            <ul>
                                <li><strong>Merchant ID</strong>: Your unique merchant identifier</li>
                                <li><strong>API Key</strong>: Provided by Easypay for your application</li>
                                <li><strong>Secret Key</strong>: Secret key provided by Easypay</li>
                                <li><strong>Callback URL</strong>: The URL where Easypay will send payment notifications</li>
                            </ul>
                            <div class="alert alert-info">
                                <i class='bx bx-info-circle me-2'></i>
                                <strong>Mode Information:</strong> In Sandbox mode, you can test payments using test accounts. In Live mode, real transactions will be processed.
                            </div>
                        @elseif($setting->gateway === 'dummy')
                            <p>The dummy payment gateway is intended for testing purposes only. All payments made through this gateway will be automatically approved without processing any real transactions.</p>
                            <div class="alert alert-warning">
                                <i class='bx bx-error-circle me-2'></i>
                                <strong>Warning:</strong> Do not use the dummy gateway in production environments.
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .form-control, .form-select {
        border-width: 2px;
        transition: all 0.3s ease;
        min-height: calc(2.5rem + 4px);
        background-color: var(--card-bg);
        border-color: var(--border-color);
        color: var(--text-color);
    }
    
    .form-control:focus, .form-select:focus {
        border-color: #4a90e2;
        box-shadow: 0 0 0 0.25rem rgba(74, 144, 226, 0.25);
    }
    
    .form-control::placeholder {
        color: var(--text-muted);
    }
    
    .input-group-text {
        border-width: 2px;
        border-right: 0;
        background-color: var(--card-bg);
        border-color: var(--border-color);
        color: var(--text-color);
    }
    
    .form-control.border-start-0 {
        border-left: 0;
    }
    
    .btn-primary {
        padding: 0.5rem 1.5rem;
        font-weight: 500;
        transition: all 0.3s ease;
    }
    
    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
    }
    
    :root.dark-mode .btn-primary:hover {
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.3);
    }
    
    .card {
        transition: all 0.3s ease;
        border-radius: 12px;
        background-color: var(--card-bg);
        border-color: var(--border-color);
        border: 1px solid var(--border-color);
    }
    
    .card:hover {
        transform: translateY(-3px);
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15) !important;
    }
    
    :root.dark-mode .card:hover {
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.3) !important;
    }
    
    .form-check-input:checked {
        background-color: #4a90e2;
        border-color: #4a90e2;
    }
    
    .form-switch .form-check-input {
        height: 1.5em;
        width: 2.5em;
    }
    
    .alert {
        border: none;
        border-radius: 12px;
    }
    
    .card-header {
        border-radius: 12px 12px 0 0 !important;
        background-color: var(--card-bg);
        border-color: var(--border-color);
    }
    
    .border {
        border: 1px solid var(--border-color) !important;
    }
    
    .gateway-section {
        background-color: rgba(0, 0, 0, 0.03);
    }
    
    :root.dark-mode .gateway-section {
        background-color: rgba(255, 255, 255, 0.05);
    }
    
    .card-title {
        font-weight: 600;
        color: var(--text-color);
    }
    
    .gateway-info-box {
        background-color: rgba(0, 0, 0, 0.03);
    }
    
    :root.dark-mode .gateway-info-box {
        background-color: rgba(255, 255, 255, 0.05);
    }
    
    .form-text {
        color: var(--text-muted);
    }
    
    /* Ensure proper text visibility in dark mode */
    :root.dark-mode .card-title,
    :root.dark-mode .card-text,
    :root.dark-mode p,
    :root.dark-mode h1,
    :root.dark-mode h2,
    :root.dark-mode h3,
    :root.dark-mode h4,
    :root.dark-mode h5,
    :root.dark-mode h6,
    :root.dark-mode span,
    :root.dark-mode label,
    :root.dark-mode .form-label,
    :root.dark-mode .form-check-label {
        color: var(--text-color) !important;
    }
    
    :root.dark-mode .text-muted,
    :root.dark-mode .form-text {
        color: var(--text-muted) !important;
    }
    
    /* Fix for alert text in dark mode */
    :root.dark-mode .alert-success {
        color: #0f172a !important;
    }
    
    :root.dark-mode .alert-warning {
        color: #0f172a !important;
    }
    
    :root.dark-mode .alert-info {
        color: #0f172a !important;
    }
    
    :root.dark-mode .alert-danger {
        color: #0f172a !important;
    }
</style>
@endsection