@extends('layouts.app')

@section('title', 'সাইমুম শিল্পীগোষ্ঠী')

@section('content')
<div class="hero-section">
    <div>
        <h1 class="display-4">সাইমুম শিল্পীগোষ্ঠী</h1>
        <p class="lead">১৯৭৮ সাল থেকে ইসলামী সংস্কৃতি ছড়িয়ে দিচ্ছি বাংলাদেশ জুড়ে</p>
    </div>
</div>

<div class="container my-5">
    <div class="row">
        <div class="col-lg-8">
            <h2 class="section-title">স্বাগতম</h2>
            <p>
                সাইমুম শিল্পীগোষ্ঠী বাংলাদেশের একটি প্রতিষ্ঠিত সাংস্কৃতিক সংগঠন যা ১৯৭৮ সাল থেকে ইসলামী মূল্যবোধ ও 
                সংস্কৃতি ছড়িয়ে দিচ্ছে সারা দেশে। আমাদের সংগঠন গান, আলোচনা, নাটক ও অন্যান্য সাংস্কৃতিক কার্যক্রমের 
                মাধ্যমে সমাজে ইতিবাচক প্রভাব ফেলে যাচ্ছে।
            </p>
            
            <h3 class="section-title mt-5">আমাদের সাম্প্রতিক কার্যক্রম</h3>
            <div class="row">
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">জুলাই জাগরণ</h5>
                            <p class="card-text">
                                সোহরাওয়ার্দী উদ্যানে আয়োজিত "জুলাই জাগরণ" কার্যক্রমে অংশগ্রহণ করুন।
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">ঈদ মাহফিল</h5>
                            <p class="card-text">
                                আসন্ন ঈদ উপলক্ষে আয়োজিত বিশেষ মাহফিলে অংশ নিন।
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h4>গুরুত্বপূর্ণ নোটিস</h4>
                </div>
                <div class="card-body">
                    <ul class="list-unstyled">
                        <li class="mb-2">
                            <h6>জুলাই জাগরণ কার্যক্রম</h6>
                            <small class="text-muted">১-৪ আগস্ট, ২০২৫ | সোহরাওয়ার্দী উদ্যান</small>
                        </li>
                        <li class="mb-2">
                            <h6>ঈদ মাহফিল</h6>
                            <small class="text-muted">১৫ আগস্ট, ২০২৫ | ঢাকা বিশ্ববিদ্যালয়</small>
                        </li>
                        <li class="mb-2">
                            <h6>নতুন সদস্য নিয়োগ</h6>
                            <small class="text-muted">আবেদন শেষ হবে ৩০ জুলাই</small>
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h4>যোগাযোগ</h4>
                </div>
                <div class="card-body">
                    <p>আমাদের সাথে যোগাযোগ করতে ডানপাশের মেনু থেকে "যোগাযোগ" পেজে যান অথবা নিচের তথ্য ব্যবহার করুন:</p>
                    <p><strong>ইমেইল:</strong> info@saimum.org</p>
                    <p><strong>ফোন:</strong> +880-XXXXXXXXXX</p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection