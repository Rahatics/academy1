@extends('layouts.app')

@section('title', 'যোগাযোগ - সাইমুম শিল্পীগোষ্ঠী')

@section('content')
<div class="container my-5">
    <h1 class="section-title">যোগাযোগ</h1>
    
    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h3 class="mb-0">আমাদের সাথে যোগাযোগ করুন</h3>
                </div>
                <div class="card-body">
                    <form>
                        <div class="mb-3">
                            <label for="name" class="form-label">নাম *</label>
                            <input type="text" class="form-control" id="name" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">ইমেইল *</label>
                            <input type="email" class="form-control" id="email" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="subject" class="form-label">বিষয় *</label>
                            <input type="text" class="form-control" id="subject" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="message" class="form-label">বার্তা *</label>
                            <textarea class="form-control" id="message" rows="5" required></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">বার্তা পাঠান</button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h4>যোগাযোগের তথ্য</h4>
                </div>
                <div class="card-body">
                    <p><strong>ঠিকানা:</strong><br>
                    {{ organization_info('name') }}<br>
                    {{ organization_info('address') }}</p>
                    
                    <p><strong>ইমেইল:</strong><br>
                    <a href="mailto:{{ organization_info('email') }}">{{ organization_info('email') }}</a></p>
                    
                    <p><strong>ফোন:</strong><br>
                    {{ organization_info('phone') }}</p>
                    
                    <p><strong>সামাজিক মাধ্যম:</strong><br>
                    <a href="{{ config('saimum.social_media.facebook') }}" target="_blank">Facebook</a><br>
                    <a href="{{ config('saimum.social_media.instagram') }}" target="_blank">Instagram</a><br>
                    <a href="{{ config('saimum.social_media.twitter') }}" target="_blank">Twitter</a></p>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h4>অফিসের সময়</h4>
                </div>
                <div class="card-body">
                    <p><strong>রবিবার থেকে বৃহস্পতিবার:</strong><br>
                    সকাল ৯:০০ থেকে বিকাল ৫:০০</p>
                    
                    <p><strong>শুক্রবার এবং শনিবার:</strong><br>
                    বন্ধ</p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row mt-5">
        <div class="col-12">
            <h3 class="section-title">আমাদের অবস্থান</h3>
            <div class="ratio ratio-16x9">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d116834.13673771235!2d90.41932575!3d23.78063645!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b8b087026b81%3A0x8fa563bbdd5904c2!2sDhaka!5e0!3m2!1sen!2sbd!4v1620000000000!5m2!1sen!2sbd" allowfullscreen="" loading="lazy"></iframe>
            </div>
        </div>
    </div>
</div>
@endsection