@extends('layouts.app')

@section('title', 'Easypay Payment Example')

@section('content')
<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Easypay Payment Example</h5>
                </div>
                <div class="card-body">
                    <p>This is an example of how to integrate Easypay payment gateway.</p>
                    
                    <form action="{{ route('easypay.initiate') }}" method="POST">
                        @csrf
                        <div class="mb-3">
                            <label for="amount" class="form-label">Amount (BDT)</label>
                            <input type="number" class="form-control" id="amount" name="amount" value="100" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="product_name" class="form-label">Product Name</label>
                            <input type="text" class="form-control" id="product_name" name="product_name" value="Application Fee" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="customer_name" class="form-label">Customer Name</label>
                            <input type="text" class="form-control" id="customer_name" name="customer_name" value="{{ auth()->check() ? auth()->user()->name : '' }}" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="customer_email" class="form-label">Customer Email</label>
                            <input type="email" class="form-control" id="customer_email" name="customer_email" value="{{ auth()->check() ? auth()->user()->email : '' }}" required>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            <i class='bx bx-credit-card me-1'></i> Pay with Easypay
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection