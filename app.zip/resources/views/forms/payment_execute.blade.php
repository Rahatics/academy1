@extends('layouts.app')

@section('title', 'bKash পেমেন্ট নিশ্চিতকরণ')

@section('content')
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header bg-warning">
          <strong>bKash পেমেন্ট এক্সিকিউট</strong>
        </div>
        <div class="card-body">
          <p class="mb-3">আপনি bKash এ অনুমোদন সম্পন্ন করেছেন বলে ধরে নেওয়া হচ্ছে। এখন পেমেন্ট এক্সিকিউট করে সিস্টেমে নিশ্চিত করুন।</p>
          <form method="POST" action="{{ route('forms.payment.bkash.execute', $application) }}">
            @csrf
            <input type="hidden" name="payment_id" value="{{ $payment_id }}">
            <button type="submit" class="btn btn-primary w-100">পেমেন্ট নিশ্চিত করুন</button>
          </form>
          <div class="mt-3 text-center">
            <a href="{{ route('forms.payment.decision', $application) }}" class="small">ফিরে যান</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
