<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Payment Receipt</title>
    <style>
        /* Add your CSS styles here */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
        
        /* Add your design styles here */
    </style>
</head>
<body>
    <!-- Add your HTML design here -->
    <div class="receipt">
        <h1>Payment Receipt</h1>
        <p>Application ID: {{ $application->application_id }}</p>
        <p>Applicant Name: {{ $application->name }}</p>
        <p>Payment Amount: {{ number_format($application->total_fee, 2) }} BDT</p>
        <p>Payment Date: {{ optional($application->paid_at)->format('Y-m-d H:i') }}</p>
        <!-- Add more fields as needed -->
    </div>
</body>
</html>