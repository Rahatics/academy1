<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>পেমেন্ট রশিদ - {{ $application->public_application_code }}</title>
    <style>
        body {
            font-family: 'SolaimanLipi', 'Arial', sans-serif;
            font-size: 14px;
            line-height: 1.4;
            color: #000;
            margin: 0;
            padding: 20px;
            background-color: #fff;
        }
        
        .receipt-container {
            max-width: 800px;
            margin: 0 auto;
            border: 2px solid #000;
            padding: 20px;
            background-color: #fff;
        }
        
        .receipt-header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 1px solid #000;
            padding-bottom: 15px;
        }
        
        .organization-name {
            font-size: 24px;
            font-weight: bold;
            margin: 0 0 5px 0;
        }
        
        .organization-address {
            font-size: 16px;
            margin: 0 0 5px 0;
        }
        
        .receipt-title {
            font-size: 20px;
            font-weight: bold;
            text-decoration: underline;
            margin: 10px 0;
        }
        
        .receipt-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        
        .receipt-info div {
            width: 48%;
        }
        
        .info-label {
            font-weight: bold;
            display: inline-block;
            width: 150px;
        }
        
        .section {
            margin-bottom: 20px;
        }
        
        .section-title {
            font-size: 16px;
            font-weight: bold;
            text-decoration: underline;
            margin-bottom: 10px;
        }
        
        .info-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
        }
        
        .info-table th, .info-table td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }
        
        .info-table th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        
        .amount-section {
            margin: 20px 0;
        }
        
        .amount-in-words {
            margin-bottom: 15px;
        }
        
        .amount-label {
            font-weight: bold;
            display: inline-block;
            width: 150px;
        }
        
        .signature-section {
            margin-top: 40px;
            display: flex;
            justify-content: space-between;
        }
        
        .signature-box {
            width: 45%;
        }
        
        .signature-line {
            margin-top: 40px;
            border-top: 1px solid #000;
            padding-top: 5px;
            text-align: center;
        }
        
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 12px;
            border-top: 1px solid #000;
            padding-top: 10px;
        }
        
        .text-right {
            text-align: right;
        }
        
        .text-center {
            text-align: center;
        }
        
        .bold {
            font-weight: bold;
        }
        
        .mt-20 {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="receipt-container">
        <div class="receipt-header">
            <div class="organization-name">SHILPIGOSTHI ACADEMY</div>
            <div class="organization-address">সাইয়দামার, মিরপুর, ঢাকা</div>
            <div class="organization-address">ইমেইল: info@shilpigosthi.edu.bd | ফোন: +880-1234567890</div>
            <div class="receipt-title">মানি রশিদ</div>
        </div>
        
        <div class="receipt-info">
            <div>
                <span class="info-label">রশিদ নং:</span>
                <span>{{ $application->internal_invoice }}</span>
            </div>
            <div class="text-right">
                <span class="info-label">তারিখ:</span>
                <span>{{ optional($application->paid_at)->format('d/m/Y') }}</span>
            </div>
        </div>
        
        <div class="receipt-info">
            <div>
                <span class="info-label">আবেদন আইডি:</span>
                <span>{{ $application->application_id }}</span>
            </div>
            <div class="text-right">
                <span class="info-label">পাবলিক কোড:</span>
                <span>{{ $application->public_application_code }}</span>
            </div>
        </div>
        
        <!-- Applicant Information -->
        <div class="section">
            <div class="section-title">আবেদনকারীর তথ্য</div>
            <table class="info-table">
                <tr>
                    <th width="30%">নাম</th>
                    <td>{{ $application->name }}</td>
                </tr>
                @if($application->data['student_name_bengali'] ?? null)
                <tr>
                    <th>শিক্ষার্থীর নাম (বাংলায়)</th>
                    <td>{{ $application->data['student_name_bengali'] }}</td>
                </tr>
                @endif
                @if($application->data['student_name_english'] ?? null)
                <tr>
                    <th>শিক্ষার্থীর নাম (ইংরেজিতে)</th>
                    <td>{{ $application->data['student_name_english'] }}</td>
                </tr>
                @endif
                @if($application->data['father_name_bengali'] ?? null)
                <tr>
                    <th>পিতার নাম</th>
                    <td>{{ $application->data['father_name_bengali'] }}</td>
                </tr>
                @endif
                @if($application->data['mother_name_bengali'] ?? null)
                <tr>
                    <th>মাতার নাম</th>
                    <td>{{ $application->data['mother_name_bengali'] }}</td>
                </tr>
                @endif
            </table>
        </div>
        
        <!-- Payment Details -->
        <div class="section">
            <div class="section-title">পেমেন্ট বিবরণ</div>
            <table class="info-table">
                <tr>
                    <th width="30%">বিবরণ</th>
                    <th width="20%" class="text-center">পরিমাণ (৳)</th>
                </tr>
                <tr>
                    <td>আবেদন ফি</td>
                    <td class="text-right">{{ number_format($application->total_fee, 2) }}</td>
                </tr>
                <tr>
                    <td colspan="2" class="text-right bold">
                        মোট: {{ number_format($application->total_fee, 2) }} ৳
                    </td>
                </tr>
            </table>
        </div>
        
        <!-- Amount in Words -->
        <div class="amount-section">
            <div class="amount-in-words">
                <span class="amount-label">টাকার পরিমাণ (কথায়):</span>
                <span>{{ convert_number_to_words($application->total_fee) }} টাকা মাত্র</span>
            </div>
        </div>
        
        <!-- Additional Information -->
        <div class="section">
            <div class="section-title">অতিরিক্ত তথ্য</div>
            <table class="info-table">
                <tr>
                    <th width="30%">বিবরণ</th>
                    <th>তথ্য</th>
                </tr>
                <tr>
                    <td>আবেদনের তারিখ</td>
                    <td>{{ $application->created_at->format('d/m/Y') }}</td>
                </tr>
                @if($application->subject)
                    @php
                        $subject = $application->subjectByCode;
                    @endphp
                    @if($subject)
                    <tr>
                        <td>আবেদনকৃত বিষয়</td>
                        <td>{{ $subject->name }}</td>
                    </tr>
                    @endif
                @endif
                @if($application->academic_class)
                <tr>
                    <td>শ্রেণি</td>
                    <td>{{ $application->academic_class }}</td>
                </tr>
                @endif
            </table>
        </div>
        
        <div class="signature-section">
            <div class="signature-box">
                <div class="signature-line">আবেদনকারীর স্বাক্ষর</div>
            </div>
            <div class="signature-box">
                <div class="signature-line">কর্তৃপক্ষের স্বাক্ষর</div>
            </div>
        </div>
        
        <div class="footer">
            <p>এই রশিদটি পেমেন্ট সফল হওয়ার পর স্বয়ংক্রিয়ভাবে তৈরি হয়েছে।</p>
            <p>প্রিন্ট করে সংরক্ষণ করুন এবং প্রয়োজনে উপস্থাপন করুন।</p>
            <p>রশিদ প্রিন্ট সময়: {{ now()->format('d/m/Y H:i:s') }}</p>
        </div>
    </div>
</body>
</html>