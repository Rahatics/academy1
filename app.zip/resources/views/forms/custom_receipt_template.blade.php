<!-- 
This is your custom receipt template.
Replace this entire content with your complete PDF design.
Keep the PHP variables as they are to populate data dynamically.
 -->

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>পেমেন্ট রশিদ - {{ $application->public_application_code }}</title>
    <style>
        /* 
         * Replace this CSS with your complete design CSS
         * Keep the data variables as they are
         */
        body {
            font-family: 'kalpurush', 'SolaimanLipi', 'Arial', sans-serif;
            font-size: 14px;
            line-height: 1.4;
            color: #000;
            margin: 0;
            padding: 20px;
            background-color: #fff;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
        }
        
        /* Add your complete CSS design here */
    </style>
</head>
<body>
    <div class="container">
        <!-- 
         * Replace this HTML with your complete design
         * Keep the data variables as they are to populate dynamically
         -->
        
        <h1>আপনার কাস্টম রশিদ ডিজাইন</h1>
        
        <div class="receipt-header">
            <h2>SHILPIGOSTHI ACADEMY</h2>
            <p>সাইয়দামার, মিরপুর, ঢাকা</p>
        </div>
        
        <div class="applicant-info">
            <h3>আবেদনকারীর তথ্য</h3>
            <p><strong>নাম:</strong> {{ $application->name }}</p>
            <p><strong>আবেদন আইডি:</strong> {{ $application->application_id }}</p>
            <p><strong>পাবলিক কোড:</strong> {{ $application->public_application_code }}</p>
        </div>
        
        <div class="payment-info">
            <h3>পেমেন্ট বিবরণ</h3>
            <p><strong>রশিদ নং:</strong> {{ $application->internal_invoice }}</p>
            <p><strong>পেমেন্ট সময়:</strong> {{ optional($application->paid_at)->format('d/m/Y') }}</p>
            <p><strong>মোট ফি:</strong> {{ number_format($application->total_fee, 2) }} ৳</p>
            <p><strong>টাকার পরিমাণ (কথায়):</strong> {{ convert_number_to_words($application->total_fee) }} টাকা মাত্র</p>
        </div>
        
        <!-- Add your complete design elements here -->
        
        <div class="signature-section">
            <div style="float: left; width: 45%;">
                <p>আবেদনকারীর স্বাক্ষর</p>
                <div style="margin-top: 40px; border-top: 1px solid #000;">&nbsp;</div>
            </div>
            <div style="float: right; width: 45%;">
                <p>কর্তৃপক্ষের স্বাক্ষর</p>
                <div style="margin-top: 40px; border-top: 1px solid #000;">&nbsp;</div>
            </div>
            <div style="clear: both;"></div>
        </div>
    </div>
</body>
</html>