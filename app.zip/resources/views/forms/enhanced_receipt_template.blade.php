<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>পেমেন্ট রশিদ - {{ $application->public_application_code }}</title>
    <style>
        @font-face {
            font-family: 'kalpurush';
            src: url('{{ asset('fonts/kalpurush.ttf') }}') format('truetype');
        }
        
        @font-face {
            font-family: 'SolaimanLipi';
            src: url('{{ asset('fonts/SolaimanLipi.ttf') }}') format('truetype');
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'kalpurush', 'SolaimanLipi', 'Arial', sans-serif;
            font-size: 14px;
            line-height: 1.6;
            color: #333;
            background-color: #f8f9fa;
            padding: 20px 0;
        }
        
        .receipt-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
            position: relative;
        }
        
        .receipt-header {
            background: linear-gradient(135deg, #1a6aa9, #2c8bc5);
            color: white;
            text-align: center;
            padding: 30px 20px;
            position: relative;
        }
        
        .header-watermark {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            opacity: 0.1;
            font-size: 100px;
            font-weight: bold;
            pointer-events: none;
        }
        
        .organization-logo {
            width: 80px;
            height: 80px;
            background: white;
            border-radius: 50%;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 30px;
            font-weight: bold;
            color: #1a6aa9;
        }
        
        .organization-name {
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 5px;
            letter-spacing: 1px;
        }
        
        .organization-address {
            font-size: 16px;
            margin-bottom: 3px;
        }
        
        .receipt-title {
            font-size: 24px;
            font-weight: bold;
            margin: 20px 0;
            padding: 10px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 5px;
            display: inline-block;
        }
        
        .receipt-body {
            padding: 30px;
        }
        
        .receipt-info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .info-card {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            border-left: 4px solid #1a6aa9;
        }
        
        .info-card-title {
            font-size: 16px;
            font-weight: bold;
            color: #1a6aa9;
            margin-bottom: 15px;
            padding-bottom: 8px;
            border-bottom: 1px solid #eee;
        }
        
        .info-row {
            display: flex;
            margin-bottom: 10px;
        }
        
        .info-label {
            font-weight: bold;
            min-width: 150px;
            color: #555;
        }
        
        .info-value {
            flex: 1;
            color: #333;
        }
        
        .section {
            margin-bottom: 30px;
        }
        
        .section-title {
            font-size: 18px;
            font-weight: bold;
            color: #1a6aa9;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #1a6aa9;
            display: inline-block;
        }
        
        .info-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }
        
        .info-table th, .info-table td {
            border: 1px solid #ddd;
            padding: 12px 15px;
            text-align: left;
        }
        
        .info-table th {
            background: #1a6aa9;
            color: white;
            font-weight: bold;
        }
        
        .info-table tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        
        .info-table tr:hover {
            background-color: #e9f0f7;
        }
        
        .amount-section {
            background: #e8f4fc;
            border-radius: 8px;
            padding: 25px;
            margin: 30px 0;
            border: 1px solid #c2e0f7;
        }
        
        .amount-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            font-size: 16px;
        }
        
        .amount-label {
            font-weight: bold;
            color: #1a6aa9;
        }
        
        .amount-value {
            font-weight: bold;
        }
        
        .total-amount {
            font-size: 20px;
            border-top: 2px solid #1a6aa9;
            padding-top: 15px;
            margin-top: 15px;
        }
        
        .amount-in-words {
            background: #f0f8ff;
            padding: 15px;
            border-radius: 5px;
            margin-top: 20px;
            border-left: 3px solid #1a6aa9;
        }
        
        .signature-section {
            margin-top: 50px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
        }
        
        .signature-box {
            text-align: center;
        }
        
        .signature-title {
            font-weight: bold;
            margin-bottom: 50px;
        }
        
        .signature-line {
            margin-top: 20px;
            padding-top: 10px;
            border-top: 1px solid #333;
        }
        
        .footer {
            background: #f8f9fa;
            text-align: center;
            padding: 20px;
            font-size: 12px;
            color: #666;
            border-top: 1px solid #eee;
        }
        
        .status-badge {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: bold;
            background: #28a745;
            color: white;
            font-size: 14px;
        }
        
        .text-right {
            text-align: right;
        }
        
        .text-center {
            text-align: center;
        }
        
        .bold {
            font-weight: bold;
        }
        
        .mt-20 {
            margin-top: 20px;
        }
        
        @media print {
            body {
                background: white;
                padding: 0;
            }
            
            .receipt-container {
                box-shadow: none;
                border-radius: 0;
            }
        }
    </style>
</head>
<body>
    <div class="receipt-container">
        <div class="receipt-header">
            <div class="header-watermark">PAID</div>
            <div class="organization-logo">SA</div>
            <div class="organization-name">SHILPIGOSTHI ACADEMY</div>
            <div class="organization-address">সাইয়দামার, মিরপুর, ঢাকা</div>
            <div class="organization-address">ইমেইল: info@shilpigosthi.edu.bd | ফোন: +880-1234567890</div>
            <div class="receipt-title">মানি রশিদ</div>
        </div>
        
        <div class="receipt-body">
            <div class="text-center mb-4">
                <span class="status-badge">পেমেন্ট সফল</span>
            </div>
            
            <div class="receipt-info-grid">
                <div class="info-card">
                    <div class="info-card-title">আবেদন তথ্য</div>
                    <div class="info-row">
                        <div class="info-label">আবেদন আইডি:</div>
                        <div class="info-value">{{ $application->application_id }}</div>
                    </div>
                    <div class="info-row">
                        <div class="info-label">পাবলিক কোড:</div>
                        <div class="info-value">{{ $application->public_application_code }}</div>
                    </div>
                    <div class="info-row">
                        <div class="info-label">আবেদনের তারিখ:</div>
                        <div class="info-value">{{ $application->created_at->format('d/m/Y') }}</div>
                    </div>
                </div>
                
                <div class="info-card">
                    <div class="info-card-title">পেমেন্ট তথ্য</div>
                    <div class="info-row">
                        <div class="info-label">রশিদ নং:</div>
                        <div class="info-value">{{ $application->internal_invoice }}</div>
                    </div>
                    <div class="info-row">
                        <div class="info-label">পেমেন্ট সময়:</div>
                        <div class="info-value">{{ optional($application->paid_at)->format('d/m/Y H:i:s') }}</div>
                    </div>
                    <div class="info-row">
                        <div class="info-label">পেমেন্ট মাধ্যম:</div>
                        <div class="info-value">বিকাশ</div>
                    </div>
                </div>
            </div>
            
            <!-- Applicant Information -->
            <div class="section">
                <div class="section-title">আবেদনকারীর তথ্য</div>
                <table class="info-table">
                    <tr>
                        <th width="30%">নাম</th>
                        <td>{{ $application->name }}</td>
                    </tr>
                    @if($application->data['student_name_bengali'] ?? null)
                    <tr>
                        <th>শিক্ষার্থীর নাম (বাংলায়)</th>
                        <td>{{ $application->data['student_name_bengali'] }}</td>
                    </tr>
                    @endif
                    @if($application->data['student_name_english'] ?? null)
                    <tr>
                        <th>শিক্ষার্থীর নাম (ইংরেজিতে)</th>
                        <td>{{ $application->data['student_name_english'] }}</td>
                    </tr>
                    @endif
                    @if($application->data['father_name_bengali'] ?? null)
                    <tr>
                        <th>পিতার নাম</th>
                        <td>{{ $application->data['father_name_bengali'] }}</td>
                    </tr>
                    @endif
                    @if($application->data['mother_name_bengali'] ?? null)
                    <tr>
                        <th>মাতার নাম</th>
                        <td>{{ $application->data['mother_name_bengali'] }}</td>
                    </tr>
                    @endif
                </table>
            </div>
            
            <!-- Payment Details -->
            <div class="section">
                <div class="section-title">পেমেন্ট বিবরণ</div>
                <table class="info-table">
                    <tr>
                        <th width="70%">বিবরণ</th>
                        <th width="30%" class="text-right">পরিমাণ (৳)</th>
                    </tr>
                    <tr>
                        <td>আবেদন ফি</td>
                        <td class="text-right">{{ number_format($application->total_fee, 2) }}</td>
                    </tr>
                </table>
                
                <div class="amount-section">
                    <div class="amount-row">
                        <div class="amount-label">মোট পরিমাণ:</div>
                        <div class="amount-value">{{ number_format($application->total_fee, 2) }} ৳</div>
                    </div>
                    <div class="amount-row total-amount">
                        <div class="amount-label">সমাপ্ত পরিমাণ:</div>
                        <div class="amount-value">{{ number_format($application->total_fee, 2) }} ৳</div>
                    </div>
                    
                    <div class="amount-in-words">
                        <div class="amount-label">টাকার পরিমাণ (কথায়):</div>
                        <div>{{ convert_number_to_words($application->total_fee) }} টাকা মাত্র</div>
                    </div>
                </div>
            </div>
            
            <!-- Additional Information -->
            <div class="section">
                <div class="section-title">অতিরিক্ত তথ্য</div>
                <table class="info-table">
                    <tr>
                        <th width="30%">বিবরণ</th>
                        <th>তথ্য</th>
                    </tr>
                    <tr>
                        <td>আবেদনের তারিখ</td>
                        <td>{{ $application->created_at->format('d/m/Y') }}</td>
                    </tr>
                    @if($application->subject)
                        @php
                            $subject = $application->subjectByCode;
                        @endphp
                        @if($subject)
                        <tr>
                            <td>আবেদনকৃত বিষয়</td>
                            <td>{{ $subject->name }}</td>
                        </tr>
                        @endif
                    @endif
                    @if($application->academic_class)
                    <tr>
                        <td>শ্রেণি</td>
                        <td>{{ $application->academic_class }}</td>
                    </tr>
                    @endif
                </table>
            </div>
            
            <div class="signature-section">
                <div class="signature-box">
                    <div class="signature-title">আবেদনকারীর স্বাক্ষর</div>
                    <div class="signature-line">তারিখ: ____/____/______</div>
                </div>
                <div class="signature-box">
                    <div class="signature-title">কর্তৃপক্ষের স্বাক্ষর</div>
                    <div class="signature-line">তারিখ: ____/____/______</div>
                </div>
            </div>
        </div>
        
        <div class="footer">
            <p>এই রশিদটি পেমেন্ট সফল হওয়ার পর স্বয়ংক্রিয়ভাবে তৈরি হয়েছে।</p>
            <p>প্রিন্ট করে সংরক্ষণ করুন এবং প্রয়োজনে উপস্থাপন করুন।</p>
            <p>রশিদ প্রিন্ট সময়: {{ now()->format('d/m/Y H:i:s') }}</p>
        </div>
    </div>
</body>
</html>