@extends('layouts.app')

@section('title', 'আবেদন - সাইমুম শিল্পীগোষ্ঠী')

@section('content')
<div class="container my-5">
    <!-- Page Header with Modern Design -->
    <div class="text-center mb-5 animate__animated animate__fadeInDown">
        <h1 class="display-4 fw-bold mb-3" style="color: #0A1F44;">আবেদন করুন</h1>
        <p class="lead text-muted mb-4">আমাদের বিভিন্ন কোর্সে ভর্তির জন্য আবেদন করুন</p>
        <div class="underline mx-auto"></div>
    </div>
    
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show shadow-sm rounded-3" role="alert">
            <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif
    
    <!-- Available Forms Section in Table Format -->
    <div class="row">
        <div class="col-12">
            @if(isset($forms) && $forms->count() > 0)
                <div class="card border-0 rounded-4 shadow-sm">
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th scope="col" class="py-4 px-4">ফরমের নাম</th>
                                        <th scope="col" class="py-4 px-4">বর্ণনা</th>
                                        <th scope="col" class="py-4 px-4 text-end">অ্যাকশন</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($forms as $form)
                                        <tr class="animate__animated animate__fadeInUp">
                                            <td class="py-4 px-4 fw-medium">
                                                <div class="d-flex align-items-center">
                                                    <div class="icon-wrapper bg-primary bg-opacity-10 rounded-3 p-2 me-3">
                                                        <i class='bx bx-file fs-5 text-primary'></i>
                                                    </div>
                                                    <span>{{ $form->name }}</span>
                                                </div>
                                            </td>
                                            <td class="py-4 px-4 text-muted">
                                                {{ Illuminate\Support\Str::limit($form->description, 100) }}
                                            </td>
                                            <td class="py-4 px-4 text-end">
                                                <a href="{{ url('forms/' . $form->id) }}" class="btn btn-primary rounded-pill px-4 py-2 fw-medium">
                                                    <i class='bx bx-edit-alt me-1'></i>আবেদন করুন
                                                </a>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            @else
                <div class="card border-0 rounded-4 shadow-sm">
                    <div class="card-body text-center py-5">
                        <div class="icon-wrapper bg-secondary bg-opacity-10 rounded-circle p-4 d-inline-block mb-4">
                            <i class='bx bx-file bx-lg text-secondary'></i>
                        </div>
                        <h5 class="text-muted fw-bold mb-3">এখনও কোন ফরম উপলব্ধ নয়</h5>
                        <p class="text-muted mb-0">দয়া করে পরে আবার চেষ্টা করুন।</p>
                    </div>
                </div>
            @endif
        </div>
    </div>
    
    <!-- Additional Information Section -->
    <div class="row mt-5">
        <div class="col-lg-8 mx-auto">
            <div class="card border-0 rounded-4 shadow-sm">
                <div class="card-body p-4">
                    <h5 class="card-title fw-bold mb-4 text-center">আবেদন প্রক্রিয়া</h5>
                    <div class="row g-4">
                        <div class="col-md-4 text-center">
                            <div class="step-icon bg-primary bg-opacity-10 rounded-circle p-3 mx-auto mb-3">
                                <span class="fw-bold text-primary">1</span>
                            </div>
                            <h6 class="fw-bold">ফরম নির্বাচন</h6>
                            <p class="text-muted small">আপনার পছন্দের ফরম নির্বাচন করুন</p>
                        </div>
                        <div class="col-md-4 text-center">
                            <div class="step-icon bg-primary bg-opacity-10 rounded-circle p-3 mx-auto mb-3">
                                <span class="fw-bold text-primary">2</span>
                            </div>
                            <h6 class="fw-bold">তথ্য প্রদান</h6>
                            <p class="text-muted small">প্রয়োজনীয় তথ্য প্রদান করুন</p>
                        </div>
                        <div class="col-md-4 text-center">
                            <div class="step-icon bg-primary bg-opacity-10 rounded-circle p-3 mx-auto mb-3">
                                <span class="fw-bold text-primary">3</span>
                            </div>
                            <h6 class="fw-bold">জমা দিন</h6>
                            <p class="text-muted small">ফরমটি জমা দিন এবং পরবর্তী ধাপে যান</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .underline {
        width: 80px;
        height: 4px;
        background: linear-gradient(90deg, #4A90E2, #2A5BA0);
        border-radius: 2px;
    }
    
    .card {
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        border: 1px solid rgba(0, 0, 0, 0.05);
    }
    
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1) !important;
    }
    
    .table > :not(caption) > * > * {
        padding: 1rem;
        vertical-align: middle;
    }
    
    .table-hover > tbody > tr:hover {
        background-color: rgba(74, 144, 226, 0.05);
        transform: scale(1.01);
        transition: all 0.2s ease;
    }
    
    .icon-wrapper {
        transition: all 0.3s ease;
    }
    
    .table-hover > tbody > tr:hover .icon-wrapper {
        transform: scale(1.1);
    }
    
    .btn-primary {
        background: linear-gradient(90deg, #2A5BA0, #4A90E2);
        border: none;
        padding: 8px 20px;
        font-weight: 600;
        transition: all 0.3s ease;
    }
    
    .btn-primary:hover {
        background: linear-gradient(90deg, #4A90E2, #2A5BA0);
        transform: translateY(-2px);
        box-shadow: 0 7px 15px rgba(42, 91, 160, 0.3);
    }
    
    .step-icon {
        width: 50px;
        height: 50px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    :root.dark-mode .card {
        background-color: #1e293b;
        border-color: #334155;
    }
    
    :root.dark-mode .table-light {
        background-color: #334155 !important;
        color: #f1f5f9 !important;
    }
    
    :root.dark-mode .table-hover > tbody > tr:hover {
        background-color: rgba(59, 130, 246, 0.1) !important;
    }
    
    :root.dark-mode .btn-primary {
        background: linear-gradient(90deg, #3b82f6, #2563eb);
    }
    
    :root.dark-mode .btn-primary:hover {
        background: linear-gradient(90deg, #2563eb, #3b82f6);
    }
    
    :root.dark-mode .text-muted {
        color: #94a3b8 !important;
    }
    
    /* Staggered animation delays for table rows */
    .animate__fadeInUp:nth-child(1) { animation-delay: 0.1s; }
    .animate__fadeInUp:nth-child(2) { animation-delay: 0.2s; }
    .animate__fadeInUp:nth-child(3) { animation-delay: 0.3s; }
    .animate__fadeInUp:nth-child(4) { animation-delay: 0.4s; }
    .animate__fadeInUp:nth-child(5) { animation-delay: 0.5s; }
    .animate__fadeInUp:nth-child(6) { animation-delay: 0.6s; }
</style>
@endsection