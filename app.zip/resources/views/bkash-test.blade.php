<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>bKash Test Payment</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
</head>
<body>
<h1>bKash Test Payment</h1>
<form id="bkashCreateForm">
    <label>Amount: <input type="number" step="0.01" name="amount" value="100" required></label><br>
    <label>Payer Ref: <input type="text" name="payer_reference" value="TESTUSER"></label><br>
    <button type="submit">Create Payment</button>
</form>

<pre id="output" style="background:#eee;padding:1rem;margin-top:1rem;"></pre>

<script>
const form = document.getElementById('bkashCreateForm');
const out = document.getElementById('output');

form.addEventListener('submit', async (e) => {
    e.preventDefault();
    out.textContent = 'Creating payment...';
    const fd = new FormData(form);
    const payload = Object.fromEntries(fd.entries());
    const res = await fetch('/payment/bkash/create', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
        },
        body: JSON.stringify(payload)
    });
    const data = await res.json();
    out.textContent = JSON.stringify(data, null, 2);
});
</script>
</body>
</html>
