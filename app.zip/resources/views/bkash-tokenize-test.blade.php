<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>bKash Tokenize Test Payment</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
</head>
<body>
<h1>bKash Tokenize Test Payment</h1>
<a href="{{ route('bkash-create-payment') }}">Create Payment</a>

<div id="output" style="background:#eee;padding:1rem;margin-top:1rem;"></div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // You can add additional JavaScript here if needed
});
</script>
</body>
</html>