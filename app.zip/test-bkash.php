<?php

require_once 'vendor/autoload.php';

try {
    // Test if we can access the facade
    echo "Testing bKash facade access...\n";
    
    // This should work if the package is properly installed
    $class = new \Karim007\LaravelBkashTokenize\Facade\BkashPaymentTokenize();
    echo "Facade access successful!\n";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}

try {
    // Test if we can access the service provider
    echo "Testing service provider access...\n";
    
    $provider = new \Karim007\LaravelBkashTokenize\BkashTokenizeServiceProvider(app());
    echo "Service provider access successful!\n";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}