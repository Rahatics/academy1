<?php
// Manually create an admin user
require_once 'vendor/autoload.php';

use Illuminate\Database\Capsule\Manager as Capsule;
use Illuminate\Support\Facades\Hash;

// Configure database connection
$capsule = new Capsule;
$capsule->addConnection([
    'driver'    => 'mysql',
    'host'      => '127.0.0.1',
    'database'  => 'saium_shilpigosthi',
    'username'  => 'root',
    'password'  => '',
    'charset'   => 'utf8',
    'collation' => 'utf8_unicode_ci',
    'prefix'    => '',
]);

$capsule->setAsGlobal();
$capsule->bootEloquent();

echo "Database connection established.\n";

// Check if admins table exists
try {
    $tables = Capsule::select("SHOW TABLES LIKE 'admins'");
    if (empty($tables)) {
        echo "Admins table does not exist! Please run migrations first.\n";
        exit;
    }
    echo "Admins table exists.\n";
    
    // Check if admin already exists
    $existingAdmin = Capsule::table('admins')->where('email', 'admin@saimum.org')->first();
    
    if ($existingAdmin) {
        echo "Admin user already exists with email: " . $existingAdmin->email . "\n";
    } else {
        // Create admin user
        $adminId = Capsule::table('admins')->insertGetId([
            'name' => 'Admin User',
            'email' => 'admin@saimum.org',
            'password' => password_hash('password123', PASSWORD_DEFAULT),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ]);
        
        echo "Admin user created with ID: " . $adminId . "\n";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}