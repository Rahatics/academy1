<?php

require_once 'vendor/autoload.php';

use Illuminate\Container\Container;
use Illuminate\Events\Dispatcher;
use Illuminate\Http\Request;
use Illuminate\Routing\Redirector;
use Illuminate\Routing\UrlGenerator;
use Illuminate\Routing\RouteCollection;
use Illuminate\Routing\Router;
use Illuminate\Config\Repository;
use Karim007\LaravelBkashTokenize\BkashTokenizeServiceProvider;

// Create a Laravel application instance
$app = new Container();
$app->instance('app', $app);

// Bind necessary services
$app->singleton('events', function () {
    return new Dispatcher();
});

$app->singleton('config', function () {
    return new Repository([
        'bkash' => [
            'sandbox' => true,
            'bkash_app_key' => 'test_key',
            'bkash_app_secret' => 'test_secret',
            'bkash_username' => 'test_username',
            'bkash_password' => 'test_password',
            'callbackURL' => 'http://localhost/bkash/callback',
            'timezone' => 'Asia/Dhaka',
        ]
    ]);
});

// Register the service provider
$provider = new BkashTokenizeServiceProvider($app);
$provider->register();

echo "bKash service provider registered successfully!\n";

// Test if we can resolve the payment service
try {
    $paymentService = $app->make('tbpayment');
    echo "Payment service resolved successfully!\n";
    echo "Payment service class: " . get_class($paymentService) . "\n";
} catch (Exception $e) {
    echo "Error resolving payment service: " . $e->getMessage() . "\n";
}