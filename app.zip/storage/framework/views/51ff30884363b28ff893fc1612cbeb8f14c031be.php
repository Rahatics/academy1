

<?php $__env->startSection('title', 'রশিদ ডিজাইন ম্যানেজমেন্ট - অ্যাডমিন প্যানেল'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex align-items-center justify-content-between mb-4">
        <div>
            <h4 class="mb-0">রশিদ ডিজাইন ম্যানেজমেন্ট</h4>
            <p class="text-muted mb-0">পিডিএফ রশিদের ডিজাইন কাস্টমাইজ করুন</p>
        </div>
        <div>
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">হোম</a></li>
                <li class="breadcrumb-item active" aria-current="page">রশিদ ডিজাইন</li>
            </ol>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <!-- Success Message -->
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="bx bx-check-circle me-2"></i>
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bx bx-error-circle me-2"></i>
                            <?php echo e(session('error')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <!-- Instructions -->
                    <div class="alert alert-info">
                        <div class="d-flex align-items-center">
                            <i class="bx bx-info-circle fs-4 me-2"></i>
                            <h5 class="alert-heading mb-0">নির্দেশনা</h5>
                        </div>
                        <ul class="mb-0 mt-2">
                            <li>HTML এবং CSS ব্যবহার করে রশিদের ডিজাইন কাস্টমাইজ করুন</li>
                            <li>নিচের ভেরিয়েবলগুলো ব্যবহার করে ডাটা প্রদর্শন করুন (উদাহরণস্বরূপ):
                                <div class="bg-light p-3 rounded mt-2">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <ul class="mb-0">
                                                <li><code><?php echo e('{'); ?><?php echo e('$application->application_id'); ?><?php echo e('}'); ?></code> - আবেদন আইডি</li>
                                                <li><code><?php echo e('{'); ?><?php echo e('$application->name'); ?><?php echo e('}'); ?></code> - আবেদনকারীর নাম</li>
                                                <li><code><?php echo e('{'); ?><?php echo e('$application->public_application_code'); ?><?php echo e('}'); ?></code> - পাবলিক আবেদন কোড</li>
                                            </ul>
                                        </div>
                                        <div class="col-md-6">
                                            <ul class="mb-0">
                                                <li><code><?php echo e('{'); ?><?php echo e('$application->internal_invoice'); ?><?php echo e('}'); ?></code> - ইনভয়েস নম্বর</li>
                                                <li><code><?php echo e('{'); ?><?php echo e('$application->total_fee'); ?><?php echo e('}'); ?></code> - মোট ফি</li>
                                                <li><code><?php echo e('{'); ?><?php echo e('$application->paid_at'); ?><?php echo e('}'); ?></code> - পেমেন্ট সময়</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li>সেভ করার পর পরিবর্তনগুলো সব রশিদে প্রযোজ্য হবে</li>
                        </ul>
                    </div>

                    <!-- Template Options Section -->
                    <div class="card mb-4 border-primary">
                        <div class="card-header bg-primary bg-opacity-10 border-primary">
                            <div class="d-flex align-items-center">
                                <i class="bx bx-layout fs-4 me-2 text-primary"></i>
                                <h5 class="mb-0 text-primary">টেমপ্লেট অপশন</h5>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="d-flex gap-2 flex-wrap">
                                <?php if($hasCustomTemplate ?? false): ?>
                                <form action="<?php echo e(route('admin.receipt-design.activate')); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-success">
                                        <i class='bx bx-check-circle me-1'></i>কাস্টম টেমপ্লেট সক্রিয় করুন
                                    </button>
                                </form>
                                <?php endif; ?>
                                
                                <?php if($hasEnhancedTemplate ?? false): ?>
                                <form action="<?php echo e(route('admin.receipt-design.activate-enhanced')); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-info">
                                        <i class='bx bx-palette me-1'></i>ভিজ্যুয়ালি এনহান্সড টেমপ্লেট সক্রিয় করুন
                                    </button>
                                </form>
                                <?php endif; ?>
                                
                                <a href="<?php echo e(route('admin.receipt-design.download')); ?>" class="btn btn-secondary">
                                    <i class='bx bx-download me-1'></i>বর্তমান টেমপ্লেট ডাউনলোড করুন
                                </a>
                                
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#uploadModal">
                                    <i class='bx bx-cloud-upload me-1'></i>নতুন টেমপ্লেট আপলোড করুন
                                </button>
                            </div>
                        </div>
                    </div>

                    <form action="<?php echo e(route('admin.receipt-design.update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <div class="d-flex justify-content-between align-items-center">
                                <label for="template_content" class="form-label">রশিদ টেমপ্লেট</label>
                                <div>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" id="formatCode">
                                        <i class='bx bx-code-curly me-1'></i>ফরম্যাট করুন
                                    </button>
                                </div>
                            </div>
                            <textarea 
                                class="form-control font-monospace" 
                                id="template_content" 
                                name="template_content" 
                                rows="20" 
                                required
                                style="font-size: 12px;"
                            ><?php echo e(old('template_content', $templateContent)); ?></textarea>
                        </div>

                        <div class="d-flex justify-content-between">
                            <button type="submit" class="btn btn-primary">
                                <i class='bx bx-save me-1'></i>সেভ করুন
                            </button>
                            
                            <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#previewModal">
                                <i class='bx bx-show me-1'></i>প্রিভিউ
                            </button>
                            
                            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#resetModal">
                                <i class='bx bx-reset me-1'></i>ডিফল্ট ফিরিয়ে আনুন
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Upload Modal -->
<div class="modal fade" id="uploadModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">কাস্টম টেমপ্লেট আপলোড</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('admin.receipt-design.upload')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="custom_template" class="form-label">কাস্টম টেমপ্লেট (HTML ফাইল)</label>
                        <input type="file" class="form-control" id="custom_template" name="custom_template" accept=".html,.htm">
                        <div class="form-text">আপনার সম্পূর্ণ ডিজাইনের HTML ফাইল আপলোড করুন</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">বাতিল</button>
                    <button type="submit" class="btn btn-primary">আপলোড করুন</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Preview Modal -->
<div class="modal fade" id="previewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">রশিদ প্রিভিউ</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="previewContent" style="min-height: 400px;">
                    <p class="text-center text-muted">প্রিভিউ দেখার জন্য টেমপ্লেটটি সেভ করুন</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">বন্ধ করুন</button>
            </div>
        </div>
    </div>
</div>

<!-- Reset Confirmation Modal -->
<div class="modal fade" id="resetModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">নিশ্চিতকরণ</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="text-center mb-3">
                    <i class="bx bx-error-circle text-warning fs-1"></i>
                </div>
                <p class="text-center">আপনি কি নিশ্চিত যে আপনি রশিদ ডিজাইনটি ডিফল্ট অবস্থায় ফেরত আনতে চান?</p>
                <p class="text-muted text-center">এই ক্রিয়াটি বর্তমান ডিজাইনটি মুছে ফেলবে এবং ডিফল্ট ডিজাইন পুনরায় স্থাপন করবে।</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">বাতিল</button>
                <form action="<?php echo e(route('admin.receipt-design.reset')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-danger">ডিফল্ট ফিরিয়ে আনুন</button>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
    #template_content {
        font-family: 'Courier New', monospace;
        font-size: 12px;
        background-color: #f8f9fa;
        border: 1px solid #ced4da;
    }
    
    .alert-info ul {
        padding-left: 20px;
    }
    
    .alert-info ul ul {
        margin-top: 5px;
        margin-bottom: 0;
    }
    
    .alert-info li {
        margin-bottom: 5px;
    }
    
    .alert-info code {
        background-color: #e9ecef;
        padding: 2px 4px;
        border-radius: 3px;
        font-size: 0.9em;
    }
    
    .font-monospace {
        font-family: 'Courier New', monospace !important;
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Preview functionality
        document.querySelector('[data-bs-target="#previewModal"]').addEventListener('click', function() {
            const templateContent = document.getElementById('template_content').value;
            const previewContent = document.getElementById('previewContent');
            
            // Simple preview - in a real implementation, you might want to send this to the server for rendering
            if (templateContent.trim() !== '') {
                previewContent.innerHTML = '<div class="alert alert-info"><strong>টেমপ্লেট কন্টেন্ট:</strong><pre class="mb-0">' + templateContent.substring(0, 1000) + (templateContent.length > 1000 ? '...' : '') + '</pre></div>';
            } else {
                previewContent.innerHTML = '<p class="text-center text-muted">টেমপ্লেটটি খালি আছে</p>';
            }
        });
        
        // Format code button
        document.getElementById('formatCode')?.addEventListener('click', function() {
            const textarea = document.getElementById('template_content');
            let content = textarea.value;
            
            // Simple formatting - add proper indentation
            content = content.replace(/(<[^>]+>)/g, '\n$1\n');
            content = content.replace(/^\s*[\r\n]/gm, '');
            
            textarea.value = content.trim();
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\All Project\1V2\saium-shilpigosthi\resources\views/admin/receipt-design/index.blade.php ENDPATH**/ ?>