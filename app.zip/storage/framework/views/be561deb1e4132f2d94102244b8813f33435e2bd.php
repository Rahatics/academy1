

<?php $__env->startSection('title', 'ফর্মসমূহ - সাইমুম শিল্পীগোষ্ঠী'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex align-items-center mb-4 fade-in">
        <div>
            <h4 class="mb-1">ফর্ম ব্যবস্থাপনা</h4>
            <p class="mb-0 text-muted">সকল ফর্মের তালিকা এবং ব্যবস্থাপনা</p>
        </div>
        <div class="ms-auto d-flex align-items-center">
            <div class="me-3">
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0">
                        <i class='bx bx-search'></i>
                    </span>
                    <input type="text" class="form-control border-start-0" placeholder="ফর্ম অনুসন্ধান..." style="min-width: 200px;">
                </div>
            </div>
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">হোম</a></li>
                <li class="breadcrumb-item active" aria-current="page">ফর্মসমূহ</li>
            </ol>
        </div>
    </div>

    <div class="row">
        <div class="col-12 fade-in">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">সকল ফর্ম</h5>
                    <a href="<?php echo e(route('admin.forms.create')); ?>" class="btn btn-primary">
                        <i class='bx bx-plus me-1'></i>নতুন ফর্ম
                    </a>
                </div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>নাম</th>
                                    <th>বর্ণনা</th>
                                    <th>স্ট্যাটাস</th>
                                    <th>তৈরিকারক</th>
                                    <th>তৈরির তারিখ</th>
                                    <th>অ্যাকশন</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="fade-in">
                                    <td><?php echo e($form->name); ?></td>
                                    <td><?php echo e(Str::limit($form->description, 50)); ?></td>
                                    <td>
                                        <?php if($form->status == 'active'): ?>
                                            <span class="badge bg-success">সক্রিয়</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">নিষ্ক্রিয়</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($form->admin->name ?? 'অজানা'); ?></td>
                                    <td><?php echo e($form->created_at->format('d/m/Y')); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.forms.show', $form)); ?>" class="btn btn-sm btn-primary">
                                            <i class='bx bx-show me-1'></i>দেখুন
                                        </a>
                                        <a href="<?php echo e(route('admin.forms.builder', $form)); ?>" class="btn btn-sm btn-info">
                                            <i class='bx bx-wrench me-1'></i>বিল্ডার
                                        </a>
                                        <a href="<?php echo e(route('admin.forms.edit', $form)); ?>" class="btn btn-sm btn-warning">
                                            <i class='bx bx-edit me-1'></i>সম্পাদনা
                                        </a>
                                        <?php
                                            // Count applications for this form
                                            $applicationCount = $form->applications()->count();
                                        ?>
                                        <a href="<?php echo e(route('admin.applications.index')); ?>?form_id=<?php echo e($form->id); ?>" class="btn btn-sm btn-success">
                                            <i class='bx bx-file me-1'></i>আবেদনসমূহ (<?php echo e($applicationCount); ?>)
                                        </a>
                                        <form action="<?php echo e(route('admin.forms.destroy', $form)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('আপনি কি নিশ্চিত যে আপনি এই ফর্মটি মুছে ফেলতে চান?')">
                                                <i class='bx bx-trash me-1'></i>মুছুন
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-5 fade-in">
                                        <i class='bx bx-file bx-lg text-muted mb-3'></i>
                                        <h5 class="text-muted">কোন ফর্ম পাওয়া যায়নি</h5>
                                        <p class="text-muted mb-0">এখনও কোন ফর্ম তৈরি করা হয়নি।</p>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <?php if($forms->hasPages()): ?>
                    <div class="d-flex justify-content-center mt-4 fade-in">
                        <?php echo e($forms->links()); ?>

                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Add specific animations for forms elements */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .fade-in {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    .fade-in:nth-child(1) { animation-delay: 0.1s; }
    .fade-in:nth-child(2) { animation-delay: 0.2s; }
    .fade-in:nth-child(3) { animation-delay: 0.3s; }
    .fade-in:nth-child(4) { animation-delay: 0.4s; }
    
    /* Ensure table rows have proper fade-in */
    .table tbody tr.fade-in {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    .table tbody tr.fade-in:nth-child(1) { animation-delay: 0.1s; }
    .table tbody tr.fade-in:nth-child(2) { animation-delay: 0.2s; }
    .table tbody tr.fade-in:nth-child(3) { animation-delay: 0.3s; }
    .table tbody tr.fade-in:nth-child(4) { animation-delay: 0.4s; }
    .table tbody tr.fade-in:nth-child(5) { animation-delay: 0.5s; }
    .table tbody tr.fade-in:nth-child(6) { animation-delay: 0.6s; }
    .table tbody tr.fade-in:nth-child(7) { animation-delay: 0.7s; }
    .table tbody tr.fade-in:nth-child(8) { animation-delay: 0.8s; }
    .table tbody tr.fade-in:nth-child(9) { animation-delay: 0.9s; }
    .table tbody tr.fade-in:nth-child(10) { animation-delay: 1.0s; }
    
    /* Dark mode fixes for table data */
    :root.dark-mode .table tbody td {
        color: #f1f5f9 !important;
    }
    
    :root.dark-mode .table thead th {
        color: #f1f5f9 !important;
    }
    
    /* Dark mode fix for empty table cell */
    :root.dark-mode .table tbody tr td[colspan="6"] {
        background-color: #1e293b !important;
    }
    
    /* Hover effect for table rows */
    .table-hover tbody tr {
        transition: all 0.3s ease;
    }
    
    .table-hover tbody tr:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/saimumba/shilpigosthi.com/resources/views/admin/forms/index.blade.php ENDPATH**/ ?>