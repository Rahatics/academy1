<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'সাইমুম শিল্পীগোষ্ঠী'); ?></title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('images/favicon.ico')); ?>">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Google Fonts - Bengali -->
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="সাইমুম শিল্পীগোষ্ঠী" height="50" class="d-inline-block align-text-top">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->is('/') ? 'active' : ''); ?>" href="<?php echo e(url('/')); ?>">হোম</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->is('about') ? 'active' : ''); ?>" href="<?php echo e(route('about')); ?>">আমাদের সম্পর্কে</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->is('notices') ? 'active' : ''); ?>" href="<?php echo e(route('notices')); ?>">নোটিস</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->is('application') ? 'active' : ''); ?>" href="<?php echo e(route('application')); ?>">আবেদন</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->is('application-status') ? 'active' : ''); ?>" href="<?php echo e(route('application-status')); ?>">আবেদনের স্ট্যাটাস</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->is('contact') ? 'active' : ''); ?>" href="<?php echo e(route('contact')); ?>">যোগাযোগ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->is('admin/login') ? 'active' : ''); ?>" href="<?php echo e(route('admin.login')); ?>">সাইন ইন</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5><?php echo e(organization_info('name')); ?></h5>
                    <p><?php echo e(organization_info('mission')); ?></p>
                </div>
                <div class="col-md-6">
                    <h5>যোগাযোগ</h5>
                    <address>
                        <strong>ঠিকানা:</strong> <?php echo e(organization_info('address')); ?><br>
                        <strong>ইমেইল:</strong> <?php echo e(organization_info('email')); ?><br>
                        <strong>ফোন:</strong> <?php echo e(organization_info('phone')); ?>

                    </address>
                </div>
            </div>
            <hr class="bg-light">
            <div class="text-center">
                <p>&copy; <?php echo e(date('Y')); ?> <?php echo e(organization_info('name')); ?>। সকল স্বত্ব সংরক্ষিত।</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH /home/saimumba/shilpigosthi.com/resources/views/layouts/app.blade.php ENDPATH**/ ?>