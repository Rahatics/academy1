<?php $__env->startSection('title', 'আবেদনের পেমেন্ট'); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">পেমেন্ট</h5>
                    <span class="badge bg-light text-dark">কোড: <?php echo e($application->code); ?></span>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h6 class="mb-1">আবেদনকৃত বিষয়</h6>
                            <p class="mb-0"><?php echo e($application->subject->name); ?></p>
                        </div>
                        <div class="text-end">
                            <h6 class="mb-1">পেমেন্টের শেষ সময়</h6>
                            <p class="mb-0 text-danger" id="expiryTime"><?php echo e($application->expires_at->format('d M, Y h:i A')); ?></p>
                            <small class="text-muted" id="countdown"></small>
                        </div>
                    </div>

                    <div class="alert alert-info small mb-4">
                        <strong>নির্দেশনা:</strong> আপনি এখন পেমেন্ট সম্পন্ন করলে আবেদন কোড পাবেন। "পরে দিব" নির্বাচন করলে ২৪ ঘণ্টার মধ্যে পেমেন্ট না দিলে আবেদনটি মুছে যাবে।
                    </div>

                    <?php $gateways = app(\App\Services\PaymentGatewayRegistry::class)->enabled(); ?>
                    <div class="mt-4">
                        <?php
                            $defaultAction = '';
                            if (count($gateways)) {
                                if ($gateways[0] == 'easypay') {
                                    $defaultAction = route('easypay.initiate');
                                } else {
                                    // Onyo gateway-er jonno purono route
                                    $defaultAction = route('forms.payment.pay_now', $application);
                                }
                            }
                        ?>

                        <form method="POST" action="<?php echo e($defaultAction); ?>" id="payNowForm">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">পেমেন্ট মাধ্যম নির্বাচন:</label>
                                <?php if(count($gateways)): ?>
                                    <div class="row g-2">
                                        <?php $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                // PROTTEK GATEWAY-ER JONNO ROUTE DEFINE KORUN
                                                $actionUrl = ($gw == 'easypay') 
                                                            ? route('easypay.initiate') 
                                                            : route('forms.payment.pay_now', $application);
                                            ?>
                                            <div class="col-6 col-md-4">
                                                <div class="gateway-option border rounded p-2 h-100 position-relative">
                                                    <label class="w-100 m-0" style="cursor:pointer;">
                                                        <input class="form-check-input me-2 gateway-radio" 
                                                               type="radio" 
                                                               name="gateway" 
                                                               value="<?php echo e($gw); ?>" 
                                                               data-action="<?php echo e($actionUrl); ?>" 
                                                               <?php if($loop->first): echo 'checked'; endif; ?>>
                                                        <span class="align-middle">
                                                            <?php switch($gw):
                                                                case ('easypay'): ?><strong>Easypay</strong><?php break; ?>
                                                                <?php case ('dummy'): ?><strong>ডেমো</strong><?php break; ?>
                                                                <?php default: ?> <strong><?php echo e(ucfirst($gw)); ?></strong>
                                                            <?php endswitch; ?>
                                                        </span>
                                                    </label>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-warning py-2 mb-0">কোনো সক্রিয় পেমেন্ট গেটওয়ে পাওয়া যায়নি।</div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="d-flex flex-column flex-md-row gap-2 mt-3">
                                <button class="btn btn-success flex-fill" type="submit">
                                    <i class='bx bx-credit-card-alt me-1'></i> এখনই পরিশোধ করুন
                                </button>
                            </form> <!-- Pay Now form ekhane shesh -->

                            <form method="POST" action="<?php echo e(route('forms.payment.pay_later', $application)); ?>" id="payLaterForm" class="flex-fill">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-outline-secondary w-100" type="submit">
                                    <i class='bx bx-time-five me-1'></i> পরে দিব
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .gateway-option {
        transition: all 0.2s;
    }
    .gateway-option:hover {
        border-color: #0d6efd !important;
        box-shadow: 0 0.125rem 0.25rem rgba(13, 110, 253, 0.2);
    }
    .gateway-option input:checked + span {
        color: #0d6efd;
    }
</style>

<script>
    (function(){
        const payNowForm = document.getElementById('payNowForm');
        const gatewayRadios = document.querySelectorAll('.gateway-radio');

        // Update expiry countdown
        const expiryTimeElement = document.getElementById('expiryTime');
        if (expiryTimeElement) {
            const expiryDate = new Date(expiryTimeElement.textContent);
            const countdownElement = document.getElementById('countdown');
            
            function updateCountdown() {
                const now = new Date();
                const diff = expiryDate - now;
                
                if (diff <= 0) {
                    countdownElement.textContent = 'সময় শেষ';
                    countdownElement.className = 'text-danger';
                    return;
                }
                
                const hours = Math.floor(diff / (1000 * 60 * 60));
                const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((diff % (1000 * 60)) / 1000);
                
                countdownElement.textContent = `${hours}ঘণ্টা ${minutes}মিনিট ${seconds}সেকেন্ড`;
            }
            
            updateCountdown();
            setInterval(updateCountdown, 1000);
        }

        // Form action update based on gateway selection
        if(payNowForm && gatewayRadios.length) {
            gatewayRadios.forEach(radio => {
                radio.addEventListener('change', function() {
                    if (this.checked) {
                        const newAction = this.getAttribute('data-action');
                        if (newAction) {
                            payNowForm.setAttribute('action', newAction);
                        }
                    }
                });
            });

            // Add hidden input for application_id if submitting to easypay.initiate
            payNowForm.addEventListener('submit', function(e) {
                const selectedRadio = document.querySelector('.gateway-radio:checked');
                if (selectedRadio && selectedRadio.value === 'easypay') {
                    // Check if application_id is already in the form
                    if (!payNowForm.querySelector('input[name="application_id"]')) {
                        const hiddenInput = document.createElement('input');
                        hiddenInput.setAttribute('type', 'hidden');
                        hiddenInput.setAttribute('name', 'application_id');
                        hiddenInput.setAttribute('value', '<?php echo e($application->id); ?>');
                        payNowForm.appendChild(hiddenInput);
                    }
                }
            });
        }
    })();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/saimumba/shilpigosthi.com/resources/views/forms/payment_decision.blade.php ENDPATH**/ ?>