<?php $__env->startSection('content'); ?>
<div class="app-content">
    <div class="container-fluid">
        <div class="row mb-4">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h1 class="h3 mb-0 fw-bold">Payment Gateways</h1>
                        <p class="mb-0">Manage payment gateway configurations</p>
                    </div>
                    <div>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Payment Gateways</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="row mb-4">
            <div class="col-md-3 col-sm-6 mb-3">
                <div class="stats-card primary">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="stats-info">
                                <h5 class="mb-1"><?php echo e(count($gateways)); ?></h5>
                                <p class="mb-0">Total Gateways</p>
                            </div>
                            <div class="stats-icon">
                                <i class='bx bx-credit-card'></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-3">
                <div class="stats-card success">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="stats-info">
                                <h5 class="mb-1"><?php echo e(count(array_filter($gateways, function($g) { return $g['configured'] && $g['active']; }))); ?></h5>
                                <p class="mb-0">Active Gateways</p>
                            </div>
                            <div class="stats-icon">
                                <i class='bx bx-check-circle'></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-3">
                <div class="stats-card warning">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="stats-info">
                                <h5 class="mb-1"><?php echo e(count(array_filter($gateways, function($g) { return $g['configured'] && !$g['active']; }))); ?></h5>
                                <p class="mb-0">Inactive Gateways</p>
                            </div>
                            <div class="stats-icon">
                                <i class='bx bx-pause-circle'></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-3">
                <div class="stats-card info">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="stats-info">
                                <h5 class="mb-1"><?php echo e(count(array_filter($gateways, function($g) { return !$g['configured']; }))); ?></h5>
                                <p class="mb-0">Not Configured</p>
                            </div>
                            <div class="stats-icon">
                                <i class='bx bx-cog'></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Gateways Grid -->
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-xl-4 col-md-6 mb-4">
                <div class="card h-100 border-0 shadow-sm gateway-card">
                    <div class="card-body d-flex flex-column">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div>
                                <h5 class="card-title mb-1"><?php echo e(ucfirst($g['name'])); ?></h5>
                                <span class="badge 
                                    <?php if($g['configured'] && $g['active']): ?>
                                        bg-success
                                    <?php elseif($g['configured']): ?>
                                        bg-warning
                                    <?php else: ?>
                                        bg-secondary
                                    <?php endif; ?>
                                ">
                                    <?php if($g['configured'] && $g['active']): ?>
                                        Active
                                    <?php elseif($g['configured']): ?>
                                        Inactive
                                    <?php else: ?>
                                        Not Configured
                                    <?php endif; ?>
                                </span>
                                <?php if($g['configured'] && $g['active'] && !$g['valid']): ?>
                                    <span class="badge bg-danger ms-1">
                                        <i class='bx bx-error-circle'></i> Invalid
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="icon-wrapper rounded-circle d-flex align-items-center justify-content-center" 
                                 style="width: 40px; height: 40px;">
                                <?php if($g['name'] === 'easypay'): ?>
                                    <i class='bx bx-credit-card gateway-icon-primary'></i>
                                <?php elseif($g['name'] === 'dummy'): ?>
                                    <i class='bx bx-test-tube gateway-icon-info'></i>
                                <?php else: ?>
                                    <i class='bx bx-credit-card'></i>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="mb-3">
                            <div class="d-flex justify-content-between small mb-1">
                                <span>Configuration</span>
                                <span class="<?php if($g['configured']): ?> text-success <?php else: ?> text-danger <?php endif; ?> configuration-status">
                                    <?php if($g['configured']): ?> Configured <?php else: ?> Not Configured <?php endif; ?>
                                </span>
                            </div>
                            <div class="progress progress-config" style="height: 5px;">
                                <div class="progress-bar 
                                    <?php if($g['configured']): ?> bg-success <?php else: ?> bg-secondary <?php endif; ?>
                                    <?php if($g['configured']): ?> progress-bar-configured <?php else: ?> progress-bar-unconfigured <?php endif; ?>" 
                                    role="progressbar">
                                </div>
                            </div>
                        </div>

                        <?php if($g['configured']): ?>
                        <div class="mb-3 small">
                            <div class="d-flex justify-content-between">
                                <span>Mode:</span>
                                <span class="fw-medium"><?php echo e(ucfirst($g['mode'])); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <div class="mt-auto">
                            <a href="<?php echo e(route('admin.payment-gateways.edit', $g['name'])); ?>" 
                               class="btn btn-outline-primary btn-sm w-100 gateway-btn">
                                <?php if($g['configured']): ?> 
                                    <i class='bx bx-edit-alt me-1'></i> Edit Settings
                                <?php else: ?> 
                                    <i class='bx bx-cog me-1'></i> Configure Gateway
                                <?php endif; ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center py-5">
                        <i class='bx bx-error-circle' style="font-size: 3rem;"></i>
                        <h4 class="mt-3">No Payment Gateways Available</h4>
                        <p>Check your payment configuration in <code>config/payment.php</code></p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Information Section -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-header py-3">
                        <h5 class="mb-0">About Payment Gateways</h5>
                    </div>
                    <div class="card-body">
                        <p class="mb-4">
                            Payment gateways allow applicants to pay fees for their applications. Each gateway can be configured separately.
                        </p>
                        
                        <div class="row g-4">
                            <div class="col-md-4">
                                <div class="d-flex">
                                    <div class="flex-shrink-0 me-3">
                                        <div class="avatar-sm bg-success bg-opacity-25 rounded-circle d-flex align-items-center justify-content-center">
                                            <i class='bx bx-check-circle gateway-icon-success'></i>
                                        </div>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6 class="mb-1">Active</h6>
                                        <p class="mb-0 small">Gateway is configured and enabled for use</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="d-flex">
                                    <div class="flex-shrink-0 me-3">
                                        <div class="avatar-sm bg-warning bg-opacity-25 rounded-circle d-flex align-items-center justify-content-center">
                                            <i class='bx bx-pause-circle gateway-icon-warning'></i>
                                        </div>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6 class="mb-1">Inactive</h6>
                                        <p class="mb-0 small">Gateway is configured but disabled</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="d-flex">
                                    <div class="flex-shrink-0 me-3">
                                        <div class="avatar-sm bg-secondary bg-opacity-25 rounded-circle d-flex align-items-center justify-content-center">
                                            <i class='bx bx-cog gateway-icon-secondary'></i>
                                        </div>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6 class="mb-1">Not Configured</h6>
                                        <p class="mb-0 small">Gateway needs to be configured with credentials</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .icon-wrapper {
        transition: all 0.3s ease;
        background-color: rgba(0, 0, 0, 0.05);
    }
    
    :root.dark-mode .icon-wrapper {
        background-color: rgba(255, 255, 255, 0.1);
    }
    
    .card:hover .icon-wrapper {
        transform: scale(1.1);
    }
    
    .avatar-sm {
        width: 2.5rem;
        height: 2.5rem;
    }
    
    .bg-opacity-25 {
        opacity: 0.25;
    }
    
    .gateway-card {
        transition: all 0.3s ease;
        background-color: var(--card-bg);
        border: 1px solid var(--border-color);
    }
    
    .gateway-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15) !important;
    }
    
    :root.dark-mode .gateway-card:hover {
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.3) !important;
    }
    
    .gateway-btn {
        border-width: 2px;
        transition: all 0.3s ease;
    }
    
    .gateway-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 0.25rem 0.5rem rgba(0, 0, 0, 0.1);
    }
    
    :root.dark-mode .gateway-btn:hover {
        box-shadow: 0 0.25rem 0.5rem rgba(0, 0, 0, 0.2);
    }
    
    .progress-config {
        height: 5px !important;
    }
    
    .progress-bar-configured {
        width: 100% !important;
    }
    
    .progress-bar-unconfigured {
        width: 0% !important;
    }
    
    .card-header {
        background-color: var(--card-bg);
        border-color: var(--border-color);
    }
    
    :root.dark-mode .card-header {
        background-color: var(--card-bg);
        border-color: var(--border-color);
    }
    
    code {
        color: #e83e8c;
        background-color: rgba(0, 0, 0, 0.05);
        padding: 0.2em 0.4em;
        border-radius: 0.25rem;
    }
    
    :root.dark-mode code {
        background-color: rgba(255, 255, 255, 0.1);
        color: #f1f5f9;
    }
    
    .stats-card {
        border: none;
    }
    
    /* Ensure proper text color in dark mode for all elements */
    :root.dark-mode .card-title,
    :root.dark-mode .card-text,
    :root.dark-mode p,
    :root.dark-mode h1,
    :root.dark-mode h2,
    :root.dark-mode h3,
    :root.dark-mode h4,
    :root.dark-mode h5,
    :root.dark-mode h6,
    :root.dark-mode span {
        color: var(--text-color) !important;
    }
    
    :root.dark-mode .text-muted {
        color: var(--text-muted) !important;
    }
    
    /* Fix badge colors in dark mode */
    :root.dark-mode .badge.bg-warning {
        color: #0f172a !important;
    }
    
    :root.dark-mode .badge.bg-secondary {
        color: #0f172a !important;
    }
    
    /* Fix configuration status text in dark mode */
    .configuration-status {
        font-weight: 500;
    }
    
    :root.dark-mode .text-success {
        color: var(--stats-success) !important;
    }
    
    :root.dark-mode .text-danger {
        color: var(--stats-danger) !important;
    }
    
    /* Custom icon colors for better dark mode support */
    .gateway-icon-primary {
        color: var(--primary-color);
    }
    
    .gateway-icon-success {
        color: var(--success-color);
    }
    
    .gateway-icon-info {
        color: var(--info-color);
    }
    
    :root.dark-mode .gateway-icon-primary {
        color: var(--stats-primary);
    }
    
    :root.dark-mode .gateway-icon-success {
        color: var(--stats-success);
    }
    
    :root.dark-mode .gateway-icon-info {
        color: var(--stats-info);
    }
    
    .gateway-icon-warning {
        color: var(--warning-color);
    }
    
    .gateway-icon-secondary {
        color: var(--secondary-color);
    }
    
    :root.dark-mode .gateway-icon-warning {
        color: var(--stats-warning);
    }
    
    :root.dark-mode .gateway-icon-secondary {
        color: var(--text-muted);
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/saimumba/shilpigosthi.com/resources/views/admin/payment-gateways/index.blade.php ENDPATH**/ ?>