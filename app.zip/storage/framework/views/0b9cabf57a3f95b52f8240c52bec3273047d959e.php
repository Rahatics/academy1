<!DOCTYPE html>
<html lang="bn" dir="ltr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'অ্যাডমিন প্যানেল - সাইমুম শিল্পীগোষ্ঠী'); ?></title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <!-- Boxicons -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <!-- Google Fonts - Bengali -->
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Custom styles -->
    <style>
        :root {
            --primary-color: #4a90e2;
            --primary-hover: #3a7bc8;
            --primary-light: #6bace9;
            --primary-dark: #2c5aa0;
            --secondary-color: #6c757d;
            --success-color: #28a745;
            --success-light: #4caf50;
            --info-color: #17a2b8;
            --info-light: #26c6da;
            --warning-color: #ffc107;
            --warning-light: #ffd54f;
            --danger-color: #dc3545;
            --danger-light: #e74c3c;
            --light-color: #f8f9fa;
            --dark-color: #343a40;
            --sidebar-bg: #ffffff;
            --sidebar-width: 280px;
            --header-height: 70px;
            --border-color: #e9ecef;
            --body-bg: #f5f6fa;
            --card-bg: #ffffff;
            --text-color: #212529;
            --text-muted: #6c757d;
            --table-header-bg: rgba(74, 144, 226, 0.05);
            --stats-primary: #4a90e2;
            --stats-warning: #ffc107;
            --stats-success: #28a745;
            --stats-danger: #dc3545;
            --stats-info: #17a2b8;
            --card-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            --card-hover-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
        }

        :root.dark-mode {
            --sidebar-bg: #1e293b;
            --body-bg: #0f172a;
            --card-bg: #1e293b;
            --text-color: #f1f5f9;
            --text-muted: #94a3b8;
            --border-color: #334155;
            --table-header-bg: rgba(74, 144, 226, 0.1);
            --stats-primary: #3b82f6;
            --stats-warning: #f59e0b;
            --stats-success: #10b981;
            --stats-danger: #ef4444;
            --stats-info: #0ea5e9;
            --card-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
            --card-hover-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
        }

        body {
            font-family: 'Hind Siliguri', sans-serif;
            background-color: var(--body-bg);
            color: var(--text-color);
            overflow-x: hidden;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        /* Ensure all text elements use proper color variables */
        h1, h2, h3, h4, h5, h6 {
            color: var(--text-color);
        }

        p {
            color: var(--text-color);
        }

        small {
            color: var(--text-muted);
        }

        /* Smooth scrolling */
        html {
            scroll-behavior: smooth;
        }

        /* Custom scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: rgba(0, 0, 0, 0.05);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--primary-color);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--primary-hover);
        }

        /* Ensure proper text visibility in dark mode */
        :root.dark-mode h1,
        :root.dark-mode h2,
        :root.dark-mode h3,
        :root.dark-mode h4,
        :root.dark-mode h5,
        :root.dark-mode h6 {
            color: #f1f5f9 !important;
        }

        :root.dark-mode p,
        :root.dark-mode span,
        :root.dark-mode div,
        :root.dark-mode a {
            color: #f1f5f9 !important;
        }

        :root.dark-mode small,
        :root.dark-mode .text-muted {
            color: #94a3b8 !important;
        }

        :root.dark-mode .breadcrumb-item.active {
            color: #94a3b8 !important;
        }

        :root.dark-mode .dropdown-item {
            color: #f1f5f9 !important;
        }

        :root.dark-mode .dropdown-item:hover {
            color: var(--primary-color) !important;
        }

        :root.dark-mode .table {
            color: #f1f5f9 !important;
        }

        :root.dark-mode .table thead th {
            color: #f1f5f9 !important;
        }

        :root.dark-mode .table tbody td {
            color: #f1f5f9 !important;
        }

        :root.dark-mode .card-header {
            color: #f1f5f9 !important;
        }

        :root.dark-mode .form-control,
        :root.dark-mode .form-select {
            color: #f1f5f9 !important;
            background-color: #1e293b !important;
        }

        :root.dark-mode .form-control::placeholder {
            color: #94a3b8 !important;
        }

        :root.dark-mode .input-group-text {
            color: #f1f5f9 !important;
            background-color: #1e293b !important;
            border-color: #334155 !important;
        }

        /* Ensure proper icon colors in dark mode */
        :root.dark-mode .bx {
            color: inherit;
        }

        :root.dark-mode .stats-card .bx {
            color: inherit;
        }

        /* More specific icon color fixes for dark mode */
        :root.dark-mode .stats-card .stats-icon .bx {
            color: inherit !important;
        }

        :root.dark-mode .stats-card.primary .stats-icon .bx {
            color: white !important;
        }

        :root.dark-mode .stats-card.warning .stats-icon .bx {
            color: white !important;
        }

        :root.dark-mode .stats-card.success .stats-icon .bx {
            color: white !important;
        }

        :root.dark-mode .stats-card.danger .stats-icon .bx {
            color: white !important;
        }

        /* Sidebar Styles */
        .app-sidebar {
            width: var(--sidebar-width);
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1040;
            background: var(--sidebar-bg);
            border-right: 1px solid var(--border-color);
            transition: all 0.3s ease;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
        }

        .app-sidebar .main-sidebar-header {
            height: var(--header-height);
            display: flex;
            align-items: center;
            padding: 0 1.5rem;
            border-bottom: 1px solid var(--border-color);
        }

        .app-sidebar .main-sidebar-header .header-logo {
            display: flex;
            align-items: center;
            text-decoration: none;
        }

        .app-sidebar .main-sidebar-header .header-logo img {
            height: 35px;
            margin-right: 10px;
            transition: filter 0.3s ease;
        }

        .app-sidebar .main-sidebar-header .header-logo .main-logo {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--primary-color);
            margin: 0;
            transition: color 0.3s ease;
        }

        .sidebar-body {
            height: calc(100vh - var(--header-height));
            overflow-y: auto;
            padding: 1rem 0;
        }

        .sidebar-body .nav-item {
            margin-bottom: 0.25rem;
        }

        .sidebar-body .slide-item {
            padding: 0.85rem 1.5rem;
            display: flex;
            align-items: center;
            text-decoration: none;
            color: var(--text-color);
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
            position: relative;
            overflow: hidden;
            margin: 0 0.75rem;
            border-radius: 8px;
        }

        .sidebar-body .slide-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: var(--primary-color);
            opacity: 0;
            transition: opacity 0.3s ease;
            z-index: -1;
            border-radius: 8px;
        }

        .sidebar-body .slide-item:hover,
        .sidebar-body .slide-item.active {
            background: rgba(74, 144, 226, 0.1);
            color: var(--primary-color);
            border-left: 3px solid var(--primary-color);
        }

        .sidebar-body .slide-item:hover::before {
            opacity: 0.05;
        }

        .sidebar-body .slide-item i {
            margin-right: 12px;
            font-size: 1.1rem;
            width: 20px;
            text-align: center;
            transition: transform 0.3s ease;
        }

        .sidebar-body .slide-item:hover i {
            transform: translateX(3px);
        }

        .sidebar-body .sub-side-menu__item {
            padding: 0.5rem 1.5rem 0.5rem 3rem;
            display: block;
            text-decoration: none;
            color: var(--text-muted);
            transition: all 0.3s ease;
            margin: 0 0.75rem;
            border-radius: 8px;
        }

        .sidebar-body .sub-side-menu__item:hover,
        .sidebar-body .sub-side-menu__item.active {
            color: var(--primary-color);
            background: rgba(74, 144, 226, 0.05);
        }

        /* Main Content */
        .main-content {
            margin-left: var(--sidebar-width);
            transition: all 0.3s ease;
        }

        .main-content.sidebar-collapsed {
            margin-left: 0;
        }

        .main-header {
            height: var(--header-height);
            background: var(--card-bg);
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            padding: 0 1.5rem;
            position: fixed;
            top: 0;
            right: 0;
            left: var(--sidebar-width);
            z-index: 1030;
            transition: all 0.3s ease;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }

        .main-header.sidebar-collapsed {
            left: 0;
        }

        .main-header .header-content {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
        }

        .main-header .header-element {
            display: flex;
            align-items: center;
        }

        .main-header .header-link {
            color: var(--text-color);
            padding: 0.6rem;
            border-radius: 8px;
            transition: all 0.3s ease;
            text-decoration: none;
            display: flex;
            align-items: center;
            margin: 0 0.25rem;
        }

        .main-header .header-link:hover {
            background: rgba(74, 144, 226, 0.1);
            color: var(--primary-color);
            transform: translateY(-2px);
        }

        /* Notification Badge */
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger-color);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 0.7rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* Theme Toggle Button */
        .theme-toggle {
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
            padding: 0.6rem;
            margin: 0 0.5rem;
            transition: all 0.3s ease;
            border-radius: 8px;
            position: relative;
        }

        .theme-toggle:hover {
            background: rgba(74, 144, 226, 0.1);
            color: var(--primary-color);
            transform: rotate(15deg);
        }

        .app-content {
            margin-top: var(--header-height);
            padding: 1.75rem;
            min-height: calc(100vh - var(--header-height));
            transition: all 0.3s ease;
        }

        /* Card Styles */
        .card {
            border: 1px solid var(--border-color);
            border-radius: 12px;
            box-shadow: var(--card-shadow);
            margin-bottom: 1.75rem;
            transition: all 0.3s ease;
            background: var(--card-bg);
            overflow: hidden;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: var(--card-hover-shadow);
        }

        .card-header {
            background: transparent;
            border-bottom: 1px solid var(--border-color);
            padding: 1.25rem 1.5rem;
            font-weight: 600;
            color: var(--text-color);
        }

        .card-body {
            padding: 1.5rem;
        }

        /* Stats Cards */
        .stats-card {
            border-radius: 12px;
            overflow: hidden;
            border: none;
            box-shadow: var(--card-shadow);
            margin-bottom: 1.75rem;
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            background: var(--card-bg);
            position: relative;
        }

        .stats-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--card-hover-shadow);
        }

        .stats-card .card-body {
            padding: 1.75rem;
        }

        .stats-card .stats-icon {
            width: 65px;
            height: 65px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 12px;
            font-size: 1.75rem;
            margin-bottom: 1.25rem;
            transition: all 0.3s ease;
            background: rgba(74, 144, 226, 0.1);
            color: var(--primary-color);
        }

        .stats-card:hover .stats-icon {
            transform: scale(1.1) rotate(5deg);
        }

        .stats-card .stats-info h5 {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.25rem;
            transition: all 0.3s ease;
            color: var(--text-color);
        }

        .stats-card .stats-info p {
            margin-bottom: 0;
            color: var(--text-muted);
            font-size: 1.1rem;
        }

        /* Custom stats card colors */
        .stats-card.primary {
            background: linear-gradient(135deg, var(--stats-primary), var(--primary-light));
        }

        .stats-card.warning {
            background: linear-gradient(135deg, var(--stats-warning), var(--warning-light));
        }

        .stats-card.success {
            background: linear-gradient(135deg, var(--stats-success), var(--success-light));
        }

        .stats-card.danger {
            background: linear-gradient(135deg, var(--stats-danger), var(--danger-light));
        }

        .stats-card.info {
            background: linear-gradient(135deg, var(--stats-info), var(--info-light));
        }

        /* Text color fixes for stats cards in both light and dark modes */
        .stats-card.primary .stats-info h5,
        .stats-card.primary .stats-info p,
        .stats-card.warning .stats-info h5,
        .stats-card.warning .stats-info p,
        .stats-card.success .stats-info h5,
        .stats-card.success .stats-info p,
        .stats-card.danger .stats-info h5,
        .stats-card.danger .stats-info p,
        .stats-card.info .stats-info h5,
        .stats-card.info .stats-info p {
            color: white !important;
        }

        .stats-card.primary .stats-icon,
        .stats-card.warning .stats-icon,
        .stats-card.success .stats-icon,
        .stats-card.danger .stats-icon,
        .stats-card.info .stats-icon {
            background: rgba(255, 255, 255, 0.2) !important;
            color: white !important;
        }

        /* Dark mode specific fixes for stats cards */
        :root.dark-mode .stats-card .stats-info h5,
        :root.dark-mode .stats-card .stats-info p {
            color: white !important;
        }

        /* Fix for icon colors in dark mode - maintain proper contrast */
        :root.dark-mode .stats-card .stats-icon {
            background: rgba(74, 144, 226, 0.2) !important;
            color: #3b82f6 !important;
        }

        :root.dark-mode .stats-card.primary .stats-icon {
            background: rgba(255, 255, 255, 0.2) !important;
            color: white !important;
        }

        :root.dark-mode .stats-card.warning .stats-icon {
            background: rgba(255, 255, 255, 0.2) !important;
            color: white !important;
        }

        :root.dark-mode .stats-card.success .stats-icon {
            background: rgba(255, 255, 255, 0.2) !important;
            color: white !important;
        }

        :root.dark-mode .stats-card.danger .stats-icon {
            background: rgba(255, 255, 255, 0.2) !important;
            color: white !important;
        }

        :root.dark-mode .stats-card.info .stats-icon {
            background: rgba(255, 255, 255, 0.2) !important;
            color: white !important;
        }

        /* Table Styles */
        .table {
            margin-bottom: 0;
            color: var(--text-color);
        }

        .table thead th {
            border-top: none;
            font-weight: 600;
            color: var(--text-color);
            background: var(--table-header-bg);
            padding: 1rem 1.25rem;
        }

        .table tbody td {
            padding: 1rem 1.25rem;
            color: var(--text-color);
        }

        .table-hover tbody tr:hover {
            background-color: rgba(74, 144, 226, 0.05);
            transform: scale(1.01);
            transition: all 0.2s ease;
        }

        /* Dark mode table fixes */
        :root.dark-mode .table {
            color: #f1f5f9 !important;
        }

        :root.dark-mode .table thead th {
            color: #f1f5f9 !important;
        }

        :root.dark-mode .table tbody td {
            color: #f1f5f9 !important;
        }

        :root.dark-mode .table-hover tbody tr:hover {
            background-color: rgba(59, 130, 246, 0.1) !important;
        }

        /* Dark mode fix for table cell backgrounds */
        :root.dark-mode .table tbody tr {
            background-color: #1e293b !important;
        }

        :root.dark-mode .table tbody tr td {
            background-color: #1e293b !important;
        }

        /* Badge Styles */
        .badge {
            padding: 0.5em 0.85em;
            font-weight: 500;
            border-radius: 6px;
        }

        .badge.bg-primary {
            background: var(--primary-color);
        }

        .badge.bg-success {
            background: var(--success-color);
        }

        .badge.bg-warning {
            background: var(--warning-color);
            color: white;
        }

        .badge.bg-danger {
            background: var(--danger-color);
        }

        .badge.bg-info {
            background: var(--info-color);
        }

        .badge.bg-secondary {
            background: var(--secondary-color);
        }

        /* Dark mode badge adjustments */
        :root.dark-mode .badge.bg-warning {
            background: var(--stats-warning);
            color: #0f172a;
        }

        :root.dark-mode .badge.bg-success {
            background: var(--stats-success);
            color: #0f172a;
        }

        .stats-card.primary .stats-info h5,
        .stats-card.primary .stats-info p,
        .stats-card.warning .stats-info h5,
        .stats-card.warning .stats-info p,
        .stats-card.success .stats-info h5,
        .stats-card.success .stats-info p,
        .stats-card.danger .stats-info h5,
        .stats-card.danger .stats-info p {
            color: white;
        }

        .stats-card.primary .stats-icon,
        .stats-card.warning .stats-icon,
        .stats-card.success .stats-icon,
        .stats-card.danger .stats-icon {
            background: rgba(255, 255, 255, 0.2);
            color: white;
        }

        /* Additional dark mode fixes for badges */
        :root.dark-mode .badge.bg-danger {
            background: var(--stats-danger);
            color: #0f172a;
        }

        :root.dark-mode .badge.bg-primary {
            background: var(--stats-primary);
            color: white;
        }

        :root.dark-mode .badge.bg-info {
            background: var(--info-light);
            color: #0f172a;
        }

        :root.dark-mode .badge.bg-secondary {
            background: var(--text-muted);
            color: #0f172a;
        }

        /* Button Styles */
        .btn {
            border-radius: 8px;
            padding: 0.6rem 1.25rem;
            font-weight: 500;
            transition: all 0.3s ease;
            border: none;
            position: relative;
            overflow: hidden;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s;
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn-primary {
            background: var(--primary-color);
            border-color: var(--primary-color);
            box-shadow: 0 4px 15px rgba(74, 144, 226, 0.3);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-hover);
            border-color: var(--primary-hover);
            transform: translateY(-3px);
            box-shadow: 0 7px 20px rgba(74, 144, 226, 0.4);
        }

        .btn-outline-primary {
            border: 2px solid var(--primary-color);
            color: var(--primary-color);
        }

        .btn-outline-primary:hover {
            background: var(--primary-color);
            color: white;
            transform: translateY(-3px);
            box-shadow: 0 7px 20px rgba(74, 144, 226, 0.4);
        }

        /* Form Styles */
        .form-control, .form-select {
            border-radius: 8px;
            border: 2px solid var(--border-color);
            padding: 0.85rem 1.25rem;
            transition: all 0.3s ease;
            background: var(--card-bg);
            color: var(--text-color);
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(74, 144, 226, 0.25);
        }

        /* Breadcrumb */
        .breadcrumb {
            background: transparent;
            padding: 0;
            margin: 0;
        }

        .breadcrumb-item a {
            color: var(--primary-color);
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .breadcrumb-item a:hover {
            color: var(--primary-hover);
            text-decoration: underline;
        }

        .breadcrumb-item.active {
            color: var(--text-muted);
        }

        /* Responsive Improvements */
        @media (max-width: 1400px) {
            .stats-card .stats-info h5 {
                font-size: 1.75rem;
            }

            .stats-card .card-body {
                padding: 1.5rem;
            }
        }

        @media (max-width: 1200px) {
            :root {
                --sidebar-width: 250px;
            }

            .stats-card .stats-info h5 {
                font-size: 1.5rem;
            }

            .app-content {
                padding: 1.5rem;
            }
        }

        @media (max-width: 992px) {
            .app-sidebar {
                transform: translateX(-100%);
            }

            .app-sidebar.show {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
            }

            .main-header {
                left: 0;
            }

            .app-content {
                padding: 1.25rem;
            }

            :root {
                --sidebar-width: 280px;
            }

            .stats-card .stats-info h5 {
                font-size: 1.75rem;
            }
        }

        /* Sidebar collapsed state for desktop */
        .app-sidebar.collapsed {
            transform: translateX(-100%);
        }

        @media (max-width: 768px) {
            .main-header .header-content {
                flex-wrap: wrap;
            }

            .main-header .header-element:last-child {
                margin-top: 0.5rem;
                width: 100%;
                justify-content: flex-end;
            }

            .app-content {
                padding: 1rem;
            }

            .stats-card .card-body {
                padding: 1.25rem;
            }

            .stats-card .stats-info h5 {
                font-size: 1.5rem;
            }
        }

        @media (max-width: 576px) {
            .app-sidebar .main-sidebar-header {
                padding: 0 1rem;
            }

            .sidebar-body .slide-item {
                padding: 0.75rem 1rem;
            }

            .main-header {
                padding: 0 1rem;
                height: 60px;
            }

            :root {
                --header-height: 60px;
            }

            .app-content {
                padding: 0.75rem;
            }

            .card-header {
                padding: 1rem;
            }

            .card-body {
                padding: 1rem;
            }

            .stats-card .card-body {
                padding: 1rem;
            }

            .stats-card .stats-info h5 {
                font-size: 1.25rem;
            }

            .stats-card .stats-icon {
                width: 50px;
                height: 50px;
                font-size: 1.25rem;
                margin-bottom: 0.75rem;
            }
        }

        /* Sidebar collapsed state for desktop */
        .app-sidebar.collapsed {
            transform: translateX(-100%);
        }

        /* Toggle Button */
        .sidebar-toggle {
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
            padding: 0.6rem;
            margin-right: 1rem;
            transition: all 0.3s ease;
            border-radius: 8px;
        }

        .sidebar-toggle:hover {
            background: rgba(74, 144, 226, 0.1);
            color: var(--primary-color);
            transform: rotate(90deg);
        }

        /* Custom Modern Cursor */
        #custom-cursor {
            position: fixed;
            width: 20px;
            height: 20px;
            pointer-events: none;
            z-index: 9999;
            transition: transform 0.1s ease, opacity 0.3s ease;
            mix-blend-mode: difference;
        }

        .cursor-dot {
            position: absolute;
            width: 6px;
            height: 6px;
            background-color: #ffffff;
            border-radius: 50%;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            transition: all 0.2s ease;
        }

        .cursor-ring {
            position: absolute;
            width: 20px;
            height: 20px;
            border: 2px solid rgba(255, 255, 255, 0.7);
            border-radius: 50%;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            transition: all 0.2s ease;
        }

        /* Dark mode cursor previously turned black (hard to see on dark bg).
           Keep high contrast (white dot / accent ring) for visibility. */
        .cursor-dot.dark-mode {
            background-color: #ffffff !important;
        }
        .cursor-ring.dark-mode {
            border-color: rgba(59, 130, 246, 0.85) !important; /* Tailwind-ish blue */
        }
        /* Improve visibility on both themes: when hovering interactive elements, accent color. */
        .cursor-hover .cursor-ring.dark-mode {
            border-color: rgba(74, 144, 226, 0.95) !important;
        }

        .cursor-hover .cursor-dot {
            transform: translate(-50%, -50%) scale(0);
        }

        .cursor-hover .cursor-ring {
            transform: translate(-50%, -50%) scale(1.5);
            border-color: rgba(74, 144, 226, 0.8);
        }

        .cursor-grab .cursor-ring {
            transform: translate(-50%, -50%) scale(1.2);
            border-style: dashed;
        }

        .cursor-grabbing .cursor-ring {
            transform: translate(-50%, -50%) scale(1.2) rotate(90deg);
            border-style: dashed;
            border-color: rgba(255, 100, 100, 0.8);
        }

        /* Hide default cursor (global) but re-enable native cursor where better UX is required. */
        * {
            cursor: none !important;
        }
        input, textarea, select, .form-control, .form-select {
            cursor: text !important;
            caret-color: var(--primary-color);
        }
        button, a, .btn, [role="button"], .sidebar-toggle, .theme-toggle, .slide-item {
            cursor: pointer !important;
        }

        /* Loading animation */
        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.5; }
            100% { opacity: 1; }
        }

        .loading {
            animation: pulse 1.5s infinite;
        }

        /* Fade in animation */
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .fade-in {
            animation: fadeInUp 0.6s ease forwards;
        }

        .fade-in:nth-child(1) { animation-delay: 0.1s; }
        .fade-in:nth-child(2) { animation-delay: 0.2s; }
        .fade-in:nth-child(3) { animation-delay: 0.3s; }
        .fade-in:nth-child(4) { animation-delay: 0.4s; }

        /* User Profile Dropdown */
        .dropdown-menu {
            border-radius: 12px;
            border: 1px solid var(--border-color);
            box-shadow: var(--card-shadow);
            background: var(--card-bg);
            padding: 0.5rem 0;
        }

        .dropdown-item {
            padding: 0.75rem 1.25rem;
            color: var(--text-color);
            transition: all 0.2s ease;
        }

        .dropdown-item:hover {
            background: rgba(74, 144, 226, 0.1);
            color: var(--primary-color);
        }

        .dropdown-item i {
            margin-right: 0.75rem;
            width: 20px;
            text-align: center;
        }

        /* Header User Profile */
        .user-profile {
            display: flex;
            align-items: center;
            padding: 0.25rem;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .user-profile:hover {
            background: rgba(74, 144, 226, 0.1);
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            margin-right: 0.75rem;
        }

        .user-info {
            text-align: left;
        }

        .user-name {
            font-weight: 600;
            margin: 0;
            font-size: 0.95rem;
        }

        .user-role {
            font-size: 0.8rem;
            color: var(--text-muted);
            margin: 0;
        }

        /* Improved mobile menu button */
        @media (max-width: 992px) {
            .sidebar-toggle {
                z-index: 1050;
            }
        }
    </style>

    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
    <!-- Sidebar -->
    <div class="app-sidebar">
        <div class="main-sidebar-header">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="header-logo">
                <?php if(file_exists(public_path('images/logo.png'))): ?>
                    <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo">
                <?php endif; ?>
                <span class="main-logo">সাইমুম শিল্পীগোষ্ঠী</span>
            </a>
        </div>
        <div class="sidebar-body">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="slide-item <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('admin.dashboard')); ?>">
                        <i class='bx bx-home-alt'></i>
                        <span>ড্যাশবোর্ড</span>
                    </a>
                </li>
                
                <!-- Application Management -->
                <li class="nav-item mt-3">
                    <div class="px-4 py-3 text-uppercase small fw-bold text-muted" style="font-size: 0.7rem; letter-spacing: 1px;">Application Management</div>
                </li>
                <li class="nav-item">
                    <a class="slide-item <?php echo e(request()->routeIs('admin.applications.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.applications.index')); ?>">
                        <i class='bx bx-file'></i>
                        <span>আবেদনসমূহ</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="slide-item <?php echo e(request()->routeIs('admin.forms.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.forms.index')); ?>">
                        <i class='bx bx-spreadsheet'></i>
                        <span>ফর্মসমূহ</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="slide-item <?php echo e(request()->routeIs('admin.subjects.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.subjects.index')); ?>">
                        <i class='bx bx-book'></i>
                        <span>বিষয়সমূহ</span>
                    </a>
                </li>
                
                <!-- Financial Management -->
                <li class="nav-item mt-3">
                    <div class="px-4 py-3 text-uppercase small fw-bold text-muted" style="font-size: 0.7rem; letter-spacing: 1px;">Financial Management</div>
                </li>
                <li class="nav-item">
                    <a class="slide-item <?php echo e(request()->routeIs('admin.payments.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.payments.index')); ?>">
                        <i class='bx bx-credit-card'></i>
                        <span>পেমেন্টসমূহ</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="slide-item <?php echo e(request()->routeIs('admin.payment-gateways.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.payment-gateways.index')); ?>">
                        <i class='bx bx-plug'></i>
                        <span>গেটওয়ে সেটিংস</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="slide-item <?php echo e(request()->routeIs('admin.receipt-design.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.receipt-design.index')); ?>">
                        <i class='bx bx-receipt'></i>
                        <span>রশিদ ডিজাইন</span>
                    </a>
                </li>
                
                <!-- Student Management -->
                <li class="nav-item mt-3">
                    <div class="px-4 py-3 text-uppercase small fw-bold text-muted" style="font-size: 0.7rem; letter-spacing: 1px;">Student Management</div>
                </li>
                <li class="nav-item">
                    <a class="slide-item" href="#">
                        <i class='bx bx-group'></i>
                        <span>ওয়ার্কশপ শিক্ষার্থী</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="slide-item" href="#">
                        <i class='bx bx-user'></i>
                        <span>রেগুলার শিক্ষার্থী</span>
                    </a>
                </li>
                
                <!-- System Configuration -->
                <li class="nav-item mt-3">
                    <div class="px-4 py-3 text-uppercase small fw-bold text-muted" style="font-size: 0.7rem; letter-spacing: 1px;">System Configuration</div>
                </li>
                <li class="nav-item">
                    <a class="slide-item <?php echo e(request()->routeIs('admin.settings.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.settings.index')); ?>">
                        <i class='bx bx-cog'></i>
                        <span>সেটিংস</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="slide-item <?php echo e(request()->routeIs('admin.users.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.users.index')); ?>">
                        <i class='bx bx-user-circle'></i>
                        <span>ইউজার ম্যানেজমেন্ট</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="main-header">
            <div class="header-content">
                <div class="header-element">
                    <button class="sidebar-toggle" id="sidebarToggle">
                        <i class='bx bx-menu'></i>
                    </button>
                </div>
                <div class="header-element">
                    <!-- Notifications Dropdown -->
                    <div class="dropdown me-2">
                        <a href="#" class="header-link position-relative" role="button" data-bs-toggle="dropdown">
                            <i class='bx bx-bell bx-sm'></i>
                            <span class="notification-badge">3</span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-lg">
                            <li>
                                <div class="dropdown-header d-flex justify-content-between align-items-center">
                                    <h6 class="mb-0">বিজ্ঞপ্তি</h6>
                                    <span class="badge bg-primary">৩ নতুন</span>
                                </div>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item" href="#">
                                    <div class="d-flex">
                                        <div class="flex-shrink-0">
                                            <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;">
                                                <i class='bx bx-file text-white'></i>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <h6 class="mb-1">নতুন আবেদন জমা হয়েছে</h6>
                                            <p class="mb-0 text-muted small">জনাব আবদুল হামিদ একটি নতুন আবেদন জমা দিয়েছেন</p>
                                            <small class="text-muted">২ মিনিট আগে</small>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="#">
                                    <div class="d-flex">
                                        <div class="flex-shrink-0">
                                            <div class="bg-success rounded-circle d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;">
                                                <i class='bx bx-check-circle text-white'></i>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <h6 class="mb-1">আবেদন অনুমোদিত</h6>
                                            <p class="mb-0 text-muted small">জনাব মোস্তফিজুর রহমান-এর আবেদন অনুমোদিত হয়েছে</p>
                                            <small class="text-muted">১ ঘন্টা আগে</small>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="#">
                                    <div class="d-flex">
                                        <div class="flex-shrink-0">
                                            <div class="bg-warning rounded-circle d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;">
                                                <i class='bx bx-time text-white'></i>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <h6 class="mb-1">আবেদন পর্যালোচনাধীন</h6>
                                            <p class="mb-0 text-muted small">জনাব আলমগীর হোসেন-এর আবেদন পর্যালোচনাধীন</p>
                                            <small class="text-muted">৩ ঘন্টা আগে</small>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item text-center" href="#">
                                    <span>সব বিজ্ঞপ্তি দেখুন</span>
                                </a>
                            </li>
                        </ul>
                    </div>

                    <button class="theme-toggle" id="themeToggle">
                        <i class='bx bx-sun' id="themeIcon"></i>
                    </button>
                    <div class="dropdown">
                        <a href="#" class="header-link user-profile" role="button" data-bs-toggle="dropdown">
                            <div class="user-avatar">
                                <i class='bx bx-user'></i>
                            </div>
                            <div class="user-info">
                                <p class="user-name">অ্যাডমিন</p>
                                <p class="user-role">প্রশাসক</p>
                            </div>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <a class="dropdown-item" href="#">
                                    <i class='bx bx-user-circle'></i>প্রোফাইল
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="#">
                                    <i class='bx bx-cog'></i>সেটিংস
                                </a>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('admin.logout')); ?>"
                                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                    <i class='bx bx-log-out'></i>লগআউট
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- Content -->
        <div class="app-content">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    <!-- Logout Form -->
    <form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST" class="d-none">
        <?php echo csrf_field(); ?>
    </form>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Check for saved sidebar state
        document.addEventListener('DOMContentLoaded', function() {
            // Check if sidebar was previously collapsed
            if (localStorage.getItem('sidebarCollapsed') === 'true' && window.innerWidth >= 992) {
                const sidebar = document.querySelector('.app-sidebar');
                const mainContent = document.querySelector('.main-content');
                const mainHeader = document.querySelector('.main-header');
                if (sidebar) {
                    sidebar.classList.add('collapsed');
                }
                if (mainContent) {
                    mainContent.style.marginLeft = '0';
                }
                if (mainHeader) {
                    mainHeader.classList.add('sidebar-collapsed');
                }
            }
        });

        // Create custom cursor
        function createCustomCursor() {
            // Check if cursor already exists
            if (document.getElementById('custom-cursor')) {
                return;
            }

            // Create cursor elements
            const cursor = document.createElement('div');
            cursor.id = 'custom-cursor';

            const cursorDot = document.createElement('div');
            cursorDot.className = 'cursor-dot';

            const cursorRing = document.createElement('div');
            cursorRing.className = 'cursor-ring';

            cursor.appendChild(cursorDot);
            cursor.appendChild(cursorRing);
            document.body.appendChild(cursor);

            // Update cursor position
            document.addEventListener('mousemove', (e) => {
                if (cursor) {
                    cursor.style.left = e.clientX + 'px';
                    cursor.style.top = e.clientY + 'px';
                }
            });

            // Add hover effects
            const interactiveElements = document.querySelectorAll('a, button, .btn, .sidebar-toggle, .theme-toggle, .slide-item, input, textarea, select');
            interactiveElements.forEach(el => {
                el.addEventListener('mouseenter', () => {
                    if (cursor) {
                        cursor.classList.add('cursor-hover');
                    }
                });

                el.addEventListener('mouseleave', () => {
                    if (cursor) {
                        cursor.classList.remove('cursor-hover');
                    }
                });
            });

            // Add grab effects
            const draggableElements = document.querySelectorAll('.draggable-element, .draggable-template');
            draggableElements.forEach(el => {
                el.addEventListener('mousedown', () => {
                    if (cursor) {
                        cursor.classList.add('cursor-grabbing');
                    }
                });

                el.addEventListener('mouseup', () => {
                    if (cursor) {
                        cursor.classList.remove('cursor-grabbing');
                    }
                });
            });

            // Update cursor for dark mode
            function updateCursorForTheme() {
                const isDarkMode = document.documentElement.classList.contains('dark-mode');
                if (cursorDot && cursorRing) {
                    if (isDarkMode) {
                        cursorDot.classList.add('dark-mode');
                        cursorRing.classList.add('dark-mode');
                    } else {
                        cursorDot.classList.remove('dark-mode');
                        cursorRing.classList.remove('dark-mode');
                    }
                }
            }

            // Update cursor when theme changes
            const themeToggle = document.getElementById('themeToggle');
            if (themeToggle) {
                const originalToggleTheme = toggleTheme;
                toggleTheme = function() {
                    originalToggleTheme();
                    setTimeout(updateCursorForTheme, 10);
                };
            }

            // Initialize cursor theme
            updateCursorForTheme();

            // Make cursor visible initially
            cursor.style.opacity = '1';
        }

        // Create cursor when DOM is loaded
        document.addEventListener('DOMContentLoaded', createCustomCursor);

        // Recreate cursor if it gets removed for any reason
        document.addEventListener('mousemove', function() {
            if (!document.getElementById('custom-cursor')) {
                setTimeout(createCustomCursor, 100);
            }
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Sidebar toggle
        document.addEventListener('DOMContentLoaded', function() {
            const sidebarToggle = document.getElementById('sidebarToggle');
            const sidebar = document.querySelector('.app-sidebar');
            const mainContent = document.querySelector('.main-content');

            if (sidebarToggle && sidebar) {
                sidebarToggle.addEventListener('click', function() {
                    // Check if we're on mobile or desktop
                    if (window.innerWidth < 992) {
                        // Mobile behavior - toggle show class
                        sidebar.classList.toggle('show');
                        // Reset rotation for mobile
                        this.style.transform = 'rotate(0deg)';
                    } else {
                        // Desktop behavior - toggle collapsed class
                        sidebar.classList.toggle('collapsed');
                        // Also adjust main content margin
                        const mainHeader = document.querySelector('.main-header');
                        if (mainContent) {
                            if (sidebar.classList.contains('collapsed')) {
                                mainContent.style.marginLeft = '0';
                                if (mainHeader) {
                                    mainHeader.classList.add('sidebar-collapsed');
                                }
                                // Save state
                                localStorage.setItem('sidebarCollapsed', 'true');
                            } else {
                                mainContent.style.marginLeft = 'var(--sidebar-width)';
                                if (mainHeader) {
                                    mainHeader.classList.remove('sidebar-collapsed');
                                }
                                // Save state
                                localStorage.setItem('sidebarCollapsed', 'false');
                            }
                        }
                        // Add rotation animation for desktop
                        this.style.transform = this.style.transform === 'rotate(90deg)' ? 'rotate(0deg)' : 'rotate(90deg)';
                    }
                });
            }
        });

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(event) {
            const sidebar = document.querySelector('.app-sidebar');
            const toggle = document.getElementById('sidebarToggle');

            if (sidebar && toggle && window.innerWidth < 992 &&
                sidebar.classList.contains('show') &&
                !sidebar.contains(event.target) &&
                event.target !== toggle) {
                sidebar.classList.remove('show');
                // Reset toggle rotation
                toggle.style.transform = 'rotate(0deg)';
            }
        });

        // Handle window resize
        window.addEventListener('resize', function() {
            const sidebar = document.querySelector('.app-sidebar');
            const mainContent = document.querySelector('.main-content');
            const mainHeader = document.querySelector('.main-header');
            const sidebarToggle = document.getElementById('sidebarToggle');

            if (sidebar && mainContent && mainHeader) {
                if (window.innerWidth < 992) {
                    // Mobile view - remove collapsed class if present
                    if (sidebar.classList.contains('collapsed')) {
                        sidebar.classList.remove('collapsed');
                        mainContent.style.marginLeft = '';
                        mainHeader.classList.remove('sidebar-collapsed');
                        if (sidebarToggle) {
                            sidebarToggle.style.transform = 'rotate(0deg)';
                        }
                    }
                } else {
                    // Desktop view - restore saved state
                    const isCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
                    if (isCollapsed) {
                        sidebar.classList.add('collapsed');
                        mainContent.style.marginLeft = '0';
                        mainHeader.classList.add('sidebar-collapsed');
                    } else {
                        sidebar.classList.remove('collapsed');
                        mainContent.style.marginLeft = 'var(--sidebar-width)';
                        mainHeader.classList.remove('sidebar-collapsed');
                    }
                }
            }
        });

        // Theme toggle
        function toggleTheme() {
            const root = document.documentElement;
            const isDark = root.classList.contains('dark-mode');

            if (isDark) {
                root.classList.remove('dark-mode');
                localStorage.setItem('theme', 'light');
                document.getElementById('themeIcon').className = 'bx bx-sun';
            } else {
                root.classList.add('dark-mode');
                localStorage.setItem('theme', 'dark');
                document.getElementById('themeIcon').className = 'bx bx-moon';
            }

            // Add animation
            const themeToggle = document.getElementById('themeToggle');
            themeToggle.style.transform = 'rotate(360deg)';
            setTimeout(() => {
                themeToggle.style.transform = '';
            }, 300);
        }

        // Load saved theme with better error handling
        document.addEventListener('DOMContentLoaded', function() {
            // Add a small delay to ensure all elements are loaded
            setTimeout(function() {
                try {
                    const savedTheme = localStorage.getItem('theme');
                    const root = document.documentElement;

                    if (savedTheme === 'dark') {
                        root.classList.add('dark-mode');
                        document.getElementById('themeIcon').className = 'bx bx-moon';
                    } else {
                        root.classList.remove('dark-mode');
                        document.getElementById('themeIcon').className = 'bx bx-sun';
                    }
                } catch (e) {
                    console.log('Error loading theme preference');
                }
            }, 10);
        });

        // Add event listener to theme toggle
        document.addEventListener('DOMContentLoaded', function() {
            const themeToggle = document.getElementById('themeToggle');
            if (themeToggle) {
                themeToggle.addEventListener('click', toggleTheme);
            }
        });

        // Add fade-in animation to cards and other elements
        document.addEventListener('DOMContentLoaded', function() {
            // Add fade-in to cards and stats cards
            const cards = document.querySelectorAll('.card, .stats-card');
            cards.forEach((card, index) => {
                if (!card.classList.contains('fade-in')) {
                    card.classList.add('fade-in');
                }
            });

            // Add fade-in to table rows if not already present
            const tableRows = document.querySelectorAll('tbody tr');
            tableRows.forEach((row, index) => {
                if (!row.classList.contains('fade-in')) {
                    row.classList.add('fade-in');
                }
            });

            // Add fade-in to other elements that might not have it
            const fadeElements = document.querySelectorAll('.fade-in-element');
            fadeElements.forEach((element, index) => {
                if (!element.classList.contains('fade-in')) {
                    element.classList.add('fade-in');
                }
            });
        });
    </script>

    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH /home/saimumba/shilpigosthi.com/resources/views/admin/layouts/app.blade.php ENDPATH**/ ?>