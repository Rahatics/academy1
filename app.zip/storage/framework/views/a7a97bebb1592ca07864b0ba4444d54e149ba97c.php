

<?php $__env->startSection('title', 'হোম - সাইমুম শিল্পীগোষ্ঠী'); ?>

<?php $__env->startSection('content'); ?>
<div class="hero-section">
    <div class="container text-center">
        <h1 class="display-4 animate__animated animate__fadeInDown">সাইমুম শিল্পীগোষ্ঠী</h1>
        <p class="lead animate__animated animate__fadeInUp"><?php echo e(organization_info('mission')); ?></p>
        <div class="mt-4 animate__animated animate__fadeIn">
            <a href="<?php echo e(route('application')); ?>" class="btn btn-primary btn-lg me-3">সদস্য হন</a>
            <a href="<?php echo e(route('about')); ?>" class="btn btn-outline-light btn-lg">আমাদের সম্পর্কে</a>
        </div>
    </div>
</div>

<div class="container my-5">
    <div class="row">
        <div class="col-lg-8">
            <h2 class="section-title">স্বাগতম</h2>
            <p class="lead">
                <?php echo e(organization_info('name')); ?> বাংলাদেশের একটি প্রতিষ্ঠিত সাংস্কৃতিক সংগঠন যা <?php echo e(organization_info('founded')); ?> সাল থেকে ইসলামী মূল্যবোধ ও 
                সংস্কৃতি ছড়িয়ে দিচ্ছে সারা দেশে। আমাদের সংগঠন গান, আলোচনা, নাটক ও অন্যান্য সাংস্কৃতিক কার্যক্রমের 
                মাধ্যমে সমাজে ইতিবাচক প্রভাব ফেলে যাচ্ছে।
            </p>
            
            <div class="row mt-4">
                <div class="col-md-6">
                    <div class="card h-100 border-primary border-2">
                        <div class="card-body">
                            <h5 class="card-title text-primary">
                                <i class="fas fa-users me-2"></i>সদস্য নিয়োগ
                            </h5>
                            <p class="card-text">
                                আমাদের সংগঠনে যোগ দিয়ে সাংস্কৃতিক কার্যক্রমে অংশ নিন এবং সমাজের জন্য ইতিবাচক প্রভাব ফেলুন।
                            </p>
                            <a href="<?php echo e(route('application')); ?>" class="btn btn-primary">আবেদন করুন</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card h-100 border-success border-2">
                        <div class="card-body">
                            <h5 class="card-title text-success">
                                <i class="fas fa-calendar-alt me-2"></i>ইভেন্টসমূহ
                            </h5>
                            <p class="card-text">
                                আমাদের সকল ইভেন্ট ও কার্যক্রমে অংশ নিয়ে সংস্কৃতির আনন্দ উপভোগ করুন।
                            </p>
                            <a href="<?php echo e(route('notices')); ?>" class="btn btn-success">সব ইভেন্ট</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <h3 class="section-title mt-5">আমাদের সাম্প্রতিক কার্যক্রম</h3>
            <div class="row">
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title">জুলাই জাগরণ</h5>
                            <p class="card-text">
                                সোহরাওয়ার্দী উদ্যানে আয়োজিত "জুলাই জাগরণ" কার্যক্রমে অংশগ্রহণ করুন।
                            </p>
                            <small class="text-muted">১-৪ আগস্ট, ২০২৫ | সোহরাওয়ার্দী উদ্যান</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title">ঈদ মাহফিল</h5>
                            <p class="card-text">
                                আসন্ন ঈদ উপলক্ষে আয়োজিত বিশেষ মাহফিলে অংশ নিন।
                            </p>
                            <small class="text-muted">১৫ আগস্ট, ২০২৫ | ঢাকা বিশ্ববিদ্যালয়</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h4>গুরুত্বপূর্ণ নোটিস</h4>
                </div>
                <div class="card-body">
                    <ul class="list-unstyled">
                        <li class="mb-3">
                            <h6>জুলাই জাগরণ কার্যক্রম</h6>
                            <small class="text-muted">১-৪ আগস্ট, ২০২৫ | সোহরাওয়ার্দী উদ্যান</small>
                        </li>
                        <li class="mb-3">
                            <h6>ঈদ মাহফিল</h6>
                            <small class="text-muted">১৫ আগস্ট, ২০২৫ | ঢাকা বিশ্ববিদ্যালয়</small>
                        </li>
                        <li class="mb-3">
                            <h6>নতুন সদস্য নিয়োগ</h6>
                            <small class="text-muted">আবেদন শেষ হবে ৩০ জুলাই</small>
                        </li>
                    </ul>
                    <a href="<?php echo e(route('notices')); ?>" class="btn btn-outline-primary w-100">সব নোটিস</a>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h4>যোগাযোগ</h4>
                </div>
                <div class="card-body">
                    <p>আমাদের সাথে যোগাযোগ করতে ডানপাশের মেনু থেকে "যোগাযোগ" পেজে যান অথবা নিচের তথ্য ব্যবহার করুন:</p>
                    <p><strong>ইমেইল:</strong> <?php echo e(organization_info('email')); ?></p>
                    <p><strong>ফোন:</strong> <?php echo e(organization_info('phone')); ?></p>
                    <a href="<?php echo e(route('contact')); ?>" class="btn btn-primary w-100">যোগাযোগ করুন</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<!-- Animate.css for animations -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/saimumba/shilpigosthi.com/resources/views/home.blade.php ENDPATH**/ ?>