

<?php $__env->startSection('title', 'নোটিস - সাইমুম শিল্পীগোষ্ঠী'); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <h1 class="section-title">নোটিস</h1>
    
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h3 class="mb-0">জুলাই জাগরণ কার্যক্রম - ২০২৫</h3>
                </div>
                <div class="card-body">
                    <p class="text-muted">প্রকাশিত: ১০ জুলাই, ২০২৫</p>
                    <p>
                        আগামী ১-৪ আগস্ট, ২০২৫ তারিখে সোহরাওয়ার্দী উদ্যানে আয়োজিত হবে "জুলাই জাগরণ" কার্যক্রম। 
                        সকল সদস্য ও আগ্রহী ব্যক্তিবর্গ এই কার্যক্রমে অংশ নেওয়ার জন্য আবেদন করতে পারবেন।
                    </p>
                    <a href="#" class="btn btn-primary">বিস্তারিত দেখুন</a>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-header bg-success text-white">
                    <h3 class="mb-0">ঈদ মাহফিল - ২০২৫</h3>
                </div>
                <div class="card-body">
                    <p class="text-muted">প্রকাশিত: ৫ জুলাই, ২০২৫</p>
                    <p>
                        ঈদ উপলক্ষে আয়োজিত বিশেষ মাহফিলে অংশ নেওয়ার জন্য সকল সদস্যকে আবেদন করতে অনুরোধ করা হচ্ছে। 
                        মাহফিলটি অনুষ্ঠিত হবে ১৫ আগস্ট, ২০২৫ তারিখে ঢাকা বিশ্ববিদ্যালয়ে।
                    </p>
                    <a href="#" class="btn btn-success">বিস্তারিত দেখুন</a>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-header bg-info text-white">
                    <h3 class="mb-0">নতুন সদস্য নিয়োগ</h3>
                </div>
                <div class="card-body">
                    <p class="text-muted">প্রকাশিত: ১ জুলাই, ২০২৫</p>
                    <p>
                        আমাদের সংগঠনে নতুন সদস্য নিয়োগের জন্য আবেদন চলছে। আগ্রহী তরুণদের আবেদন করতে পারবেন 
                        "আবেদন" পেজ থেকে। আবেদনের শেষ তারিখ ৩০ জুলাই, ২০২৫।
                    </p>
                    <a href="<?php echo e(route('application')); ?>" class="btn btn-info">আবেদন করুন</a>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-header bg-warning text-dark">
                    <h3 class="mb-0">মাসিক সভা</h3>
                </div>
                <div class="card-body">
                    <p class="text-muted">প্রকাশিত: ২৫ জুন, ২০২৫</p>
                    <p>
                        প্রতি মাসের শেষ শুক্রবার অনুষ্ঠিত হওয়া মাসিক সভায় সকল সদস্যকে উপস্থিত থাকতে অনুরোধ করা হচ্ছে। 
                        পরবর্তী সভা ২৭ জুলাই, ২০২৫ তারিখে সকাল ১০টায়।
                    </p>
                    <a href="#" class="btn btn-warning">বিস্তারিত দেখুন</a>
                </div>
            </div>
        </div>
    </div>
    
    <nav aria-label="Page navigation example">
        <ul class="pagination justify-content-center">
            <li class="page-item disabled">
                <a class="page-link" href="#" tabindex="-1">Previous</a>
            </li>
            <li class="page-item active"><a class="page-link" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="#">2</a></li>
            <li class="page-item"><a class="page-link" href="#">3</a></li>
            <li class="page-item">
                <a class="page-link" href="#">Next</a>
            </li>
        </ul>
    </nav>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\All Project\1V2\saium-shilpigosthi\resources\views/notices.blade.php ENDPATH**/ ?>