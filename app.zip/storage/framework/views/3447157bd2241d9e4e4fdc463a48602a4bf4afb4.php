<?php $__env->startSection('title', 'আবেদনের পেমেন্ট'); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white d-flex flex-wrap gap-2 justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-0">পেমেন্ট সংক্ষেপ</h5>
                        <div class="small text-white-50">আবেদন আইডি (অভ্যন্তরীণ): #<?php echo e($application->id); ?></div>
                    </div>
                    <div class="text-end">
                        <span class="badge bg-light text-dark d-block">আবেদন কোড:
                            <?php if($application->public_application_code): ?>
                                <?php echo e($application->public_application_code); ?>

                            <?php else: ?>
                                <em class="text-muted">পেমেন্টের পর প্রদান</em>
                            <?php endif; ?>
                        </span>
                        <?php if($application->payment_due_at): ?>
                            <span class="small d-block mt-1" id="expiryCountdown" data-expiry="<?php echo e($application->payment_due_at->toIso8601String()); ?>">
                                অবশিষ্ট সময় লোড হচ্ছে...
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <?php $total = $application->total_fee; ?>
                    
                    <?php if(isset($breakdown) && count($breakdown) > 0): ?>
                        <p class="mb-2">আপনি যে বিষয়গুলো নির্বাচন করেছেন তার ফি সংক্ষেপ:</p>
                        <ul class="list-group mb-3">
                            <?php $__currentLoopData = $breakdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <span><strong><?php echo e($item['name']); ?></strong> <span class="text-muted">(<?php echo e($code); ?>)</span></span>
                                    <span><?php echo e(number_format($item['fee'],2)); ?> ৳</span>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center bg-light">
                                <strong>মোট</strong>
                                <strong><?php echo e(number_format($total,2)); ?> ৳</strong>
                            </li>
                        </ul>
                    <?php else: ?>
                        <p class="mb-2">আবেদন ফি:</p>
                        <ul class="list-group mb-3">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <span><strong>আবেদন ফি</strong></span>
                                <span><?php echo e(number_format($total,2)); ?> ৳</span>
                            </li>
                        </ul>
                    <?php endif; ?>

                    <div class="alert alert-info small mb-4">
                        <strong>নির্দেশনা:</strong> আপনি এখন পেমেন্ট সম্পন্ন করলে আবেদন কোড পাবেন। "পরে দিব" নির্বাচন করলে ২৪ ঘণ্টার মধ্যে পেমেন্ট না দিলে আবেদনটি মুছে যাবে।
                    </div>

                    <?php $gateways = app(\App\Services\PaymentGatewayRegistry::class)->enabled(); ?>
                    <div class="mt-4">
                        <form method="POST" action="<?php echo e(route('forms.payment.pay_now', $application)); ?>" id="payNowForm">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">পেমেন্ট মাধ্যম নির্বাচন:</label>
                                <?php if(count($gateways)): ?>
                                    <div class="row g-2">
                                        <?php $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-6 col-md-4">
                                                <div class="gateway-option border rounded p-2 h-100 position-relative">
                                                    <label class="w-100 m-0" style="cursor:pointer;">
                                                        <input class="form-check-input me-2" type="radio" name="gateway" value="<?php echo e($gw); ?>" <?php if($loop->first): echo 'checked'; endif; ?>>
                                                        <span class="align-middle">
                                                            <?php switch($gw):
                                                                case ('bkash'): ?><strong>bKash</strong><?php break; ?>
                                                                <?php case ('nagad'): ?><strong>Nagad</strong><?php break; ?>
                                                                <?php case ('dummy'): ?><strong>ডেমো</strong><?php break; ?>
                                                                <?php default: ?> <strong><?php echo e(ucfirst($gw)); ?></strong>
                                                            <?php endswitch; ?>
                                                        </span>
                                                    </label>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-warning py-2 mb-0">কোনো সক্রিয় পেমেন্ট গেটওয়ে পাওয়া যায়নি।</div>
                                <?php endif; ?>
                            </div>
                            <div class="d-flex flex-column flex-md-row gap-2 mt-3">
                                <button class="btn btn-success flex-fill" type="submit">
                                    <i class='bx bx-credit-card-alt me-1'></i> এখনই পরিশোধ করুন
                                </button>
                                <form method="POST" action="<?php echo e(route('forms.payment.pay_later', $application)); ?>" id="payLaterForm" class="flex-fill">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-outline-secondary w-100" type="submit">
                                        <i class='bx bx-time-five me-1'></i> পরে দিব
                                    </button>
                                </form>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="text-center mt-3">
                <a href="<?php echo e(route('application')); ?>" class="small text-decoration-none">ফিরে যান</a>
            </div>
        </div>
    </div>
</div>
<style>
    .gateway-option { transition: background-color .15s, border-color .15s; }
    .gateway-option:hover { background: rgba(0,0,0,0.03); }
    :root.dark-mode .gateway-option { background:#1e293b; border-color:#334155; }
    :root.dark-mode .gateway-option:hover { background:#243552; }
    #expiryCountdown { font-size:.75rem; font-weight:600; }
</style>
<script>
    (function(){
        const span = document.getElementById('expiryCountdown');
        if(!span) return;
        const expiryIso = span.getAttribute('data-expiry');
        if(!expiryIso) return;
        const expiry = new Date(expiryIso);
        function tick(){
            const now = new Date();
            let diff = Math.floor((expiry - now)/1000);
            if(diff <= 0){
                span.textContent = 'সময় শেষ (রিফ্রেশ করুন)';
                span.classList.add('text-danger');
                return;
            }
            const h = Math.floor(diff/3600); diff%=3600;
            const m = Math.floor(diff/60); diff%=60;
            const s = diff;
            span.textContent = `অবশিষ্ট: ${h} ঘন্টা ${m} মিনিট ${s} সেকেন্ড`;
            requestAnimationFrame(()=>setTimeout(tick,1000));
        }
        tick();
    })();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\All Project\1V2\saium-shilpigosthi\resources\views/forms/payment_decision.blade.php ENDPATH**/ ?>