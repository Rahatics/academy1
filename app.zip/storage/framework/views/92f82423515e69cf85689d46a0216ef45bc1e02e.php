<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-success text-white">
                    <h4 class="mb-0">পেমেন্ট সফল</h4>
                </div>
                <div class="card-body">
                    <div class="text-center mb-4">
                        <div class="avatar avatar-lg bg-success-subtle text-success rounded-circle mx-auto mb-3">
                            <i class='bx bx-check-circle bx-lg'></i>
                        </div>
                        <h5 class="mb-2">পেমেন্ট সফলভাবে সম্পন্ন হয়েছে!</h5>
                        <p class="text-muted">আপনার আবেদন ফি সফলভাবে গ্রহণ করা হয়েছে। নিচের তথ্য সংরক্ষণ করুন।</p>
                    </div>
                    
                    <!-- Applicant Information -->
                    <div class="mb-4">
                        <h6 class="border-bottom pb-2 mb-3">আবেদনকারীর তথ্য</h6>
                        <ul class="list-group">
                            <li class="list-group-item d-flex justify-content-between">
                                <span>আবেদনকারীর নাম</span>
                                <strong><?php echo e($application->name); ?></strong>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>আবেদন আইডি</span>
                                <strong><?php echo e($application->application_id); ?></strong>
                            </li>
                            <?php if($application->data['student_name_bengali'] ?? null): ?>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>শিক্ষার্থীর নাম (বাংলায়)</span>
                                <strong><?php echo e($application->data['student_name_bengali']); ?></strong>
                            </li>
                            <?php endif; ?>
                            <?php if($application->data['student_name_english'] ?? null): ?>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>শিক্ষার্থীর নাম (ইংরেজিতে)</span>
                                <strong><?php echo e($application->data['student_name_english']); ?></strong>
                            </li>
                            <?php endif; ?>
                            <?php if($application->data['father_name_bengali'] ?? null): ?>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>পিতার নাম</span>
                                <strong><?php echo e($application->data['father_name_bengali']); ?></strong>
                            </li>
                            <?php endif; ?>
                            <?php if($application->data['mother_name_bengali'] ?? null): ?>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>মাতার নাম</span>
                                <strong><?php echo e($application->data['mother_name_bengali']); ?></strong>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    
                    <!-- Payment Information -->
                    <div class="mb-4">
                        <h6 class="border-bottom pb-2 mb-3">পেমেন্ট তথ্য</h6>
                        <ul class="list-group">
                            <li class="list-group-item d-flex justify-content-between">
                                <span>পাবলিক আবেদন কোড</span>
                                <strong><?php echo e($application->public_application_code); ?></strong>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>ইনভয়েস</span>
                                <strong><?php echo e($application->internal_invoice); ?></strong>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>মোট ফি</span>
                                <strong><?php echo e(number_format($application->total_fee)); ?> ৳</strong>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>পেমেন্ট সময়</span>
                                <strong><?php echo e(optional($application->paid_at)->format('Y-m-d H:i')); ?></strong>
                            </li>
                        </ul>
                    </div>
                    
                    <!-- Additional Information -->
                    <div class="mb-4">
                        <h6 class="border-bottom pb-2 mb-3">অতিরিক্ত তথ্য</h6>
                        <ul class="list-group">
                            <li class="list-group-item d-flex justify-content-between">
                                <span>আবেদনের তারিখ</span>
                                <strong><?php echo e($application->created_at->format('Y-m-d')); ?></strong>
                            </li>
                            <?php if($application->subject): ?>
                                <?php
                                    $subject = $application->subjectByCode;
                                ?>
                                <?php if($subject): ?>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>আবেদনকৃত বিষয়</span>
                                    <strong><?php echo e($subject->name); ?></strong>
                                </li>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if($application->academic_class): ?>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>শ্রেণি</span>
                                <strong><?php echo e($application->academic_class); ?></strong>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <a href="/" class="btn btn-primary">হোমে ফিরুন</a>
                        <a href="<?php echo e(route('forms.payment.receipt-pdf', $application)); ?>" class="btn btn-success">
                            <i class='bx bx-download me-1'></i>পিডিএফ রশিদ ডাউনলোড করুন
                        </a>
                        <a href="javascript:window.print()" class="btn btn-outline-secondary">
                            <i class='bx bx-printer me-1'></i>প্রিন্ট করুন
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    @media print {
        body * {
            visibility: hidden;
        }
        .card, .card * {
            visibility: visible;
        }
        .card {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            box-shadow: none;
            border: none;
        }
        .btn {
            display: none;
        }
        .card-header {
            background-color: #28a745 !important;
            color: white !important;
        }
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/saimumba/shilpigosthi.com/resources/views/forms/payment_success.blade.php ENDPATH**/ ?>