<?php $__env->startSection('title', 'পেমেন্ট বিস্তারিত - অ্যাডমিন প্যানেল'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex align-items-center justify-content-between mb-4 fade-in py-3 px-4 rounded page-header">
        <div>
            <h4 class="mb-1 fw-bold">পেমেন্ট বিস্তারিত</h4>
            <p class="text-muted mb-0 small">পেমেন্ট আইডি: #<?php echo e($payment->id); ?></p>
        </div>
        <div>
            <ol class="breadcrumb mb-0 bg-transparent">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>" class="text-decoration-none">হোম</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.payments.index')); ?>" class="text-decoration-none">পেমেন্টসমূহ</a></li>
                <li class="breadcrumb-item active" aria-current="page">বিস্তারিত</li>
            </ol>
        </div>
    </div>

    <!-- Session Messages -->
    <?php if(session('status')): ?>
        <div class="alert alert-success alert-dismissible fade show fade-in mb-4" role="alert">
            <i class='bx bx-check-circle me-2'></i><strong>সফল!</strong> <?php echo e(session('status')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show fade-in mb-4" role="alert">
            <i class='bx bx-error me-2'></i><strong>ত্রুটি!</strong> <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-12 fade-in">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-0">
                    <!-- Payment Overview Header -->
                    <div class="p-4 border-bottom">
                        <div class="d-flex flex-column flex-lg-row justify-content-between align-items-start align-items-lg-center gap-3">
                            <div>
                                <h5 class="mb-2">পেমেন্ট সারসংক্ষেপ</h5>
                                <div class="d-flex flex-wrap align-items-center gap-3">
                                    <div class="d-flex align-items-center">
                                        <div class="avatar avatar-md bg-primary bg-opacity-10 text-primary rounded me-2">
                                            <i class='bx bx-hash'></i>
                                        </div>
                                        <div>
                                            <div class="small text-muted">আবেদন আইডি</div>
                                            <div class="fw-bold">
                                                <?php if($payment->application): ?>
                                                    <a href="<?php echo e(route('admin.applications.show', $payment->application)); ?>" class="text-decoration-none">
                                                        <?php echo e($payment->application->application_id ?? 'N/A'); ?>

                                                    </a>
                                                <?php else: ?>
                                                    <?php echo e($payment->application_id ?? 'N/A'); ?>

                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar avatar-md bg-success bg-opacity-10 text-success rounded me-2">
                                            <i class='bx bx-money'></i>
                                        </div>
                                        <div>
                                            <div class="small text-muted">পরিমাণ</div>
                                            <div class="fw-bold"><?php echo e(number_format($payment->amount, 2)); ?> <?php echo e($payment->currency ?? 'BDT'); ?></div>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar avatar-md bg-info bg-opacity-10 text-info rounded me-2">
                                            <i class='bx bx-time'></i>
                                        </div>
                                        <div>
                                            <div class="small text-muted">তৈরির তারিখ</div>
                                            <div class="fw-bold"><?php echo e($payment->created_at->format('d/m/Y H:i')); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex gap-2">
                                <a href="<?php echo e(route('admin.payments.index')); ?>" class="btn btn-outline-primary">
                                    <i class='bx bx-arrow-back me-1'></i>পেমেন্টসমূহে ফিরে যান
                                </a>
                                <?php if($payment->application): ?>
                                    <a href="<?php echo e(route('admin.applications.show', $payment->application)); ?>" class="btn btn-outline-secondary">
                                        <i class='bx bx-file me-1'></i>আবেদন দেখুন
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="p-4">
                        <div class="row g-4">
                            <!-- Payment Details Card -->
                            <div class="col-lg-6">
                                <div class="card border-0 shadow-sm h-100">
                                    <div class="card-header bg-light-subtle py-3">
                                        <h6 class="mb-0 d-flex align-items-center">
                                            <i class='bx bx-detail me-2 text-primary'></i>পেমেন্ট বিবরণ
                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="row g-3">
                                            <div class="col-12">
                                                <div class="d-flex justify-content-between align-items-center border-bottom pb-2">
                                                    <span class="text-muted">গেটওয়ে</span>
                                                    <span>
                                                        <?php if($payment->gateway == 'bkash'): ?>
                                                            <span class="badge bg-info-subtle text-info-emphasis">
                                                                <i class='bx bxl-bkash me-1'></i>bKash
                                                            </span>
                                                        <?php else: ?>
                                                            <span class="badge bg-secondary-subtle text-secondary-emphasis">
                                                                <?php echo e(ucfirst($payment->gateway ?? 'N/A')); ?>

                                                            </span>
                                                        <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="d-flex justify-content-between align-items-center border-bottom pb-2">
                                                    <span class="text-muted">স্ট্যাটাস</span>
                                                    <span>
                                                        <?php if($payment->status == 'completed'): ?>
                                                            <span class="badge bg-success-subtle text-success-emphasis">
                                                                <i class='bx bx-check-circle me-1'></i>সফল
                                                            </span>
                                                        <?php elseif($payment->status == 'failed'): ?>
                                                            <span class="badge bg-danger-subtle text-danger-emphasis">
                                                                <i class='bx bx-x-circle me-1'></i>ব্যর্থ
                                                            </span>
                                                        <?php elseif($payment->status == 'pending'): ?>
                                                            <span class="badge bg-warning-subtle text-warning-emphasis">
                                                                <i class='bx bx-hourglass me-1'></i>অপেক্ষমান
                                                            </span>
                                                        <?php else: ?>
                                                            <span class="badge bg-secondary-subtle text-secondary-emphasis">
                                                                <?php echo e(ucfirst($payment->status ?? 'N/A')); ?>

                                                            </span>
                                                        <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="d-flex justify-content-between align-items-center border-bottom pb-2">
                                                    <span class="text-muted">পরিমাণ</span>
                                                    <span class="fw-bold"><?php echo e(number_format($payment->amount, 2)); ?> <?php echo e($payment->currency ?? 'BDT'); ?></span>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="d-flex justify-content-between align-items-center border-bottom pb-2">
                                                    <span class="text-muted">আবেদন আইডি</span>
                                                    <span>
                                                        <?php if($payment->application): ?>
                                                            <a href="<?php echo e(route('admin.applications.show', $payment->application)); ?>" class="text-decoration-none">
                                                                <?php echo e($payment->application->application_id ?? 'N/A'); ?>

                                                            </a>
                                                        <?php else: ?>
                                                            <?php echo e($payment->application_id ?? 'N/A'); ?>

                                                        <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="d-flex justify-content-between align-items-center border-bottom pb-2">
                                                    <span class="text-muted">শিক্ষার্থির নাম</span>
                                                    <span>
                                                        <?php if($payment->application): ?>
                                                            <?php echo e($payment->application->name ?? 'N/A'); ?>

                                                        <?php else: ?>
                                                            N/A
                                                        <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="d-flex justify-content-between align-items-center border-bottom pb-2">
                                                    <span class="text-muted">পেমেন্ট আইডি</span>
                                                    <span><?php echo e($payment->payment_id ?? '-'); ?></span>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="d-flex justify-content-between align-items-center border-bottom pb-2">
                                                    <span class="text-muted">লেনদেন আইডি</span>
                                                    <span><?php echo e($payment->transaction_id ?? '-'); ?></span>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="d-flex justify-content-between align-items-center border-bottom pb-2">
                                                    <span class="text-muted">কার্যকর হয়েছে</span>
                                                    <span><?php echo e(optional($payment->executed_at)->format('d/m/Y H:i') ?? '-'); ?></span>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <span class="text-muted">তৈরির তারিখ</span>
                                                    <span><?php echo e($payment->created_at->format('d/m/Y H:i')); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Refund Information Card -->
                            <div class="col-lg-6">
                                <div class="card border-0 shadow-sm h-100">
                                    <div class="card-header bg-light-subtle py-3">
                                        <h6 class="mb-0 d-flex align-items-center">
                                            <i class='bx bx-undo me-2 text-warning'></i>রিফান্ড তথ্য
                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="row g-3 mb-4">
                                            <div class="col-12">
                                                <div class="d-flex justify-content-between align-items-center border-bottom pb-2">
                                                    <span class="text-muted">মোট পরিশোধিত</span>
                                                    <span class="fw-bold"><?php echo e(number_format($payment->amount ?? 0, 2)); ?> <?php echo e($payment->currency ?? 'BDT'); ?></span>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="d-flex justify-content-between align-items-center border-bottom pb-2">
                                                    <span class="text-muted">মোট রিফান্ডকৃত</span>
                                                    <span class="fw-bold"><?php echo e(number_format($payment->refunded_amount ?? 0, 2)); ?> <?php echo e($payment->currency ?? 'BDT'); ?></span>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <span class="text-muted">রিফান্ডযোগ্য অবশিষ্ট</span>
                                                    <span class="fw-bold text-<?php echo e($payment->refundableAmount() > 0 ? 'success' : 'muted'); ?>">
                                                        <?php echo e(number_format($payment->refundableAmount(), 2)); ?> <?php echo e($payment->currency ?? 'BDT'); ?>

                                                    </span>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Refund Form -->
                                        <?php if($payment->refundableAmount() > 0 && in_array($payment->status,['executed','success','completed'])): ?>
                                            <div class="border-top pt-3">
                                                <h6 class="mb-3">রিফান্ড প্রক্রিয়া</h6>
                                                <form method="post" action="<?php echo e(route('admin.payments.refund', $payment)); ?>" class="row g-3">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="col-md-6">
                                                        <label class="form-label small fw-medium">পরিমাণ *</label>
                                                        <input type="number" name="amount" step="0.01" min="0.01" max="<?php echo e($payment->refundableAmount()); ?>" 
                                                               value="<?php echo e($payment->refundableAmount()); ?>" class="form-control" required />
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label class="form-label small fw-medium">কারণ (ঐচ্ছিক)</label>
                                                        <input type="text" name="reason" class="form-control" placeholder="রিফান্ডের কারণ" />
                                                    </div>
                                                    <div class="col-12">
                                                        <button type="submit" class="btn btn-danger" onclick="return confirm('আপনি কি নিশ্চিত যে আপনি রিফান্ড প্রক্রিয়া করতে চান?');">
                                                            <i class='bx bx-undo me-1'></i>রিফান্ড প্রক্রিয়া করুন
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        <?php else: ?>
                                            <div class="alert alert-info mb-0 py-2 px-3 small">
                                                <i class='bx bx-info-circle me-1'></i>কোন রিফান্ডযোগ্য ব্যালেন্স নেই বা পেমেন্ট কার্যকর হয়নি।
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <!-- Meta Information Cards -->
                            <div class="col-lg-6">
                                <div class="card border-0 shadow-sm h-100">
                                    <div class="card-header bg-light-subtle py-3">
                                        <h6 class="mb-0 d-flex align-items-center">
                                            <i class='bx bx-code me-2 text-secondary'></i>মেটা তথ্য
                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <?php if($payment->meta): ?>
                                            <pre class="bg-light-subtle p-3 rounded small text-muted mb-0" style="max-height: 200px; overflow-y: auto;"><?php echo e(json_encode($payment->meta, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)); ?></pre>
                                        <?php else: ?>
                                            <p class="text-muted mb-0">কোন মেটা তথ্য নেই</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="card border-0 shadow-sm h-100">
                                    <div class="card-header bg-light-subtle py-3">
                                        <h6 class="mb-0 d-flex align-items-center">
                                            <i class='bx bx-code-curly me-2 text-secondary'></i>রিফান্ড মেটা
                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <?php if($payment->refund_meta): ?>
                                            <pre class="bg-light-subtle p-3 rounded small text-muted mb-0" style="max-height: 200px; overflow-y: auto;"><?php echo e(json_encode($payment->refund_meta, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)); ?></pre>
                                        <?php else: ?>
                                            <p class="text-muted mb-0">কোন রিফান্ড মেটা তথ্য নেই</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <!-- Refund Entries -->
                            <?php if(is_array($payment->refund_meta) && isset($payment->refund_meta['entries']) && count($payment->refund_meta['entries']) > 0): ?>
                                <div class="col-12">
                                    <div class="card border-0 shadow-sm">
                                        <div class="card-header bg-light-subtle py-3">
                                            <h6 class="mb-0 d-flex align-items-center">
                                                <i class='bx bx-list-ul me-2 text-info'></i>রিফান্ড এন্ট্রিসমূহ
                                            </h6>
                                        </div>
                                        <div class="card-body p-0">
                                            <div class="table-responsive">
                                                <table class="table table-hover align-middle mb-0">
                                                    <thead class="table-light">
                                                        <tr>
                                                            <th width="25%">পরিমাণ</th>
                                                            <th width="45%">কারণ</th>
                                                            <th width="30%">তারিখ</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $payment->refund_meta['entries']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e(number_format($entry['amount'], 2)); ?> <?php echo e($payment->currency ?? 'BDT'); ?></td>
                                                                <td><?php echo e($entry['reason'] ?? '-'); ?></td>
                                                                <td><?php echo e($entry['at'] ?? ''); ?></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Add specific animations for payments elements */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .fade-in {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    .fade-in:nth-child(1) { animation-delay: 0.1s; }
    .fade-in:nth-child(2) { animation-delay: 0.2s; }
    .fade-in:nth-child(3) { animation-delay: 0.3s; }
    .fade-in:nth-child(4) { animation-delay: 0.4s; }
    
    /* Ensure table rows have proper fade-in */
    .table tbody tr.fade-in {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    .table tbody tr.fade-in:nth-child(1) { animation-delay: 0.1s; }
    .table tbody tr.fade-in:nth-child(2) { animation-delay: 0.2s; }
    .table tbody tr.fade-in:nth-child(3) { animation-delay: 0.3s; }
    .table tbody tr.fade-in:nth-child(4) { animation-delay: 0.4s; }
    .table tbody tr.fade-in:nth-child(5) { animation-delay: 0.5s; }
    .table tbody tr.fade-in:nth-child(6) { animation-delay: 0.6s; }
    .table tbody tr.fade-in:nth-child(7) { animation-delay: 0.7s; }
    .table tbody tr.fade-in:nth-child(8) { animation-delay: 0.8s; }
    .table tbody tr.fade-in:nth-child(9) { animation-delay: 0.9s; }
    .table tbody tr.fade-in:nth-child(10) { animation-delay: 1.0s; }
    
    /* Card styling */
    .card {
        border-radius: 0.75rem;
        box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
    }
    
    /* Avatar styling */
    .avatar {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .avatar-sm {
        width: 2rem;
        height: 2rem;
        border-radius: 0.375rem;
    }
    
    .avatar-md {
        width: 3rem;
        height: 3rem;
        border-radius: 0.5rem;
    }
    
    .avatar-lg {
        width: 4rem;
        height: 4rem;
        border-radius: 0.75rem;
    }
    
    /* Table header styling */
    .table-light th {
        font-weight: 600;
        color: #495057;
    }
    
    /* Dark mode fixes */
    :root.dark-mode .card {
        background-color: #1e293b;
        border-color: #334155;
    }
    
    :root.dark-mode .card-header {
        background-color: #1e293b !important;
        border-color: #334155 !important;
    }
    
    :root.dark-mode .table-light th {
        background-color: #334155 !important;
        color: #f1f5f9 !important;
    }
    
    :root.dark-mode .table-hover tbody tr:hover {
        background-color: #334155 !important;
    }
    
    :root.dark-mode .table-bordered th,
    :root.dark-mode .table-bordered td {
        border-color: #334155 !important;
    }
    
    :root.dark-mode .form-control,
    :root.dark-mode .form-select {
        background-color: #1e293b;
        border-color: #334155;
        color: #f1f5f9;
    }
    
    :root.dark-mode .form-control:focus,
    :root.dark-mode .form-select:focus {
        background-color: #1e293b;
        border-color: #38bdf8;
        color: #f1f5f9;
        box-shadow: 0 0 0 0.25rem rgba(56, 189, 248, 0.25);
    }
    
    :root.dark-mode .modal-content {
        background-color: #1e293b;
    }
    
    :root.dark-mode .modal-header,
    :root.dark-mode .modal-footer {
        background-color: #334155 !important;
        border-color: #475569 !important;
    }
    
    :root.dark-mode .btn-close {
        filter: invert(1) grayscale(100%) brightness(200%);
    }
    
    /* Status badge improvements */
    .badge {
        font-size: 0.75em;
        padding: 0.5em 0.75em;
    }
    
    /* Button group spacing */
    .btn-group .btn {
        margin: 0;
    }
    
    /* Breadcrumb styling */
    .breadcrumb {
        background-color: transparent;
        padding: 0;
    }
    
    /* Subject badges */
    .badge.bg-primary-subtle {
        background-color: #dbeafe !important;
        color: #1d4ed8 !important;
    }
    
    .badge.bg-info-subtle {
        background-color: #cff4fc !important;
        color: #087990 !important;
    }
    
    .badge.bg-success-subtle {
        background-color: #d1fadf !important;
        color: #0a7641 !important;
    }
    
    .badge.bg-warning-subtle {
        background-color: #fff3cd !important;
        color: #856404 !important;
    }
    
    .badge.bg-danger-subtle {
        background-color: #f8d7da !important;
        color: #721c24 !important;
    }
    
    .badge.bg-secondary-subtle {
        background-color: #e2e8f0 !important;
        color: #475569 !important;
    }
    
    /* Dark mode subject badges */
    :root.dark-mode .badge.bg-primary-subtle {
        background-color: #1e3a8a !important;
        color: #93c5fd !important;
    }
    
    :root.dark-mode .badge.bg-info-subtle {
        background-color: #083344 !important;
        color: #67e8f9 !important;
    }
    
    :root.dark-mode .badge.bg-success-subtle {
        background-color: #052e16 !important;
        color: #4ade80 !important;
    }
    
    :root.dark-mode .badge.bg-warning-subtle {
        background-color: #856404 !important;
        color: #fef3c7 !important;
    }
    
    :root.dark-mode .badge.bg-danger-subtle {
        background-color: #721c24 !important;
        color: #f8d7da !important;
    }
    
    :root.dark-mode .badge.bg-secondary-subtle {
        background-color: #1e293b !important;
        color: #cbd5e1 !important;
    }
    
    /* Page header styling */
    .page-header {
        background-color: #f8f9fa;
        border-radius: 0.5rem;
    }
    
    /* Dark mode page header */
    :root.dark-mode .page-header {
        background-color: #1e293b;
    }
    
    :root.dark-mode .page-header h4 {
        color: #f1f5f9;
    }
    
    :root.dark-mode .page-header .text-muted {
        color: #94a3b8 !important;
    }
    
    :root.dark-mode .breadcrumb .breadcrumb-item a {
        color: #93c5fd;
    }
    
    :root.dark-mode .breadcrumb .breadcrumb-item.active {
        color: #cbd5e1;
    }
    
    /* Definition list styling */
    dl.row dt {
        font-weight: 600;
        color: var(--text-color);
    }
    
    dl.row dd {
        color: var(--text-color);
    }
    
    :root.dark-mode dl.row dt,
    :root.dark-mode dl.row dd {
        color: #f1f5f9 !important;
    }
    
    /* Table styling fixes */
    .table-responsive {
        overflow-x: visible;
    }
    
    @media (max-width: 768px) {
        .table-responsive {
            overflow-x: auto;
        }
        
        .table th, .table td {
            white-space: nowrap;
        }
    }
    
    /* Summary cards */
    .summary-card {
        transition: all 0.3s ease;
        border-radius: 0.75rem;
        overflow: hidden;
    }
    
    .summary-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 1rem 2rem rgba(0, 0, 0, 0.15) !important;
    }
    
    .summary-card .card-body {
        padding: 1.25rem 1rem;
    }
    
    .summary-card h5 {
        font-size: 1.5rem;
        margin-bottom: 0.5rem;
    }
    
    .summary-card .avatar {
        width: 3.5rem;
        height: 3.5rem;
        font-size: 1.25rem;
    }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
        .summary-card h5 {
            font-size: 1.25rem;
        }
        
        .summary-card .avatar {
            width: 3rem;
            height: 3rem;
            font-size: 1rem;
        }
        
        .summary-card .card-body {
            padding: 1rem 0.75rem;
        }
        
        .page-header {
            padding: 1rem;
        }
        
        .card-body {
            padding: 1rem;
        }
    }
    
    @media (max-width: 576px) {
        .summary-card h5 {
            font-size: 1.1rem;
        }
        
        .summary-card .avatar {
            width: 2.5rem;
            height: 2.5rem;
            font-size: 0.875rem;
        }
        
        .d-flex.flex-wrap.gap-3 > * {
            margin-bottom: 0.5rem;
        }
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\All Project\1V2\saium-shilpigosthi\resources\views/admin/payments/show.blade.php ENDPATH**/ ?>