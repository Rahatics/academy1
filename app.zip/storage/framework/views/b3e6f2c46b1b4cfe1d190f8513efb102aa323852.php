

<?php $__env->startSection('title', 'ইউজার ম্যানেজমেন্ট - অ্যাডমিন প্যানেল'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Modern Page Header -->
    <div class="d-flex align-items-center justify-content-between mb-4 fade-in py-3 px-4 rounded page-header shadow-sm" style="background-color: var(--card-bg); border: 1px solid var(--border-color);">
        <div>
            <h4 class="mb-1 fw-bold" style="color: var(--text-color);">ইউজার ম্যানেজমেন্ট</h4>
            <p class="mb-0 small" style="color: var(--text-muted);">সকল ইউজার এবং অ্যাডমিনের তালিকা</p>
        </div>
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 bg-transparent p-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>" class="text-decoration-none" style="color: var(--primary-color);">হোম</a></li>
                    <li class="breadcrumb-item active" style="color: var(--text-muted);" aria-current="page">ইউজার ম্যানেজমেন্ট</li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- Modern Stats Cards -->
    <div class="row mb-4 fade-in g-3">
        <div class="col-xl-4 col-md-6">
            <div class="card border-0 shadow-sm h-100 stats-card-primary">
                <div class="card-body d-flex align-items-center">
                    <div class="stats-icon bg-primary bg-opacity-10 text-primary rounded-circle me-3">
                        <i class='bx bx-user fs-4'></i>
                    </div>
                    <div class="stats-info flex-grow-1">
                        <h5 class="mb-0 fw-bold text-dark"><?php echo e(\App\Models\User::count() + \App\Models\Admin::count()); ?></h5>
                        <p class="mb-0 text-muted small">মোট ইউজার এবং অ্যাডমিন</p>
                    </div>
                    <div class="stats-trend text-success small">
                        <i class='bx bx-up-arrow-alt'></i> 12%
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-md-6">
            <div class="card border-0 shadow-sm h-100 stats-card-success">
                <div class="card-body d-flex align-items-center">
                    <div class="stats-icon bg-success bg-opacity-10 text-success rounded-circle me-3">
                        <i class='bx bx-check-circle fs-4'></i>
                    </div>
                    <div class="stats-info flex-grow-1">
                        <h5 class="mb-0 fw-bold text-dark"><?php echo e(\App\Models\User::where('email_verified_at', '!=', null)->count() + \App\Models\Admin::where('email_verified_at', '!=', null)->count()); ?></h5>
                        <p class="mb-0 text-muted small">ভেরিফাইড</p>
                    </div>
                    <div class="stats-trend text-success small">
                        <i class='bx bx-up-arrow-alt'></i> 8%
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-md-6">
            <div class="card border-0 shadow-sm h-100 stats-card-warning">
                <div class="card-body d-flex align-items-center">
                    <div class="stats-icon bg-warning bg-opacity-10 text-warning rounded-circle me-3">
                        <i class='bx bx-time fs-4'></i>
                    </div>
                    <div class="stats-info flex-grow-1">
                        <h5 class="mb-0 fw-bold text-dark"><?php echo e(\App\Models\User::where('email_verified_at', null)->count() + \App\Models\Admin::where('email_verified_at', null)->count()); ?></h5>
                        <p class="mb-0 text-muted small">পেন্ডিং</p>
                    </div>
                    <div class="stats-trend text-danger small">
                        <i class='bx bx-down-arrow-alt'></i> 3%
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modern User Management Card -->
    <div class="row">
        <div class="col-12 fade-in">
            <div class="card border-0 shadow-sm">
                <div class="card-header border-0 py-3 px-4 d-flex flex-wrap justify-content-between align-items-center gap-3" style="background-color: var(--card-bg); border-bottom: 1px solid var(--border-color);">
                    <div class="d-flex align-items-center gap-3">
                        <div>
                            <h5 class="mb-0 fw-bold d-inline" style="color: var(--text-color);">ইউজার এবং অ্যাডমিন তালিকা</h5>
                            <p class="mb-0 small" style="color: var(--text-muted);">আপনার সিস্টেমের সকল ইউজার এবং অ্যাডমিন</p>
                        </div>
                    </div>
                    <div class="d-flex flex-wrap gap-2">
                        <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary btn-sm d-flex align-items-center">
                            <i class='bx bx-plus me-1'></i>নতুন ইউজার
                        </a>
                        
                        <!-- Modern Filter Controls -->
                        <div class="btn-group" role="group">
                            <button type="button" class="btn btn-outline-secondary btn-sm" id="filterToggle">
                                <i class='bx bx-filter-alt me-1'></i>ফিল্টার
                            </button>
                            <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-outline-secondary btn-sm">
                                <i class='bx bx-reset'></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- Collapsible Filter Section -->
                <div id="filterSection" class="px-4 pb-0" style="display: none;">
                    <form method="GET" class="row g-3 pb-3">
                        <div class="col-md-4">
                            <label class="form-label small text-muted">সার্চ</label>
                            <div class="input-group input-group-sm">
                                <span class="input-group-text bg-white border-end-0">
                                    <i class='bx bx-search text-muted'></i>
                                </span>
                                <input type="text" name="search" class="form-control border-start-0" placeholder="ইউজার বা অ্যাডমিন খুঁজুন..." value="<?php echo e(request('search')); ?>">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small text-muted">স্ট্যাটাস</label>
                            <select name="status" class="form-select form-select-sm">
                                <option value="">সকল স্ট্যাটাস</option>
                                <option value="verified" <?php echo e(request('status') == 'verified' ? 'selected' : ''); ?>>ভেরিফাইড</option>
                                <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>পেন্ডিং</option>
                            </select>
                        </div>
                        <div class="col-md-4 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary btn-sm w-100">
                                <i class='bx bx-filter-alt me-1'></i>ফিল্টার প্রয়োগ
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Modern Users Table -->
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" id="usersTable">
                        <thead class="table-light">
                            <tr>
                                <th width="5%">
                                    <div class="form-check mb-0">
                                        <input class="form-check-input" type="checkbox" id="selectAll">
                                    </div>
                                </th>
                                <th width="20%">নাম</th>
                                <th width="25%">ইমেইল</th>
<th width="15%">টাইপ</th>
                                <th width="15%">স্ট্যাটাস</th>
                                <th width="15%">যোগদানের তারিখ</th>
                                <th width="10%">অ্যাকশন</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="fade-in">
                                <td>
                                    <div class="form-check mb-0">
                                        <?php if(isset($user['user_type']) && $user['user_type'] === 'admin'): ?>
                                            <!-- Admins cannot be selected for bulk actions -->
                                            <input class="form-check-input" type="checkbox" disabled>
                                        <?php else: ?>
                                            <input class="form-check-input user-checkbox" type="checkbox" value="<?php echo e($user['id']); ?>" data-id="<?php echo e($user['id']); ?>">
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar avatar-sm bg-primary bg-opacity-10 text-primary rounded-circle me-2">
                                            <i class='bx bx-user'></i>
                                        </div>
                                        <div>
                                            <div class="fw-medium text-dark"><?php echo e($user['name']); ?></div>
                                            <div class="small text-muted">#<?php echo e($user['id']); ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex flex-column">
                                        <span class="text-dark"><?php echo e($user['email']); ?></span>
                                        <span class="small text-muted"><?php echo e(isset($user['email_verified_at']) ? 'Verified' : 'Not Verified'); ?></span>
                                    </div>
                                </td>
                                <td>
                                    <?php if(isset($user['user_type']) && $user['user_type'] === 'admin'): ?>
                                        <span class="badge bg-danger bg-opacity-10 text-danger px-2 py-1 rounded-pill">
                                            <i class='bx bx-shield-quarter me-1'></i>অ্যাডমিন
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-primary bg-opacity-10 text-primary px-2 py-1 rounded-pill">
                                            <i class='bx bx-user me-1'></i>ইউজার
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if(isset($user['email_verified_at'])): ?>
                                        <span class="badge bg-success bg-opacity-10 text-success px-2 py-1 rounded-pill">
                                            <i class='bx bx-check-circle me-1'></i>Verified
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-warning bg-opacity-10 text-warning px-2 py-1 rounded-pill">
                                            <i class='bx bx-time me-1'></i>Pending
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="d-flex flex-column">
                                        <span class="text-dark"><?php echo e(\Carbon\Carbon::parse($user['created_at'])->format('d M, Y')); ?></span>
                                        <span class="small text-muted"><?php echo e(\Carbon\Carbon::parse($user['created_at'])->format('H:i')); ?></span>
                                    </div>
                                </td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-light rounded-circle p-2" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class='bx bx-dots-vertical-rounded text-muted'></i>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                                            <li>
                                                <a class="dropdown-item d-flex align-items-center" href="#">
                                                    <i class='bx bx-show me-2 text-primary'></i>দেখুন
                                                </a>
                                            </li>
                                            <?php if(!isset($user['user_type']) || $user['user_type'] !== 'admin'): ?>
                                            <li>
                                                <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('admin.users.edit', $user['id'])); ?>">
                                                    <i class='bx bx-edit me-2 text-warning'></i>সম্পাদনা
                                                </a>
                                            </li>
                                            <li><hr class="dropdown-divider"></li>
                                            <li>
                                                <button class="dropdown-item d-flex align-items-center text-danger delete-user-btn" 
                                                        data-id="<?php echo e($user['id']); ?>" 
                                                        data-name="<?php echo e($user['name']); ?>">
                                                    <i class='bx bx-trash me-2'></i>মুছে ফেলুন
                                                </button>
                                            </li>
                                            <?php else: ?>
                                            <li>
                                                <a class="dropdown-item d-flex align-items-center text-muted" href="#">
                                                    <i class='bx bx-edit me-2'></i>সম্পাদনা (অ্যাডমিন)
                                                </a>
                                            </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center py-5 fade-in">
                                    <div class="avatar avatar-xl bg-light-subtle text-muted rounded-circle mx-auto mb-3">
                                        <i class='bx bx-user bx-lg'></i>
                                    </div>
                                    <h5 class="text-muted">কোন ইউজার বা অ্যাডমিন পাওয়া যায়নি</h5>
                                    <p class="text-muted mb-0">এখনও কোন ইউজার বা অ্যাডমিন রেজিস্টার করেনি।</p>
                                    <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary btn-sm mt-3">
                                        <i class='bx bx-plus me-1'></i>নতুন ইউজার তৈরি করুন
                                    </a>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Modern Pagination and Bulk Actions -->
                <div class="card-footer bg-white border-0 py-3 px-4 d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">
                    <div class="d-flex align-items-center gap-2">
                        <button class="btn btn-sm btn-outline-danger" id="bulkDeleteBtn" disabled>
                            <i class='bx bx-trash me-1'></i>মুছে ফেলুন
                        </button>
                        <span class="text-muted small">
                            <span id="selectedCount">0</span> টি ইউজার নির্বাচিত
                        </span>
                    </div>
                    
                    <?php if($users->hasPages()): ?>
                    <div class="d-flex justify-content-center">
                        <?php echo e($users->appends(request()->query())->links()); ?>

                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modern Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold text-dark">ইউজার মুছে ফেলুন</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body py-3">
                <div class="d-flex align-items-center mb-3">
                    <div class="avatar avatar-lg bg-danger bg-opacity-10 text-danger rounded-circle me-3">
                        <i class='bx bx-error fs-4'></i>
                    </div>
                    <div>
                        <p class="mb-0">আপনি কি নিশ্চিত যে আপনি <strong id="deleteUserName"></strong> নামের ইউজারটি মুছে ফেলতে চান?</p>
                        <p class="text-muted mb-0 small">এই ক্রিয়াটি পূর্বাবস্থায় ফেরানো যাবে না।</p>
                    </div>
                </div>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">বাতিল</button>
                <button type="button" class="btn btn-danger" id="confirmDeleteBtn">মুছে ফেলুন</button>
            </div>
        </div>
    </div>
</div>

<!-- Bulk Delete Confirmation Modal -->
<div class="modal fade" id="bulkDeleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold text-dark">ইউজার মুছে ফেলুন</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body py-3">
                <div class="d-flex align-items-center mb-3">
                    <div class="avatar avatar-lg bg-danger bg-opacity-10 text-danger rounded-circle me-3">
                        <i class='bx bx-error fs-4'></i>
                    </div>
                    <div>
                        <p class="mb-0">আপনি কি নিশ্চিত যে আপনি <strong id="bulkDeleteCount"></strong> টি ইউজার মুছে ফেলতে চান?</p>
                        <p class="text-muted mb-0 small">এই ক্রিয়াটি পূর্বাবস্থায় ফেরানো যাবে না।</p>
                    </div>
                </div>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">বাতিল</button>
                <button type="button" class="btn btn-danger" id="confirmBulkDeleteBtn">মুছে ফেলুন</button>
            </div>
        </div>
    </div>
</div>

<style>
    /* Modern Stats Cards */
    .stats-card-primary, .stats-card-success, .stats-card-warning {
        transition: all 0.3s ease;
        border-radius: 12px;
        overflow: hidden;
    }
    
    .stats-card-primary:hover, .stats-card-success:hover, .stats-card-warning:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    }
    
    .stats-icon {
        width: 50px;
        height: 50px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.3s ease;
    }
    
    .stats-card-primary:hover .stats-icon {
        transform: scale(1.1);
    }
    
    /* Modern Table Styling */
    #usersTable thead th {
        font-weight: 600;
        color: #495057;
        border-top: none;
        padding: 1rem 1.25rem;
    }
    
    #usersTable tbody td {
        padding: 1rem 1.25rem;
        vertical-align: middle;
    }
    
    #usersTable tbody tr:hover {
        background-color: rgba(74, 144, 226, 0.03);
    }
    
    /* Modern Dropdown */
    .dropdown-menu {
        border-radius: 12px;
        border: none;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        padding: 0.5rem 0;
    }
    
    .dropdown-item {
        padding: 0.75rem 1.25rem;
        transition: all 0.2s ease;
    }
    
    .dropdown-item:hover {
        background-color: rgba(74, 144, 226, 0.1);
    }
    
    /* Modern Pagination */
    .pagination .page-link {
        border-radius: 8px;
        margin: 0 2px;
        border: none;
        color: #495057;
    }
    
    .pagination .page-item.active .page-link {
        background-color: #4a90e2;
        border-color: #4a90e2;
    }
    
    .pagination .page-link:hover {
        background-color: #e9ecef;
    }
    
    /* Modern Avatar */
    .avatar {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .avatar-sm {
        width: 36px;
        height: 36px;
        font-size: 0.875rem;
    }
    
    .avatar-xl {
        width: 80px;
        height: 80px;
        font-size: 2rem;
    }
    
    /* Modern Badges */
    .badge {
        font-weight: 500;
        padding: 0.5em 0.85em;
    }
    
    /* Modern Buttons */
    .btn {
        border-radius: 8px;
        font-weight: 500;
        padding: 0.5rem 1rem;
    }
    
    .btn-sm {
        padding: 0.375rem 0.75rem;
        font-size: 0.875rem;
    }
    
    /* Modern Form Controls */
    .form-control, .form-select {
        border-radius: 8px;
        padding: 0.5rem 1rem;
    }
    
    .input-group-text {
        border-radius: 8px 0 0 8px;
    }
    
    /* Modern Card */
    .card {
        border-radius: 16px;
        overflow: hidden;
    }
    
    .card-header {
        border-bottom: 1px solid #e9ecef;
    }
    
    /* Modern Breadcrumb */
    .breadcrumb-item + .breadcrumb-item::before {
        content: ">";
        color: #adb5bd;
    }
    
    /* Modern Animations */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .fade-in {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    /* Dark Mode Support */
    :root.dark-mode .stats-card-primary, 
    :root.dark-mode .stats-card-success, 
    :root.dark-mode .stats-card-warning {
        background-color: #1e293b;
    }
    
    :root.dark-mode .card {
        background-color: #1e293b;
        border-color: #334155;
    }
    
    :root.dark-mode .card-header {
        background-color: #1e293b;
        border-color: #334155;
    }
    
    :root.dark-mode .table-light th {
        background-color: #334155 !important;
        color: #f1f5f9 !important;
    }
    
    :root.dark-mode .table-hover tbody tr:hover {
        background-color: #334155 !important;
    }
    
    :root.dark-mode .form-control, 
    :root.dark-mode .form-select {
        background-color: #1e293b;
        border-color: #334155;
        color: #f1f5f9;
    }
    
    :root.dark-mode .form-control:focus, 
    :root.dark-mode .form-select:focus {
        border-color: #3b82f6;
        box-shadow: 0 0 0 0.25rem rgba(59, 130, 246, 0.25);
    }
    
    :root.dark-mode .input-group-text {
        background-color: #334155;
        border-color: #334155;
        color: #f1f5f9;
    }
    
    :root.dark-mode .bg-white {
        background-color: #1e293b !important;
    }
    
    :root.dark-mode .text-dark {
        color: #f1f5f9 !important;
    }
    
    :root.dark-mode .text-muted {
        color: #94a3b8 !important;
    }
    
    :root.dark-mode .border-bottom {
        border-color: #334155 !important;
    }
    
    :root.dark-mode .page-header {
        background-color: #1e293b;
    }
    
    :root.dark-mode .stats-info .text-dark {
        color: #f1f5f9 !important;
    }
    
    :root.dark-mode .dropdown-menu {
        background-color: #1e293b;
        border: 1px solid #334155;
    }
    
    :root.dark-mode .dropdown-item {
        color: #f1f5f9;
    }
    
    :root.dark-mode .dropdown-item:hover {
        background-color: #334155;
    }
    
    :root.dark-mode .pagination .page-link {
        background-color: #1e293b;
        border-color: #334155;
        color: #f1f5f9;
    }
    
    :root.dark-mode .pagination .page-item.active .page-link {
        background-color: #3b82f6;
        border-color: #3b82f6;
    }
    
    :root.dark-mode .pagination .page-link:hover {
        background-color: #334155;
    }
    
    :root.dark-mode .btn-close {
        filter: invert(1) grayscale(100%) brightness(200%);
    }
    
    :root.dark-mode .modal-content {
        background-color: #1e293b;
    }
    
    :root.dark-mode .modal-header {
        border-color: #334155;
    }
    
    :root.dark-mode .modal-footer {
        border-color: #334155;
    }
    
    :root.dark-mode .alert-info {
        background-color: #0ea5e9;
        border-color: #0ea5e9;
        color: #0f172a;
    }
    
    :root.dark-mode .table td, 
    :root.dark-mode .table th {
        color: #f1f5f9;
    }
    
    :root.dark-mode .form-check-input {
        background-color: #1e293b;
        border-color: #334155;
    }
    
    :root.dark-mode .form-check-input:checked {
        background-color: #3b82f6;
        border-color: #3b82f6;
    }
    
    :root.dark-mode .btn-outline-secondary {
        color: #f1f5f9;
        border-color: #334155;
    }
    
    :root.dark-mode .btn-outline-secondary:hover {
        background-color: #334155;
        border-color: #334155;
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Filter toggle functionality
        const filterToggle = document.getElementById('filterToggle');
        const filterSection = document.getElementById('filterSection');
        
        if (filterToggle) {
            filterToggle.addEventListener('click', function() {
                if (filterSection.style.display === 'none') {
                    filterSection.style.display = 'block';
                } else {
                    filterSection.style.display = 'none';
                }
            });
        }
        
        // Select all functionality
        const selectAll = document.getElementById('selectAll');
        const userCheckboxes = document.querySelectorAll('.user-checkbox');
        const bulkDeleteBtn = document.getElementById('bulkDeleteBtn');
        const selectedCount = document.getElementById('selectedCount');
        
        if (selectAll) {
            selectAll.addEventListener('change', function() {
                userCheckboxes.forEach(checkbox => {
                    checkbox.checked = this.checked;
                });
                updateBulkActions();
            });
        }
        
        userCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', updateBulkActions);
        });
        
        function updateBulkActions() {
            const selectedCheckboxes = document.querySelectorAll('.user-checkbox:checked');
            const count = selectedCheckboxes.length;
            
            selectedCount.textContent = count;
            
            if (count > 0) {
                bulkDeleteBtn.disabled = false;
            } else {
                bulkDeleteBtn.disabled = true;
            }
        }
        
        // Single delete user functionality
        const deleteButtons = document.querySelectorAll('.delete-user-btn');
        const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
        let currentUserId = null;
        
        deleteButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                
                currentUserId = this.getAttribute('data-id');
                const userName = this.getAttribute('data-name');
                
                // Set user name in modal
                document.getElementById('deleteUserName').textContent = userName;
                
                // Show delete confirmation modal
                deleteModal.show();
            });
        });
        
        // Confirm delete button in modal
        document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
            if (!currentUserId) return;
            
            // Create a form dynamically and submit it
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = `/admin/users/${currentUserId}`;
            
            const methodInput = document.createElement('input');
            methodInput.type = 'hidden';
            methodInput.name = '_method';
            methodInput.value = 'DELETE';
            
            const tokenInput = document.createElement('input');
            tokenInput.type = 'hidden';
            tokenInput.name = '_token';
            tokenInput.value = '<?php echo e(csrf_token()); ?>';
            
            form.appendChild(methodInput);
            form.appendChild(tokenInput);
            document.body.appendChild(form);
            form.submit();
        });
        
        // Bulk delete functionality
        const bulkDeleteModal = new bootstrap.Modal(document.getElementById('bulkDeleteModal'));
        let selectedUserIds = [];
        
        if (bulkDeleteBtn) {
            bulkDeleteBtn.addEventListener('click', function() {
                const selectedCheckboxes = document.querySelectorAll('.user-checkbox:checked');
                selectedUserIds = Array.from(selectedCheckboxes).map(cb => cb.value);
                
                // Set count in modal
                document.getElementById('bulkDeleteCount').textContent = selectedUserIds.length;
                
                // Show bulk delete confirmation modal
                bulkDeleteModal.show();
            });
        }
        
        // Confirm bulk delete button in modal
        document.getElementById('confirmBulkDeleteBtn').addEventListener('click', function() {
            if (selectedUserIds.length === 0) return;
            
            // Create a form dynamically and submit it
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '<?php echo e(route("admin.users.bulk-delete")); ?>';
            
            const methodInput = document.createElement('input');
            methodInput.type = 'hidden';
            methodInput.name = '_method';
            methodInput.value = 'DELETE';
            
            const tokenInput = document.createElement('input');
            tokenInput.type = 'hidden';
            tokenInput.name = '_token';
            tokenInput.value = '<?php echo e(csrf_token()); ?>';
            
            // Add selected user IDs
            selectedUserIds.forEach(id => {
                const idInput = document.createElement('input');
                idInput.type = 'hidden';
                idInput.name = 'ids[]';
                idInput.value = id;
                form.appendChild(idInput);
            });
            
            form.appendChild(methodInput);
            form.appendChild(tokenInput);
            document.body.appendChild(form);
            form.submit();
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\All Project\1V2\saium-shilpigosthi\resources\views/admin/users/index.blade.php ENDPATH**/ ?>