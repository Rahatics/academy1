

<?php $__env->startSection('title', 'নতুন ইউজার - অ্যাডমিন প্যানেল'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Modern Page Header -->
    <div class="d-flex align-items-center justify-content-between mb-4 fade-in py-3 px-4 rounded page-header bg-white shadow-sm">
        <div>
            <h4 class="mb-1 fw-bold text-dark">নতুন ইউজার</h4>
            <p class="text-muted mb-0 small">নতুন ইউজার তৈরি করুন</p>
        </div>
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 bg-transparent p-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>" class="text-decoration-none text-primary">হোম</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.users.index')); ?>" class="text-decoration-none text-primary">ইউজার ম্যানেজমেন্ট</a></li>
                    <li class="breadcrumb-item active text-muted" aria-current="page">নতুন ইউজার</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="row">
        <div class="col-12 fade-in">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-0 py-3 px-4">
                    <h5 class="mb-0 fw-bold text-dark">ইউজারের তথ্য</h5>
                    <p class="mb-0 text-muted small">নতুন ইউজারের প্রয়োজনীয় তথ্য প্রদান করুন</p>
                </div>
                <div class="card-body p-4">
                    <form action="<?php echo e(route('admin.users.store')); ?>" method="POST" class="row">
                        <?php echo csrf_field(); ?>
                        
                        <div class="col-lg-8">
                            <div class="row">
                                <div class="col-md-12 mb-4">
                                    <label class="form-label fw-medium text-dark">নাম <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-white border-end-0">
                                            <i class='bx bx-user text-muted'></i>
                                        </span>
                                        <input type="text" class="form-control border-start-0 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" placeholder="ইউজারের নাম লিখুন" required>
                                    </div>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="col-md-12 mb-4">
                                    <label class="form-label fw-medium text-dark">ইমেইল <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-white border-end-0">
                                            <i class='bx bx-envelope text-muted'></i>
                                        </span>
                                        <input type="email" class="form-control border-start-0 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="ইউজারের ইমেইল লিখুন" required>
                                    </div>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="col-md-12 mb-4">
                                    <label class="form-label fw-medium text-dark">পাসওয়ার্ড <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-white border-end-0">
                                            <i class='bx bx-lock text-muted'></i>
                                        </span>
                                        <input type="password" class="form-control border-start-0 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" placeholder="পাসওয়ার্ড লিখুন" required>
                                    </div>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div class="form-text text-muted">পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে</div>
                                </div>
                                
                                <div class="col-md-12 mb-4">
                                    <label class="form-label fw-medium text-dark">পাসওয়ার্ড নিশ্চিত করুন <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-white border-end-0">
                                            <i class='bx bx-lock text-muted'></i>
                                        </span>
                                        <input type="password" class="form-control border-start-0 <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password_confirmation" placeholder="পাসওয়ার্ড পুনরায় লিখুন" required>
                                    </div>
                                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-lg-4">
                            <div class="card border-0 bg-light-subtle shadow-sm">
                                <div class="card-body">
                                    <h6 class="card-title fw-bold text-dark mb-3">ইউজার প্রোফাইল</h6>
                                    <div class="text-center mb-4">
                                        <div class="avatar avatar-xl bg-primary bg-opacity-10 text-primary rounded-circle mx-auto mb-3">
                                            <i class='bx bx-user fs-1'></i>
                                        </div>
                                        <p class="text-muted small mb-0">ইউজারের প্রোফাইল ছবি</p>
                                        <p class="text-muted small">সুপারিশকৃত সাইজ: 200x200 পিক্সেল</p>
                                    </div>
                                    
                                    <div class="alert alert-info d-flex align-items-center" role="alert">
                                        <i class='bx bx-info-circle me-2'></i>
                                        <div>
                                            <h6 class="alert-heading fw-bold mb-1">গুরুত্বপূর্ণ তথ্য</h6>
                                            <p class="mb-0 small">ইউজারের প্রয়োজনীয় তথ্য সঠিকভাবে প্রদান করুন। ইমেইল অবশ্যই অনন্য হতে হবে।</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-12 mt-4">
                            <div class="d-flex justify-content-between">
                                <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-outline-secondary">
                                    <i class='bx bx-arrow-back me-1'></i>বাতিল
                                </a>
                                <button type="submit" class="btn btn-primary">
                                    <i class='bx bx-save me-1'></i>ইউজার তৈরি করুন
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Modern Form Styling */
    .form-control, .form-select {
        border-radius: 10px;
        padding: 0.75rem 1rem;
        border: 1px solid #e9ecef;
        transition: all 0.3s ease;
    }
    
    .form-control:focus, .form-select:focus {
        border-color: #4a90e2;
        box-shadow: 0 0 0 0.25rem rgba(74, 144, 226, 0.15);
    }
    
    .input-group-text {
        border-radius: 10px 0 0 10px;
        border: 1px solid #e9ecef;
        background-color: #f8f9fa;
    }
    
    .form-label {
        margin-bottom: 0.5rem;
        font-weight: 500;
    }
    
    /* Modern Card Styling */
    .card {
        border-radius: 16px;
        overflow: hidden;
    }
    
    .card-header {
        border-bottom: 1px solid #e9ecef;
    }
    
    /* Modern Avatar */
    .avatar {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .avatar-xl {
        width: 100px;
        height: 100px;
        font-size: 2.5rem;
    }
    
    /* Modern Alert */
    .alert {
        border-radius: 10px;
        border: none;
    }
    
    /* Modern Buttons */
    .btn {
        border-radius: 10px;
        padding: 0.6rem 1.25rem;
        font-weight: 500;
        transition: all 0.3s ease;
    }
    
    .btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    
    /* Modern Breadcrumb */
    .breadcrumb-item + .breadcrumb-item::before {
        content: ">";
        color: #adb5bd;
    }
    
    /* Dark Mode Support */
    :root.dark-mode .card {
        background-color: #1e293b;
        border-color: #334155;
    }
    
    :root.dark-mode .card-header {
        background-color: #1e293b;
        border-color: #334155;
    }
    
    :root.dark-mode .form-control, 
    :root.dark-mode .form-select,
    :root.dark-mode .input-group-text {
        background-color: #1e293b;
        border-color: #334155;
        color: #f1f5f9;
    }
    
    :root.dark-mode .form-control:focus, 
    :root.dark-mode .form-select:focus {
        border-color: #3b82f6;
        box-shadow: 0 0 0 0.25rem rgba(59, 130, 246, 0.15);
    }
    
    :root.dark-mode .input-group-text {
        background-color: #334155;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\All Project\1V2\saium-shilpigosthi\resources\views/admin/users/create.blade.php ENDPATH**/ ?>