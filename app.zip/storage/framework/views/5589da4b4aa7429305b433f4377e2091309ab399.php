

<?php $__env->startSection('title', 'আবেদনসমূহ - অ্যাডমিন প্যানেল'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex align-items-center justify-content-between mb-4 fade-in py-2 px-3 rounded page-header">
        <div>
            <h4 class="mb-0 fw-bold">আবেদনসমূহ</h4>
            <p class="text-muted mb-0 small">সকল আবেদনের তালিকা এবং ব্যবস্থাপনা</p>
        </div>
        <div>
            <ol class="breadcrumb mb-0 bg-transparent">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>" class="text-decoration-none">হোম</a></li>
                <li class="breadcrumb-item active" aria-current="page">আবেদনসমূহ</li>
            </ol>
        </div>
    </div>

    <!-- Summary Cards -->
    <div class="row mb-4 fade-in g-3 justify-content-center">
        <div class="col-6 col-md-4 col-lg mb-3">
            <div class="card border-0 shadow-sm h-100 summary-card">
                <div class="card-body text-center py-3">
                    <div class="avatar avatar-md bg-primary bg-opacity-10 text-primary rounded mx-auto mb-2">
                        <i class='bx bx-file fs-4'></i>
                    </div>
                    <h5 class="mb-1 fw-bold"><?php echo e($applications->total()); ?></h5>
                    <p class="text-muted mb-0 small">মোট আবেদন</p>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-4 col-lg mb-3">
            <div class="card border-0 shadow-sm h-100 summary-card">
                <div class="card-body text-center py-3">
                    <div class="avatar avatar-md bg-info bg-opacity-10 text-info rounded mx-auto mb-2">
                        <i class='bx bx-check-circle fs-4'></i>
                    </div>
                    <h5 class="mb-1 fw-bold"><?php echo e($applications->where('status', 'reviewed')->count()); ?></h5>
                    <p class="text-muted mb-0 small">পর্যালোচনা</p>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-4 col-lg mb-3">
            <div class="card border-0 shadow-sm h-100 summary-card">
                <div class="card-body text-center py-3">
                    <div class="avatar avatar-md bg-success bg-opacity-10 text-success rounded mx-auto mb-2">
                        <i class='bx bx-badge-check fs-4'></i>
                    </div>
                    <h5 class="mb-1 fw-bold"><?php echo e($applications->where('status', 'accepted')->count()); ?></h5>
                    <p class="text-muted mb-0 small">গৃহীত</p>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-4 col-lg mb-3">
            <div class="card border-0 shadow-sm h-100 summary-card">
                <div class="card-body text-center py-3">
                    <div class="avatar avatar-md bg-danger bg-opacity-10 text-danger rounded mx-auto mb-2">
                        <i class='bx bx-x-circle fs-4'></i>
                    </div>
                    <h5 class="mb-1 fw-bold"><?php echo e($applications->where('status', 'rejected')->count()); ?></h5>
                    <p class="text-muted mb-0 small">বাতিল</p>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-4 col-lg mb-3">
            <div class="card border-0 shadow-sm h-100 summary-card">
                <div class="card-body text-center py-3">
                    <div class="avatar avatar-md bg-warning bg-opacity-10 text-warning rounded mx-auto mb-2">
                        <i class='bx bx-hourglass fs-4'></i>
                    </div>
                    <h5 class="mb-1 fw-bold"><?php echo e($applications->where('status', 'pending')->count() + $applications->where('status', 'interview')->count()); ?></h5>
                    <p class="text-muted mb-0 small">অন্যান্য</p>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12 fade-in">
            <div class="card border-0 shadow-sm">
                <div class="card-body p-0">
                    <!-- Table Header with Filters -->
                    <div class="p-4 border-bottom">
                        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">
                            <h5 class="mb-0">সকল আবেদন</h5>
                            <div class="d-flex flex-wrap gap-2">
                                <!-- Filter Form -->
                                <form method="GET" class="d-flex flex-wrap gap-2">
                                    <!-- Form Filter -->
                                    <select name="form_id" class="form-select" style="width: 180px;">
                                        <option value="">সকল ফর্ম</option>
                                        <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($form->id); ?>" <?php echo e(request('form_id') == $form->id ? 'selected' : ''); ?>>
                                                <?php echo e($form->title); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    
                                    <!-- Status Filter -->
                                    <select name="status" class="form-select" style="width: 150px;">
                                        <option value="">সকল স্ট্যাটাস</option>
                                        <option value="reviewed" <?php echo e(request('status') == 'reviewed' ? 'selected' : ''); ?>>পর্যালোচনা</option>
                                        <option value="accepted" <?php echo e(request('status') == 'accepted' ? 'selected' : ''); ?>>গৃহীত</option>
                                        <option value="rejected" <?php echo e(request('status') == 'rejected' ? 'selected' : ''); ?>>বাতিল</option>
                                    </select>
                                    
                                    <!-- Date Range -->
                                    <input type="date" name="start_date" class="form-control" style="width: 140px;" value="<?php echo e(request('start_date')); ?>" placeholder="শুরু">
                                    <input type="date" name="end_date" class="form-control" style="width: 140px;" value="<?php echo e(request('end_date')); ?>" placeholder="শেষ">
                                    
                                    <!-- Search -->
                                    <div class="input-group" style="width: 200px;">
                                        <span class="input-group-text bg-white border-end-0">
                                            <i class='bx bx-search'></i>
                                        </span>
                                        <input type="text" name="search" class="form-control border-start-0" placeholder="আবেদন খুঁজুন..." value="<?php echo e(request('search')); ?>">
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary">
                                        <i class='bx bx-filter-alt me-1'></i>ফিল্টার
                                    </button>
                                    
                                    <a href="<?php echo e(route('admin.applications.index')); ?>" class="btn btn-outline-secondary">
                                        <i class='bx bx-reset'></i>
                                    </a>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Applications Table -->
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0" id="applicationsTable">
                            <thead class="table-light">
                                <tr>
                                    <th width="5%">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="selectAll">
                                        </div>
                                    </th>
                                    <th width="12%">App. No</th>
                                    <th width="15%">নাম</th>
                                    <th width="15%">বিষয়</th>
                                    <th width="8%">শ্রেণি</th>
                                    <th width="8%">লিঙ্গ</th>
                                    <th width="8%">বয়স</th>
                                    <th width="10%">স্ট্যাটাস</th>
                                    <th width="10%">স্ট্যাটাস আপডেট</th>
                                    <th width="12%">আবেদনের তারিখ</th>
                                    <th width="12%">অ্যাকশন</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="fade-in">
                                    <td>
                                        <div class="form-check">
                                            <input class="form-check-input application-checkbox" type="checkbox" value="<?php echo e($application->id); ?>" data-id="<?php echo e($application->id); ?>">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar avatar-sm bg-primary-subtle text-primary rounded me-2">
                                                <i class='bx bx-hash'></i>
                                            </div>
                                            <div>
                                                <div class="fw-medium"><?php echo e($application->application_id); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="fw-medium"><?php echo e($application->name); ?></div>
                                        <?php if($application->data['student_name_bengali'] ?? null): ?>
                                            <div class="small text-muted"><?php echo e($application->data['student_name_bengali']); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo format_subjects_display($application->subject ?? '', $subjectMap); ?>

                                    </td>
                                    <td>
                                        <?php if(!empty($application->data['last_class_or_year'])): ?>
                                            <span class="badge bg-info-subtle text-info-emphasis"><?php echo e($application->data['last_class_or_year']); ?></span>
                                        <?php elseif(!empty($application->academic_class)): ?>
                                            <span class="badge bg-info-subtle text-info-emphasis"><?php echo e($application->academic_class); ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if(!empty($application->data['gender'])): ?>
                                            <span class="badge bg-warning-subtle text-warning-emphasis"><?php echo e($application->data['gender']); ?></span>
                                        <?php elseif(!empty($application->gender)): ?>
                                            <span class="badge bg-warning-subtle text-warning-emphasis"><?php echo e($application->gender); ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                            $dateOfBirth = null;
                                            if (!empty($application->data['date_of_birth'])) {
                                                $dateOfBirth = $application->data['date_of_birth'];
                                            } elseif (!empty($application->date_of_birth)) {
                                                $dateOfBirth = $application->date_of_birth;
                                            }
                                        ?>
                                        <?php if($dateOfBirth): ?>
                                            <?php
                                                try {
                                                    $dob = \Carbon\Carbon::parse($dateOfBirth);
                                                    $age = $dob->diffInYears(now());
                                                    echo '<span class="badge bg-success-subtle text-success-emphasis">' . $age . '</span>';
                                                } catch (Exception $e) {
                                                    echo '<span class="text-muted">N/A</span>';
                                                }
                                            ?>
                                        <?php else: ?>
                                            <span class="text-muted">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($application->status == 'pending'): ?>
                                            <span class="badge bg-warning-subtle text-warning-emphasis">
                                                <i class='bx bx-hourglass me-1'></i>পেন্ডিং
                                            </span>
                                        <?php elseif($application->status == 'reviewed'): ?>
                                            <span class="badge bg-info-subtle text-info-emphasis">
                                                <i class='bx bx-check-circle me-1'></i>In Review
                                            </span>
                                        <?php elseif($application->status == 'interview'): ?>
                                            <span class="badge bg-primary-subtle text-primary-emphasis">
                                                <i class='bx bx-user-voice me-1'></i>সাক্ষাৎ
                                            </span>
                                        <?php elseif($application->status == 'accepted'): ?>
                                            <span class="badge bg-success-subtle text-success-emphasis">
                                                <i class='bx bx-badge-check me-1'></i>Approved
                                            </span>
                                        <?php elseif($application->status == 'rejected'): ?>
                                            <span class="badge bg-danger-subtle text-danger-emphasis">
                                                <i class='bx bx-x-circle me-1'></i>Rejected
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary-subtle text-secondary-emphasis">
                                                <?php echo e(ucfirst($application->status)); ?>

                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <!-- Status Update Form -->
                                        <form method="POST" action="<?php echo e(route('admin.applications.update-status', $application)); ?>" class="status-update-form d-inline-block">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="input-group input-group-sm">
                                                <select name="status" class="form-select form-select-sm status-select" required>
                                                    <option value="">স্ট্যাটাস</option>
                                                    <?php $__currentLoopData = application_status_options(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($key); ?>" <?php echo e($application->status == $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <button type="submit" class="btn btn-sm btn-primary">
                                                    <i class='bx bx-save'></i>
                                                </button>
                                            </div>
                                        </form>
                                    </td>
                                    <td>
                                        <div><?php echo e($application->created_at->format('d/m/Y')); ?></div>
                                        <div class="small text-muted"><?php echo e($application->created_at->format('H:i')); ?></div>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm" role="group">
                                            <a href="<?php echo e(route('admin.applications.show', $application)); ?>" class="btn btn-primary" title="দেখুন">
                                                <i class='bx bx-show'></i>
                                            </a>
                                            <button class="btn btn-danger delete-application-btn" 
                                                    data-id="<?php echo e($application->id); ?>" 
                                                    data-name="<?php echo e($application->name); ?>"
                                                    title="মুছুন">
                                                <i class='bx bx-trash'></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="11" class="text-center py-5 fade-in">
                                        <div class="avatar avatar-lg bg-light-subtle text-muted rounded mx-auto mb-3">
                                            <i class='bx bx-file bx-lg'></i>
                                        </div>
                                        <h5 class="text-muted">কোন আবেদন পাওয়া যায়নি</h5>
                                        <p class="text-muted mb-0">এখনও কোন আবেদন জমা হয়নি।</p>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Bulk Actions -->
                    <div class="p-3 border-top bg-light-subtle d-flex justify-content-between align-items-center">
                        <div>
                            <button class="btn btn-sm btn-outline-primary" id="bulkAcceptBtn">
                                <i class='bx bx-badge-check me-1'></i>গৃহীত
                            </button>
                            <button class="btn btn-sm btn-outline-danger ms-2" id="bulkRejectBtn">
                                <i class='bx bx-x-circle me-1'></i>বাতিল
                            </button>
                        </div>
                        <?php if($applications->hasPages()): ?>
                        <div class="d-flex justify-content-center fade-in">
                            <?php echo e($applications->appends(request()->query())->links()); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<!-- Success Toasts -->
<div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index: 1051;">
    <div id="statusToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-header bg-success text-white">
            <strong class="me-auto">সফল</strong>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body">
            আবেদনের স্ট্যাটাস সফলভাবে আপডেট করা হয়েছে।
        </div>
    </div>
    
    <div id="deleteSuccessToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-header bg-success text-white">
            <strong class="me-auto">সফল</strong>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body">
            আবেদনটি সফলভাবে মুছে ফেলা হয়েছে।
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content border-0">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">আবেদন মুছে ফেলুন</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>আপনি কি নিশ্চিত যে আপনি <strong id="deleteApplicationName"></strong> নামের আবেদনটি মুছে ফেলতে চান?</p>
                <p class="text-muted">এই ক্রিয়াটি পূর্বাবস্থায় ফেরানো যাবে না।</p>
            </div>
            <div class="modal-footer bg-light">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">বাতিল</button>
                <button type="button" class="btn btn-danger" id="confirmDeleteBtn">মুছে ফেলুন</button>
            </div>
        </div>
    </div>
</div>

<!-- Status Update Error Modal -->
<div class="modal fade" id="statusErrorModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content border-0">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">স্ট্যাটাস আপডেট করতে সমস্যা</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p id="statusErrorMessage">স্ট্যাটাস আপডেট করতে সমস্যা হয়েছে।</p>
            </div>
            <div class="modal-footer bg-light">
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal">ঠিক আছে</button>
            </div>
        </div>
    </div>
</div>

<!-- Validation Error Modal -->
<div class="modal fade" id="validationErrorModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content border-0">
            <div class="modal-header bg-warning text-white">
                <h5 class="modal-title">অনুগ্রহ করে স্ট্যাটাস নির্বাচন করুন</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>স্ট্যাটাস আপডেট করতে হলে অবশ্যই একটি স্ট্যাটাস নির্বাচন করতে হবে।</p>
            </div>
            <div class="modal-footer bg-light">
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal">ঠিক আছে</button>
            </div>
        </div>
    </div>
</div>

<!-- Bulk Action Confirmation Modal -->
<div class="modal fade" id="bulkActionModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content border-0">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">বাল্ক অ্যাকশন নিশ্চিতকরণ</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p id="bulkActionMessage">আপনি কি নিশ্চিত যে আপনি নির্বাচিত আবেদনগুলোর স্ট্যাটাস পরিবর্তন করতে চান?</p>
            </div>
            <div class="modal-footer bg-light">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">বাতিল</button>
                <button type="button" class="btn btn-primary" id="confirmBulkActionBtn">নিশ্চিত করুন</button>
            </div>
        </div>
    </div>
</div>

<!-- Bulk Action Success Modal -->
<div class="modal fade" id="bulkActionSuccessModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content border-0">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title">সফল</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>আবেদনসমূহের স্ট্যাটাস সফলভাবে আপডেট করা হয়েছে।</p>
            </div>
            <div class="modal-footer bg-light">
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal" id="reloadPageBtn">ঠিক আছে</button>
            </div>
        </div>
    </div>
</div>

<!-- Add JavaScript variables for routes -->
<script>
    window.appRoutes = {
        bulkStatus: "<?php echo e(route('admin.applications.bulk-status')); ?>",
        deleteApplication: "<?php echo e(url('/admin/applications')); ?>"
    };
</script>

<style>
    /* Add specific animations for applications elements */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .fade-in {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    .fade-in:nth-child(1) { animation-delay: 0.1s; }
    .fade-in:nth-child(2) { animation-delay: 0.2s; }
    .fade-in:nth-child(3) { animation-delay: 0.3s; }
    .fade-in:nth-child(4) { animation-delay: 0.4s; }
    
    /* Ensure table rows have proper fade-in */
    .table tbody tr.fade-in {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    .table tbody tr.fade-in:nth-child(1) { animation-delay: 0.1s; }
    .table tbody tr.fade-in:nth-child(2) { animation-delay: 0.2s; }
    .table tbody tr.fade-in:nth-child(3) { animation-delay: 0.3s; }
    .table tbody tr.fade-in:nth-child(4) { animation-delay: 0.4s; }
    .table tbody tr.fade-in:nth-child(5) { animation-delay: 0.5s; }
    .table tbody tr.fade-in:nth-child(6) { animation-delay: 0.6s; }
    .table tbody tr.fade-in:nth-child(7) { animation-delay: 0.7s; }
    .table tbody tr.fade-in:nth-child(8) { animation-delay: 0.8s; }
    .table tbody tr.fade-in:nth-child(9) { animation-delay: 0.9s; }
    .table tbody tr.fade-in:nth-child(10) { animation-delay: 1.0s; }
    
    /* Card styling */
    .card {
        border-radius: 0.75rem;
        box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
    }
    
    /* Avatar styling */
    .avatar {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .avatar-sm {
        width: 2rem;
        height: 2rem;
        border-radius: 0.375rem;
    }
    
    .avatar-md {
        width: 3rem;
        height: 3rem;
        border-radius: 0.5rem;
    }
    
    .avatar-lg {
        width: 4rem;
        height: 4rem;
        border-radius: 0.75rem;
    }
    
    /* Table header styling */
    .table-light th {
        font-weight: 600;
        color: #495057;
    }
    
    /* Dark mode fixes */
    :root.dark-mode .card {
        background-color: #1e293b;
        border-color: #334155;
    }
    
    :root.dark-mode .card-header {
        background-color: #1e293b !important;
        border-color: #334155 !important;
    }
    
    :root.dark-mode .table-light th {
        background-color: #334155 !important;
        color: #f1f5f9 !important;
    }
    
    :root.dark-mode .table-hover tbody tr:hover {
        background-color: #334155 !important;
    }
    
    :root.dark-mode .table-bordered th,
    :root.dark-mode .table-bordered td {
        border-color: #334155 !important;
    }
    
    :root.dark-mode .form-control,
    :root.dark-mode .form-select {
        background-color: #1e293b;
        border-color: #334155;
        color: #f1f5f9;
    }
    
    :root.dark-mode .form-control:focus,
    :root.dark-mode .form-select:focus {
        background-color: #1e293b;
        border-color: #38bdf8;
        color: #f1f5f9;
        box-shadow: 0 0 0 0.25rem rgba(56, 189, 248, 0.25);
    }
    
    :root.dark-mode .modal-content {
        background-color: #1e293b;
    }
    
    :root.dark-mode .modal-header,
    :root.dark-mode .modal-footer {
        background-color: #334155 !important;
        border-color: #475569 !important;
    }
    
    :root.dark-mode .btn-close {
        filter: invert(1) grayscale(100%) brightness(200%);
    }
    
    /* Status badge improvements */
    .badge {
        font-size: 0.75em;
        padding: 0.5em 0.75em;
    }
    
    /* Button group spacing */
    .btn-group .btn {
        margin: 0;
    }
    
    /* Breadcrumb styling */
    .breadcrumb {
        background-color: transparent;
        padding: 0;
    }
    
    /* Search input styling */
    .input-group-text {
        border-radius: 0.375rem 0 0 0.375rem;
    }
    
    .form-control {
        border-radius: 0 0.375rem 0.375rem 0;
    }
    
    /* Subject badges */
    .badge.bg-primary-subtle {
        background-color: #dbeafe !important;
        color: #1d4ed8 !important;
    }
    
    .badge.bg-info-subtle {
        background-color: #cff4fc !important;
        color: #087990 !important;
    }
    
    .badge.bg-success-subtle {
        background-color: #d1fadf !important;
        color: #0a7641 !important;
    }
    
    .badge.bg-warning-subtle {
        background-color: #fff3cd !important;
        color: #856404 !important;
    }
    
    .badge.bg-danger-subtle {
        background-color: #f8d7da !important;
        color: #721c24 !important;
    }
    
    .badge.bg-secondary-subtle {
        background-color: #e2e8f0 !important;
        color: #475569 !important;
    }
    
    /* Dark mode subject badges */
    :root.dark-mode .badge.bg-primary-subtle {
        background-color: #1e3a8a !important;
        color: #93c5fd !important;
    }
    
    :root.dark-mode .badge.bg-info-subtle {
        background-color: #083344 !important;
        color: #67e8f9 !important;
    }
    
    :root.dark-mode .badge.bg-success-subtle {
        background-color: #052e16 !important;
        color: #4ade80 !important;
    }
    
    :root.dark-mode .badge.bg-warning-subtle {
        background-color: #856404 !important;
        color: #fef3c7 !important;
    }
    
    :root.dark-mode .badge.bg-danger-subtle {
        background-color: #721c24 !important;
        color: #f8d7da !important;
    }
    
    :root.dark-mode .badge.bg-secondary-subtle {
        background-color: #1e293b !important;
        color: #cbd5e1 !important;
    }
    
    /* Status button styling */
    .status-update-btn {
        border: none;
        padding: 0.25rem 0.5rem;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .status-update-btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
    }
    
    .status-update-btn:focus {
        box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.25);
        outline: none;
    }
    
    .status-update-btn i {
        font-size: 1rem;
    }
    
    /* Toast styling */
    .toast {
        border: none;
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
    }
    
    /* Page header styling */
    .page-header {
        background-color: #f8f9fa;
        border-radius: 0.5rem;
    }
    
    /* Dark mode page header */
    :root.dark-mode .page-header {
        background-color: #1e293b;
    }
    
    :root.dark-mode .page-header h4 {
        color: #f1f5f9;
    }
    
    :root.dark-mode .page-header .text-muted {
        color: #94a3b8 !important;
    }
    
    /* Dark mode breadcrumb */
    :root.dark-mode .breadcrumb .breadcrumb-item a {
        color: #93c5fd;
    }
    
    :root.dark-mode .breadcrumb .breadcrumb-item.active {
        color: #cbd5e1;
    }
    
    /* Table styling fixes */
    .table-responsive {
        overflow-x: visible;
    }
    
    @media (max-width: 768px) {
        .table-responsive {
            overflow-x: auto;
        }
        
        .table th, .table td {
            white-space: nowrap;
        }
    }
    
    /* Summary cards */
    .summary-card {
        transition: all 0.3s ease;
        border-radius: 0.75rem;
        overflow: hidden;
    }
    
    .summary-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 1rem 2rem rgba(0, 0, 0, 0.15) !important;
    }
    
    .summary-card .card-body {
        padding: 1.25rem 1rem;
    }
    
    .summary-card h5 {
        font-size: 1.5rem;
        margin-bottom: 0.5rem;
    }
    
    .summary-card .avatar {
        width: 3.5rem;
        height: 3.5rem;
        font-size: 1.25rem;
    }
    
    /* Responsive adjustments for summary cards */
    @media (max-width: 768px) {
        .summary-card h5 {
            font-size: 1.25rem;
        }
        
        .summary-card .avatar {
            width: 3rem;
            height: 3rem;
            font-size: 1rem;
        }
        
        .summary-card .card-body {
            padding: 1rem 0.75rem;
        }
    }
    
    @media (max-width: 576px) {
        .summary-card h5 {
            font-size: 1.1rem;
        }
        
        .summary-card .avatar {
            width: 2.5rem;
            height: 2.5rem;
            font-size: 0.875rem;
        }
    }
    
    /* Filter form responsiveness */
    @media (max-width: 768px) {
        .d-flex.flex-wrap.gap-2 > * {
            margin-bottom: 0.5rem;
        }
    }
    
    /* Status update form in table */
    .status-update-form .form-select {
        min-width: 120px;
    }
    
    .status-update-form .input-group {
        flex-wrap: nowrap;
    }
    
    @media (max-width: 768px) {
        .status-update-form .form-select {
            min-width: 100px;
            font-size: 0.875rem;
        }
        
        .status-update-form .btn {
            padding: 0.25rem 0.5rem;
        }
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {

        
        // Search functionality
        const searchInput = document.querySelector('input[name="search"]');
        if (searchInput) {
            searchInput.addEventListener('keyup', function(event) {
                if (event.key === 'Enter') {
                    event.preventDefault();
                    const form = this.closest('form');
                    if (form) form.submit();
                }
            });
        }
        
        // Status update form functionality
        const statusForms = document.querySelectorAll('.status-update-form');
        const toastEl = document.getElementById('statusToast');
        const toast = new bootstrap.Toast(toastEl, { delay: 3000 });
        
        statusForms.forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // Extract application ID from form action
                const urlMatch = this.action.match(/admin\/applications\/(\d+)(?:\/status)?/);
                const applicationId = urlMatch ? urlMatch[1] : null;
                
                const statusSelect = this.querySelector('.status-select');
                const newStatus = statusSelect.value;
                const submitButton = this.querySelector('button[type="submit"]');
                
                // Log the form action for debugging
                console.log('Form action URL:', this.action);
                console.log('URL match result:', urlMatch);
                console.log('Application ID extracted:', applicationId);
                
                // Validate selection
                if (!newStatus) {
                    // Show validation error modal instead of alert
                    const validationModal = new bootstrap.Modal(document.getElementById('validationErrorModal'));
                    validationModal.show();
                    return;
                }
                
                // Validate application ID
                if (!applicationId) {
                    // Show error modal with specific message
                    const errorModal = new bootstrap.Modal(document.getElementById('statusErrorModal'));
                    document.getElementById('statusErrorMessage').textContent = 'Invalid application ID. Please try again.';
                    errorModal.show();
                    return;
                }
                
                // Log the request for debugging
                console.log('Sending status update request:', {
                    applicationId: applicationId,
                    newStatus: newStatus,
                    actionUrl: this.action
                });
                
                // Show loading state
                const originalText = submitButton.innerHTML;
                submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';
                submitButton.disabled = true;
                
                // Create form data
                const formData = new FormData();
                formData.append('status', newStatus);
                formData.append('_method', 'PUT');
                formData.append('_token', document.querySelector('meta[name="csrf-token"]').getAttribute('content'));
                
                // Log the actual request details
                console.log('Request details:', {
                    url: this.action,
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: {
                        status: newStatus,
                        _method: 'PUT'
                    }
                });
                
                // Send AJAX request to update status
                fetch(this.action, {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: formData
                })
                .then(async response => {
                    console.log('Response received:', {
                        status: response.status,
                        statusText: response.statusText,
                        url: response.url,
                        contentType: response.headers.get('content-type'),
                        redirectUrl: response.redirected ? response.url : null
                    });
                    
                    // Check if it's a redirect (which would indicate auth/session issues)
                    if (response.redirected && response.url.includes('login')) {
                        throw new Error('Authentication required. Please refresh the page and try again.');
                    }
                    
                    if (!response.ok) {
                        // Try to get response text for debugging
                        const responseText = await response.clone().text();
                        console.log('Error response text:', responseText.substring(0, 500));
                        
                        // For error responses, try to parse as JSON first, fallback to text
                        const contentType = response.headers.get('content-type');
                        const isJson = contentType && (contentType.includes('application/json') || contentType.includes('text/json'));
                        
                        if (isJson) {
                            try {
                                const data = await response.json();
                                const errorMessage = data.message || data.error || 'Validation failed';
                                throw new Error(errorMessage);
                            } catch (jsonError) {
                                // If JSON parsing fails, try to get text
                                if (response.status === 422) {
                                    throw new Error('Validation failed');
                                } else if (response.status >= 500) {
                                    throw new Error('Server error. Please try again later.');
                                } else {
                                    throw new Error(`HTTP error! status: ${response.status}`);
                                }
                            }
                        } else {
                            // If not JSON, it's likely an HTML error page
                            // Try to get response text to see what we're getting
                            console.log('Non-JSON response content:', responseText.substring(0, 500) + (responseText.length > 500 ? '...' : ''));
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }
                    }
                    
                    // Check if response is JSON
                    const contentType = response.headers.get('content-type');
                    const isJson = contentType && (contentType.includes('application/json') || contentType.includes('text/json'));
                    
                    // If response is not JSON, log what we got and throw an error
                    if (!isJson) {
                        // Try to get response text to see what we're getting
                        const responseClone = response.clone(); // Clone to avoid consuming the response
                        const responseText = await responseClone.text();
                        console.log('Non-JSON response content:', responseText.substring(0, 500) + (responseText.length > 500 ? '...' : ''));
                        
                        // Check if it looks like HTML
                        if (responseText.trim().startsWith('<!DOCTYPE') || responseText.trim().startsWith('<html')) {
                            throw new Error('Authentication required or session expired. Please refresh the page and try again.');
                        }
                        
                        throw new Error('Server returned an unexpected response. Please try again later.');
                    }
                    
                    return response.json();
                })
                .then(data => {
                    console.log('Response data:', data);
                    
                    if (data && data.success) {
                        // Show success toast
                        toast.show();
                        
                        // Reload the page to reflect the status change
                        setTimeout(() => {
                            location.reload();
                        }, 1000);
                    } else {
                        console.error('Server returned error:', data);
                        const errorMessage = data && data.message ? data.message : (data && data.error ? data.error : 'Unknown error occurred');
                        // Show error modal instead of alert
                        const errorModal = new bootstrap.Modal(document.getElementById('statusErrorModal'));
                        document.getElementById('statusErrorMessage').textContent = 'স্ট্যাটাস আপডেট করতে সমস্যা হয়েছে: ' + errorMessage;
                        errorModal.show();
                    }
                })
                .catch(error => {
                    console.error('Network or parsing error:', error);
                    // Show error modal instead of alert
                    const errorModal = new bootstrap.Modal(document.getElementById('statusErrorModal'));
                    // Check if it's a JSON parsing error
                    if (error.message && error.message.includes('Unexpected token')) {
                        document.getElementById('statusErrorMessage').textContent = 'স্ট্যাটাস আপডেট করতে সমস্যা হয়েছে: Server error occurred. Please try again later.';
                    } else {
                        document.getElementById('statusErrorMessage').textContent = 'স্ট্যাটাস আপডেট করতে সমস্যা হয়েছে: ' + error.message;
                    }
                    errorModal.show();
                })
                .finally(() => {
                    // Restore button state
                    submitButton.innerHTML = originalText;
                    submitButton.disabled = false;
                });
            });
        });
        
        // Delete application functionality
        const deleteButtons = document.querySelectorAll('.delete-application-btn');
        const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
        let currentApplicationId = null;
        
        deleteButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                
                currentApplicationId = this.getAttribute('data-id');
                const applicationName = this.getAttribute('data-name');
                
                // Set application name in modal
                document.getElementById('deleteApplicationName').textContent = applicationName;
                
                // Show delete confirmation modal
                deleteModal.show();
            });
        });
        
        // Confirm delete button in modal
        document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
            if (!currentApplicationId) return;
            
            // Construct the URL using the application ID and the route helper
            const baseUrl = window.appRoutes.deleteApplication;
            const url = `${baseUrl}/${currentApplicationId}`;
            
            console.log('Sending DELETE request to:', url);
            console.log('Application ID:', currentApplicationId);
            console.log('Base URL:', baseUrl);
            console.log('Window location:', window.location.href);
            
            // Create URL-encoded form data for method spoofing
            const params = new URLSearchParams();
            params.append('_method', 'DELETE');
            params.append('_token', document.querySelector('meta[name="csrf-token"]').getAttribute('content'));
            
            // Send AJAX request to delete application using method spoofing
            fetch(url, {
                method: 'POST',
                body: params,
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(async response => {
                // Log response details for debugging
                console.log('Delete response:', {
                    status: response.status,
                    statusText: response.statusText,
                    url: response.url,
                    headers: [...response.headers.entries()]
                });
                
                if (!response.ok) {
                    // Try to get response text for debugging
                    const responseText = await response.clone().text();
                    console.log('Error response text:', responseText.substring(0, 500));
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                
                // Check if response is JSON or redirect
                const contentType = response.headers.get('content-type');
                if (contentType && contentType.includes('application/json')) {
                    return response.json();
                } else {
                    // If it's a redirect, reload the page
                    location.reload();
                    return;
                }
            })
            .then(data => {
                if (data && data.success) {
                    // Hide modal
                    deleteModal.hide();
                    
                    // Show success toast
                    const deleteSuccessToastEl = document.getElementById('deleteSuccessToast');
                    const deleteSuccessToast = new bootstrap.Toast(deleteSuccessToastEl, { delay: 3000 });
                    deleteSuccessToast.show();
                    
                    // Reload the page after a short delay to allow the toast to be seen
                    setTimeout(() => {
                        location.reload();
                    }, 2000);
                } else if (data) {
                    console.error('Server returned error:', data);
                    alert('আবেদনটি মুছে ফেলতে সমস্যা হয়েছে।');
                }
            })
            .catch(error => {
                console.error('Network or parsing error:', error);
                alert('আবেদনটি মুছে ফেলতে সমস্যা হয়েছে: ' + error.message);
                // In case of network error, still reload to show current state
                location.reload();
            });
        });
        
        // Select all checkboxes
        const selectAllCheckbox = document.getElementById('selectAll');
        const applicationCheckboxes = document.querySelectorAll('.application-checkbox');
        
        if (selectAllCheckbox) {
            selectAllCheckbox.addEventListener('change', function() {
                applicationCheckboxes.forEach(checkbox => {
                    checkbox.checked = this.checked;
                });
            });
        }
        
        // Bulk actions
        const bulkAcceptBtn = document.getElementById('bulkAcceptBtn');
        const bulkRejectBtn = document.getElementById('bulkRejectBtn');
        const bulkActionModal = new bootstrap.Modal(document.getElementById('bulkActionModal'));
        const bulkActionSuccessModal = new bootstrap.Modal(document.getElementById('bulkActionSuccessModal'));
        const statusErrorModal = new bootstrap.Modal(document.getElementById('statusErrorModal'));
        
        // Store bulk action data
        let bulkActionData = {
            applicationIds: [],
            status: ''
        };
        
        if (bulkAcceptBtn) {
            bulkAcceptBtn.addEventListener('click', function() {
                const selectedApplications = Array.from(applicationCheckboxes)
                    .filter(checkbox => checkbox.checked)
                    .map(checkbox => checkbox.getAttribute('data-id'));
                
                if (selectedApplications.length === 0) {
                    // Show validation error modal instead of alert
                    const validationModal = new bootstrap.Modal(document.getElementById('validationErrorModal'));
                    document.querySelector('#validationErrorModal .modal-body p').textContent = 'অনুগ্রহ করে কমপক্ষে একটি আবেদন নির্বাচন করুন।';
                    validationModal.show();
                    return;
                }
                
                // Set bulk action data
                bulkActionData.applicationIds = selectedApplications;
                bulkActionData.status = 'accepted';
                
                // Show confirmation modal
                document.getElementById('bulkActionMessage').textContent = `আপনি কি নিশ্চিত যে আপনি ${selectedApplications.length} টি আবেদন গৃহীত হিসেবে চিহ্নিত করতে চান?`;
                bulkActionModal.show();
            });
        }
        
        if (bulkRejectBtn) {
            bulkRejectBtn.addEventListener('click', function() {
                const selectedApplications = Array.from(applicationCheckboxes)
                    .filter(checkbox => checkbox.checked)
                    .map(checkbox => checkbox.getAttribute('data-id'));
                
                if (selectedApplications.length === 0) {
                    // Show validation error modal instead of alert
                    const validationModal = new bootstrap.Modal(document.getElementById('validationErrorModal'));
                    document.querySelector('#validationErrorModal .modal-body p').textContent = 'অনুগ্রহ করে কমপক্ষে একটি আবেদন নির্বাচন করুন।';
                    validationModal.show();
                    return;
                }
                
                // Set bulk action data
                bulkActionData.applicationIds = selectedApplications;
                bulkActionData.status = 'rejected';
                
                // Show confirmation modal
                document.getElementById('bulkActionMessage').textContent = `আপনি কি নিশ্চিত যে আপনি ${selectedApplications.length} টি আবেদন বাতিল হিসেবে চিহ্নিত করতে চান?`;
                bulkActionModal.show();
            });
        }
        
        // Confirm bulk action button
        document.getElementById('confirmBulkActionBtn').addEventListener('click', function() {
            // Close confirmation modal
            bulkActionModal.hide();
            
            // Perform bulk action
            updateBulkStatus(bulkActionData.applicationIds, bulkActionData.status);
        });
        
        // Reload page button
        document.getElementById('reloadPageBtn').addEventListener('click', function() {
            location.reload();
        });
        
        // Function to update bulk status
        function updateBulkStatus(applicationIds, status) {
            // Show loading state if we had a loading indicator
            console.log('Sending bulk status update request:', {
                application_ids: applicationIds,
                status: status
            });
            
            // Use Laravel-generated route URL
            const bulkStatusUrl = window.appRoutes.bulkStatus;
            
            // Log the final URL for debugging
            console.log('Final bulk status URL:', bulkStatusUrl);
            
            fetch(bulkStatusUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    application_ids: applicationIds,
                    status: status
                })
            })
            .then(async response => {
                console.log('Bulk status response received:', {
                    status: response.status,
                    statusText: response.statusText,
                    url: response.url,
                    contentType: response.headers.get('content-type')
                });
                
                if (!response.ok) {
                    // Try to parse error response
                    const contentType = response.headers.get('content-type');
                    if (contentType && contentType.includes('application/json')) {
                        try {
                            const errorData = await response.json();
                            throw new Error(errorData.message || 'HTTP error ' + response.status);
                        } catch (e) {
                            throw new Error('HTTP error ' + response.status);
                        }
                    } else {
                        throw new Error('HTTP error ' + response.status);
                    }
                }
                
                // Check if response is JSON
                const contentType = response.headers.get('content-type');
                if (!contentType || !contentType.includes('application/json')) {
                    throw new Error('Server returned invalid response format');
                }
                
                return response.json();
            })
            .then(data => {
                console.log('Bulk status response data:', data);
                
                if (data && data.success) {
                    // Show success modal
                    bulkActionSuccessModal.show();
                } else {
                    // Show error modal
                    document.getElementById('statusErrorMessage').textContent = data.message || 'স্ট্যাটাস আপডেট করতে সমস্যা হয়েছে।';
                    statusErrorModal.show();
                }
            })
            .catch(error => {
                console.error('Network or parsing error:', error);
                // Show error modal
                document.getElementById('statusErrorMessage').textContent = 'স্ট্যাটাস আপডেট করতে সমস্যা হয়েছে: ' + error.message;
                statusErrorModal.show();
            });
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/saimumba/shilpigosthi.com/resources/views/admin/applications/index.blade.php ENDPATH**/ ?>