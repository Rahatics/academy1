

<?php $__env->startSection('title', 'আমাদের সম্পর্কে - সাইমুম শিল্পীগোষ্ঠী'); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <h1 class="section-title">আমাদের সম্পর্কে</h1>
    
    <div class="row">
        <div class="col-lg-8">
            <div class="card mb-4">
                <div class="card-body">
                    <h3><?php echo e(organization_info('name')); ?></h3>
                    <p>
                        <?php echo e(organization_info('name')); ?> বাংলাদেশের একটি প্রতিষ্ঠিত সাংস্কৃতিক সংগঠন যা <?php echo e(organization_info('founded')); ?> সাল থেকে ইসলামী মূল্যবোধ ও 
                        সংস্কৃতি ছড়িয়ে দিচ্ছে সারা দেশে। আমাদের সংগঠন গান, আলোচনা, নাটক ও অন্যান্য সাংস্কৃতিক কার্যক্রমের 
                        মাধ্যমে সমাজে ইতিবাচক প্রভাব ফেলে যাচ্ছে।
                    </p>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-body">
                    <h4 class="section-title">আমাদের ইতিহাস</h4>
                    <p>
                        <?php echo e(organization_info('founded')); ?> সালে প্রতিষ্ঠিত <?php echo e(organization_info('name')); ?> বাংলাদেশের সবচেয়ে প্রতিষ্ঠিত সাংস্কৃতিক সংগঠনগুলোর একটি। 
                        সংগঠনটি প্রতিষ্ঠার পর থেকেই ইসলামী মূল্যবোধ ও সংস্কৃতি ছড়িয়ে দেওয়ার জন্য নানান সাংস্কৃতিক কার্যক্রম 
                        পরিচালনা করে আসছে।
                    </p>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-body">
                    <h4 class="section-title">আমাদের লক্ষ্য ও উদ্দেশ্য</h4>
                    <ul>
                        <li>ইসলামী মূল্যবোধ ছড়িয়ে দেওয়া</li>
                        <li>সমাজে সাংস্কৃতিক উন্নয়ন ঘটানো</li>
                        <li>তরুণদের মধ্যে সংস্কৃতির চেতনা তৈরি করা</li>
                        <li>দেশের সাংস্কৃতিক ঐতিহ্য সংরক্ষণ ও উন্নয়ন</li>
                        <li>সামাজিক সচেতনতা বৃদ্ধি করা</li>
                    </ul>
                </div>
            </div>
            
            <div class="card">
                <div class="card-body">
                    <h4 class="section-title">আমাদের কার্যক্রম</h4>
                    <p>
                        আমরা নানান সাংস্কৃতিক কার্যক্রমের মাধ্যমে সমাজে ইতিবাচক প্রভাব ফেলে যাচ্ছি। গান, আলোচনা, নাটক, 
                        মাহফিল ইত্যাদি আমাদের প্রধান কার্যক্রম। এছাড়াও বিভিন্ন জাতীয় ও সামাজিক অনুষ্ঠানে আমরা অংশ নিয়ে থাকি।
                    </p>
                    
                    <h4 class="section-title mt-4">আমাদের ভিশন</h4>
                    <p>
                        আমাদের ভিশন হলো একটি সুসংস্কৃত সমাজ গঠন করা যেখানে প্রতিটি মানুষ ইসলামী মূল্যবোধের আলোকে জীবন যাপন করবে 
                        এবং সাংস্কৃতিক ঐতিহ্যকে সম্মান করবে।
                    </p>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h4>গুরুত্বপূর্ণ তথ্য</h4>
                </div>
                <div class="card-body">
                    <p><strong>প্রতিষ্ঠাকাল:</strong> <?php echo e(organization_info('founded')); ?></p>
                    <p><strong>প্রতিষ্ঠাতা:</strong> সাইমুম</p>
                    <p><strong>অফিস:</strong> <?php echo e(organization_info('address')); ?></p>
                    <p><strong>ইমেইল:</strong> <?php echo e(organization_info('email')); ?></p>
                    <p><strong>ফোন:</strong> <?php echo e(organization_info('phone')); ?></p>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h4>সামাজিক মাধ্যম</h4>
                </div>
                <div class="card-body">
                    <p><a href="<?php echo e(config('saimum.social_media.facebook')); ?>" target="_blank">Facebook</a></p>
                    <p><a href="<?php echo e(config('saimum.social_media.instagram')); ?>" target="_blank">Instagram</a></p>
                    <p><a href="<?php echo e(config('saimum.social_media.twitter')); ?>" target="_blank">Twitter</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\All Project\1V2\saium-shilpigosthi\resources\views/about.blade.php ENDPATH**/ ?>