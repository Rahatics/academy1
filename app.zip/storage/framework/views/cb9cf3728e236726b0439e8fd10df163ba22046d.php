<?php $__env->startSection('title', 'পেমেন্টসমূহ - অ্যাডমিন প্যানেল'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex align-items-center justify-content-between mb-4 fade-in py-2 px-3 rounded page-header">
        <div>
            <h4 class="mb-0 fw-bold">পেমেন্টসমূহ</h4>
            <p class="text-muted mb-0 small">সকল পেমেন্টের তালিকা এবং ব্যবস্থাপনা</p>
        </div>
        <div>
            <ol class="breadcrumb mb-0 bg-transparent">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>" class="text-decoration-none">হোম</a></li>
                <li class="breadcrumb-item active" aria-current="page">পেমেন্টসমূহ</li>
            </ol>
        </div>
    </div>

    <!-- Summary Cards -->
    <div class="row mb-4 fade-in g-3 justify-content-center">
        <div class="col-6 col-md-4 col-lg mb-3">
            <div class="card border-0 shadow-sm h-100 summary-card">
                <div class="card-body text-center py-3">
                    <div class="avatar avatar-md bg-primary bg-opacity-10 text-primary rounded mx-auto mb-2">
                        <i class='bx bx-money fs-4'></i>
                    </div>
                    <h5 class="mb-1 fw-bold"><?php echo e(number_format($payments->total(), 0)); ?></h5>
                    <p class="text-muted mb-0 small">মোট পেমেন্ট</p>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-4 col-lg mb-3">
            <div class="card border-0 shadow-sm h-100 summary-card">
                <div class="card-body text-center py-3">
                    <div class="avatar avatar-md bg-success bg-opacity-10 text-success rounded mx-auto mb-2">
                        <i class='bx bx-check-circle fs-4'></i>
                    </div>
                    <h5 class="mb-1 fw-bold"><?php echo e(number_format($payments->where('status', 'completed')->count(), 0)); ?></h5>
                    <p class="text-muted mb-0 small">সফল</p>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-4 col-lg mb-3">
            <div class="card border-0 shadow-sm h-100 summary-card">
                <div class="card-body text-center py-3">
                    <div class="avatar avatar-md bg-warning bg-opacity-10 text-warning rounded mx-auto mb-2">
                        <i class='bx bx-error fs-4'></i>
                    </div>
                    <h5 class="mb-1 fw-bold"><?php echo e(number_format($payments->where('status', 'failed')->count(), 0)); ?></h5>
                    <p class="text-muted mb-0 small">ব্যর্থ</p>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-4 col-lg mb-3">
            <div class="card border-0 shadow-sm h-100 summary-card">
                <div class="card-body text-center py-3">
                    <div class="avatar avatar-md bg-info bg-opacity-10 text-info rounded mx-auto mb-2">
                        <i class='bx bx-credit-card fs-4'></i>
                    </div>
                    <h5 class="mb-1 fw-bold"><?php echo e(number_format($payments->where('gateway', 'bkash')->count(), 0)); ?></h5>
                    <p class="text-muted mb-0 small">bKash</p>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-4 col-lg mb-3">
            <div class="card border-0 shadow-sm h-100 summary-card">
                <div class="card-body text-center py-3">
                    <div class="avatar avatar-md bg-secondary bg-opacity-10 text-secondary rounded mx-auto mb-2">
                        <i class='bx bx-calculator fs-4'></i>
                    </div>
                    <h5 class="mb-1 fw-bold">
                        <?php
                            $totalAmount = $payments->sum('amount');
                            echo number_format($totalAmount, 2);
                        ?>
                    </h5>
                    <p class="text-muted mb-0 small">মোট টাকা (BDT)</p>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12 fade-in">
            <div class="card border-0 shadow-sm">
                <div class="card-body p-0">
                    <!-- Table Header with Filters -->
                    <div class="p-4 border-bottom">
                        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">
                            <h5 class="mb-0">সকল পেমেন্ট</h5>
                            <div class="d-flex flex-wrap gap-2">
                                <!-- Filter Form -->
                                <form method="GET" class="d-flex flex-wrap gap-2">
                                    <!-- Status Filter -->
                                    <select name="status" class="form-select" style="width: 150px;">
                                        <option value="">সকল স্ট্যাটাস</option>
                                        <?php $__currentLoopData = $distinctStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($status); ?>" <?php echo e(request('status') == $status ? 'selected' : ''); ?>>
                                                <?php echo e(ucfirst($status)); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    
                                    <!-- Gateway Filter -->
                                    <select name="gateway" class="form-select" style="width: 150px;">
                                        <option value="">সকল গেটওয়ে</option>
                                        <?php $__currentLoopData = $distinctGateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($gateway); ?>" <?php echo e(request('gateway') == $gateway ? 'selected' : ''); ?>>
                                                <?php echo e(ucfirst($gateway)); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    
                                    <!-- Date Range -->
                                    <input type="date" name="from" class="form-control" style="width: 140px;" value="<?php echo e(request('from')); ?>" placeholder="শুরু">
                                    <input type="date" name="to" class="form-control" style="width: 140px;" value="<?php echo e(request('to')); ?>" placeholder="শেষ">
                                    
                                    <button type="submit" class="btn btn-primary">
                                        <i class='bx bx-filter-alt me-1'></i>ফিল্টার
                                    </button>
                                    
                                    <a href="<?php echo e(route('admin.payments.index')); ?>" class="btn btn-outline-secondary">
                                        <i class='bx bx-reset'></i>
                                    </a>
                                    
                                    <a href="<?php echo e(route('admin.payments.export', request()->only(['status','gateway','from','to']))); ?>" class="btn btn-success">
                                        <i class='bx bx-export me-1'></i>Export
                                    </a>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Payments Table -->
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0" id="paymentsTable">
                            <thead class="table-light">
                                <tr>
                                    <th width="10%">আবেদন আইডি</th>
                                    <th width="12%">শিক্ষার্থির নাম</th>
                                    <th width="8%">গেটওয়ে</th>
                                    <th width="10%">স্ট্যাটাস</th>
                                    <th width="10%">পরিমাণ</th>
                                    <th width="10%">ইনভয়েস</th>
                                    <th width="15%">লেনদেন আইডি</th>
                                    <th width="12%">তৈরির তারিখ</th>
                                    <th width="8%">অ্যাকশন</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="fade-in">
                                    <td class="text-truncate" style="max-width: 120px;" title="<?php echo e($payment->application->application_id ?? $payment->application_id ?? 'N/A'); ?>">
                                        <?php if($payment->application): ?>
                                            <?php echo e($payment->application->application_id ?? 'N/A'); ?>

                                        <?php else: ?>
                                            <?php echo e($payment->application_id ?? 'N/A'); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td class="text-truncate" style="max-width: 150px;" title="<?php echo e($payment->application->name ?? 'N/A'); ?>">
                                        <?php echo e($payment->application->name ?? 'N/A'); ?>

                                    </td>
                                    <td>
                                        <?php if($payment->gateway == 'bkash'): ?>
                                            <span class="badge bg-info-subtle text-info-emphasis p-1">
                                                bKash
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary-subtle text-secondary-emphasis p-1">
                                                <?php echo e(ucfirst($payment->gateway ?? 'N/A')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($payment->status == 'completed'): ?>
                                            <span class="badge bg-success-subtle text-success-emphasis p-1">
                                                সফল
                                            </span>
                                        <?php elseif($payment->status == 'failed'): ?>
                                            <span class="badge bg-danger-subtle text-danger-emphasis p-1">
                                                ব্যর্থ
                                            </span>
                                        <?php elseif($payment->status == 'pending'): ?>
                                            <span class="badge bg-warning-subtle text-warning-emphasis p-1">
                                                অপেক্ষমান
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary-subtle text-secondary-emphasis p-1">
                                                <?php echo e(ucfirst($payment->status ?? 'N/A')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="fw-bold"><?php echo e(number_format($payment->amount, 2)); ?> <?php echo e($payment->currency ?? 'BDT'); ?></td>
                                    <td class="text-truncate" style="max-width: 120px;" title="<?php echo e($payment->application->internal_invoice ?? 'N/A'); ?>">
                                        <?php echo e($payment->application->internal_invoice ?? 'N/A'); ?>

                                    </td>
                                    <td class="text-truncate" style="max-width: 180px;" title="<?php echo e($payment->transaction_id ?? 'N/A'); ?>">
                                        <?php echo e($payment->transaction_id ?? 'N/A'); ?>

                                    </td>
                                    <td><?php echo e($payment->created_at->format('d/m/Y H:i')); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.payments.show', $payment)); ?>" class="btn btn-sm btn-primary" title="দেখুন">
                                            <i class='bx bx-show'></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="9" class="text-center py-5 fade-in">
                                        <div class="avatar avatar-lg bg-light-subtle text-muted rounded mx-auto mb-3">
                                            <i class='bx bx-money bx-lg'></i>
                                        </div>
                                        <h5 class="text-muted">কোন পেমেন্ট পাওয়া যায়নি</h5>
                                        <p class="text-muted mb-0">এখনও কোন পেমেন্ট রেকর্ড নেই।</p>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <?php if($payments->hasPages()): ?>
                    <div class="p-3 border-top bg-light-subtle d-flex justify-content-center fade-in">
                        <?php echo e($payments->appends(request()->query())->links()); ?>

                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Add specific animations for payments elements */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .fade-in {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    .fade-in:nth-child(1) { animation-delay: 0.1s; }
    .fade-in:nth-child(2) { animation-delay: 0.2s; }
    .fade-in:nth-child(3) { animation-delay: 0.3s; }
    .fade-in:nth-child(4) { animation-delay: 0.4s; }
    
    /* Ensure table rows have proper fade-in */
    .table tbody tr.fade-in {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    .table tbody tr.fade-in:nth-child(1) { animation-delay: 0.1s; }
    .table tbody tr.fade-in:nth-child(2) { animation-delay: 0.2s; }
    .table tbody tr.fade-in:nth-child(3) { animation-delay: 0.3s; }
    .table tbody tr.fade-in:nth-child(4) { animation-delay: 0.4s; }
    .table tbody tr.fade-in:nth-child(5) { animation-delay: 0.5s; }
    .table tbody tr.fade-in:nth-child(6) { animation-delay: 0.6s; }
    .table tbody tr.fade-in:nth-child(7) { animation-delay: 0.7s; }
    .table tbody tr.fade-in:nth-child(8) { animation-delay: 0.8s; }
    .table tbody tr.fade-in:nth-child(9) { animation-delay: 0.9s; }
    .table tbody tr.fade-in:nth-child(10) { animation-delay: 1.0s; }
    
    /* Card styling */
    .card {
        border-radius: 0.75rem;
        box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
    }
    
    /* Table header styling */
    .table-light th {
        font-weight: 600;
        color: #495057;
    }
    
    /* Dark mode fixes */
    :root.dark-mode .card {
        background-color: #1e293b;
        border-color: #334155;
    }
    
    :root.dark-mode .card-header {
        background-color: #1e293b !important;
        border-color: #334155 !important;
    }
    
    :root.dark-mode .table-light th {
        background-color: #334155 !important;
        color: #f1f5f9 !important;
    }
    
    :root.dark-mode .table-hover tbody tr:hover {
        background-color: #334155 !important;
    }
    
    :root.dark-mode .table-bordered th,
    :root.dark-mode .table-bordered td {
        border-color: #334155 !important;
    }
    
    :root.dark-mode .form-control,
    :root.dark-mode .form-select {
        background-color: #1e293b;
        border-color: #334155;
        color: #f1f5f9;
    }
    
    :root.dark-mode .form-control:focus,
    :root.dark-mode .form-select:focus {
        background-color: #1e293b;
        border-color: #38bdf8;
        color: #f1f5f9;
        box-shadow: 0 0 0 0.25rem rgba(56, 189, 248, 0.25);
    }
    
    .table td {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    
    /* Status badge improvements */
    .badge {
        font-size: 0.75em;
        padding: 0.25em 0.5em;
    }
    
    /* Breadcrumb styling */
    .breadcrumb {
        background-color: transparent;
        padding: 0;
    }
    
    /* Subject badges */
    .badge.bg-primary-subtle {
        background-color: #dbeafe !important;
        color: #1d4ed8 !important;
    }
    
    .badge.bg-info-subtle {
        background-color: #cff4fc !important;
        color: #087990 !important;
    }
    
    .badge.bg-success-subtle {
        background-color: #d1fadf !important;
        color: #0a7641 !important;
    }
    
    .badge.bg-warning-subtle {
        background-color: #fff3cd !important;
        color: #856404 !important;
    }
    
    .badge.bg-danger-subtle {
        background-color: #f8d7da !important;
        color: #721c24 !important;
    }
    
    .badge.bg-secondary-subtle {
        background-color: #e2e8f0 !important;
        color: #475569 !important;
    }
    
    /* Dark mode subject badges */
    :root.dark-mode .badge.bg-primary-subtle {
        background-color: #1e3a8a !important;
        color: #93c5fd !important;
    }
    
    :root.dark-mode .badge.bg-info-subtle {
        background-color: #083344 !important;
        color: #67e8f9 !important;
    }
    
    :root.dark-mode .badge.bg-success-subtle {
        background-color: #052e16 !important;
        color: #4ade80 !important;
    }
    
    :root.dark-mode .badge.bg-warning-subtle {
        background-color: #856404 !important;
        color: #fef3c7 !important;
    }
    
    :root.dark-mode .badge.bg-danger-subtle {
        background-color: #721c24 !important;
        color: #f8d7da !important;
    }
    
    :root.dark-mode .badge.bg-secondary-subtle {
        background-color: #1e293b !important;
        color: #cbd5e1 !important;
    }
    
    /* Page header styling */
    .page-header {
        background-color: #f8f9fa;
        border-radius: 0.5rem;
    }
    
    /* Dark mode page header */
    :root.dark-mode .page-header {
        background-color: #1e293b;
    }
    
    :root.dark-mode .page-header h4 {
        color: #f1f5f9;
    }
    
    :root.dark-mode .page-header .text-muted {
        color: #94a3b8 !important;
    }
    
    :root.dark-mode .breadcrumb .breadcrumb-item a {
        color: #93c5fd;
    }
    
    :root.dark-mode .breadcrumb .breadcrumb-item.active {
        color: #cbd5e1;
    }
    
    /* Table styling fixes */
    .table-responsive {
        overflow-x: auto;
    }
    
    /* Summary cards */
    .summary-card {
        transition: all 0.3s ease;
        border-radius: 0.75rem;
        overflow: hidden;
    }
    
    .summary-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 1rem 2rem rgba(0, 0, 0, 0.15) !important;
    }
    
    .summary-card .card-body {
        padding: 1.25rem 1rem;
    }
    
    .summary-card h5 {
        font-size: 1.5rem;
        margin-bottom: 0.5rem;
    }
    
    .summary-card .avatar {
        width: 3.5rem;
        height: 3.5rem;
        font-size: 1.25rem;
    }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
        .table th, .table td {
            font-size: 0.875rem;
            padding: 0.5rem;
        }
        
        .summary-card h5 {
            font-size: 1.25rem;
        }
        
        .summary-card .avatar {
            width: 3rem;
            height: 3rem;
            font-size: 1rem;
        }
        
        .summary-card .card-body {
            padding: 1rem 0.75rem;
        }
    }
    
    @media (max-width: 576px) {
        .table th, .table td {
            font-size: 0.75rem;
            padding: 0.4rem;
        }
        
        .summary-card h5 {
            font-size: 1.1rem;
        }
        
        .summary-card .avatar {
            width: 2.5rem;
            height: 2.5rem;
            font-size: 0.875rem;
        }
        
        .badge {
            font-size: 0.65em;
            padding: 0.2em 0.4em;
        }
    }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Add title attributes to truncated text for tooltip display
        const truncatedElements = document.querySelectorAll('.text-truncate');
        truncatedElements.forEach(element => {
            if (element.scrollWidth > element.clientWidth) {
                element.setAttribute('title', element.textContent);
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\All Project\1V2\saium-shilpigosthi\resources\views/admin/payments/index.blade.php ENDPATH**/ ?>