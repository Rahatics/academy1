

<?php $__env->startSection('title', 'আবেদন দেখুন - অ্যাডমিন প্যানেল'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex align-items-center justify-content-between mb-4 fade-in">
        <div>
            <h4 class="mb-0">আবেদন দেখুন</h4>
            <p class="text-muted mb-0">আবেদন আইডি: <?php echo e($application->application_id); ?></p>
        </div>
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">হোম</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.applications.index')); ?>">আবেদনসমূহ</a></li>
                    <li class="breadcrumb-item active" aria-current="page">আবেদন দেখুন</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="row g-4 fade-in">
        <!-- Left Column - Main Information -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex align-items-center">
                        <div class="avatar avatar-lg bg-primary bg-opacity-10 text-primary rounded me-3">
                            <i class='bx bx-user fs-4'></i>
                        </div>
                        <div>
                            <h5 class="mb-0"><?php echo e($application->name); ?></h5>
                            <p class="text-muted mb-0 small">আবেদন আইডি: <?php echo e($application->application_id); ?></p>
                            <?php if(!empty($application->data['student_name_bengali'])): ?>
                                <p class="text-muted mb-0 small"><?php echo e($application->data['student_name_bengali']); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row g-4">
                        <!-- Personal Information -->
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">ব্যক্তিগত তথ্য</h6>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <div class="row g-2">
                                        <div class="col-12">
                                            <p class="mb-1 small text-muted">নাম</p>
                                            <p class="mb-0"><?php echo e($application->name); ?></p>
                                        </div>
                                        <?php if(!empty($application->data['father_name_bengali'])): ?>
                                        <div class="col-12">
                                            <p class="mb-1 small text-muted">পিতার নাম</p>
                                            <p class="mb-0"><?php echo e($application->data['father_name_bengali']); ?></p>
                                        </div>
                                        <?php endif; ?>
                                        <?php if(!empty($application->data['mother_name_bengali'])): ?>
                                        <div class="col-12">
                                            <p class="mb-1 small text-muted">মাতার নাম</p>
                                            <p class="mb-0"><?php echo e($application->data['mother_name_bengali']); ?></p>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="row g-2">
                                        <?php if(!empty($application->data['date_of_birth'])): ?>
                                        <div class="col-12">
                                            <p class="mb-1 small text-muted">জন্ম তারিখ</p>
                                            <?php
                                                $dob = \Carbon\Carbon::parse($application->data['date_of_birth']);
                                                $age = $dob->diffInYears(now());
                                            ?>
                                            <p class="mb-0"><?php echo e($dob->format('d/m/Y')); ?> (<?php echo e($age); ?> বছর)</p>
                                        </div>
                                        <?php endif; ?>
                                        <?php if(!empty($application->data['gender'])): ?>
                                        <div class="col-12">
                                            <p class="mb-1 small text-muted">লিঙ্গ</p>
                                            <p class="mb-0">
                                                <span class="badge bg-primary bg-opacity-10 text-primary"><?php echo e($application->data['gender']); ?></span>
                                            </p>
                                        </div>
                                        <?php endif; ?>
                                        <?php if(!empty($application->data['blood_group'])): ?>
                                        <div class="col-12">
                                            <p class="mb-1 small text-muted">রক্তের গ্রুপ</p>
                                            <p class="mb-0">
                                                <span class="badge bg-success bg-opacity-10 text-success"><?php echo e($application->data['blood_group']); ?></span>
                                            </p>
                                        </div>
                                        <?php endif; ?>
                                        <?php if(!empty($application->data['religion'])): ?>
                                        <div class="col-12">
                                            <p class="mb-1 small text-muted">ধর্ম</p>
                                            <p class="mb-0"><?php echo e($application->data['religion']); ?></p>
                                        </div>
                                        <?php endif; ?>
                                        <?php if(!empty($application->data['nationality'])): ?>
                                        <div class="col-12">
                                            <p class="mb-1 small text-muted">জাতীয়তা</p>
                                            <p class="mb-0"><?php echo e($application->data['nationality']); ?></p>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Contact Information -->
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">যোগাযোগের তথ্য</h6>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <?php if(!empty($application->email) || !empty($application->data['email_address'])): ?>
                                    <div class="mb-3">
                                        <p class="mb-1 small text-muted">ইমেইল</p>
                                        <p class="mb-0">
                                            <?php if(!empty($application->data['email_address'])): ?>
                                                <?php echo e($application->data['email_address']); ?>

                                            <?php else: ?>
                                                <?php echo e($application->email); ?>

                                            <?php endif; ?>
                                        </p>
                                    </div>
                                    <?php endif; ?>
                                    <?php if(!empty($application->data['facebook_id'])): ?>
                                    <div class="mb-3">
                                        <p class="mb-1 small text-muted">ফেসবুক আইডি</p>
                                        <p class="mb-0"><?php echo e($application->data['facebook_id']); ?></p>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <?php if(!empty($application->phone) || !empty($application->data['student_mobile_number'])): ?>
                                    <div class="mb-3">
                                        <p class="mb-1 small text-muted">ফোন</p>
                                        <p class="mb-0">
                                            <?php if(!empty($application->data['student_mobile_number'])): ?>
                                                <?php echo e($application->data['student_mobile_number']); ?>

                                            <?php else: ?>
                                                <?php echo e($application->phone); ?>

                                            <?php endif; ?>
                                        </p>
                                    </div>
                                    <?php endif; ?>
                                    <?php if(!empty($application->data['guardian_mobile_number'])): ?>
                                    <div class="mb-3">
                                        <p class="mb-1 small text-muted">অভিভাবকের মোবাইল</p>
                                        <p class="mb-0"><?php echo e($application->data['guardian_mobile_number']); ?></p>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Additional Information Sections -->
                        <?php if($application->data && is_array($application->data)): ?>
                            <?php
                                $groupedData = group_admission_fields($application->data);
                            ?>
                            
                            <?php if(count($groupedData) > 0): ?>
                                <?php $__currentLoopData = $groupedData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupKey => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(count($group['fields']) > 0 && !in_array($groupKey, ['personal_info'])): ?>
                                        <div class="col-12">
                                            <h6 class="border-bottom pb-2 mb-3"><?php echo e($group['label']); ?></h6>
                                            <div class="row g-3">
                                                <?php $__currentLoopData = $group['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fieldKey => $fieldValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-md-6">
                                                        <p class="mb-1 small text-muted"><?php echo e(format_field_name($fieldKey)); ?></p>
                                                        <p class="mb-0"><?php echo format_field_value($fieldValue); ?></p>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Column - Status and Application Info -->
        <div class="col-lg-4">
            <!-- Application Status Card -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex align-items-center">
                        <div class="avatar avatar-lg bg-info bg-opacity-10 text-info rounded me-3">
                            <i class='bx bx-pulse fs-4'></i>
                        </div>
                        <h5 class="mb-0">আবেদনের স্ট্যাটাস</h5>
                    </div>
                </div>
                <div class="card-body">
                    <div class="text-center py-3">
                        <?php if($application->status == 'pending'): ?>
                            <div class="avatar avatar-xl bg-warning bg-opacity-10 text-warning rounded-circle mb-3 mx-auto">
                                <i class='bx bx-hourglass fs-1'></i>
                            </div>
                            <h5 class="mb-1">পেন্ডিং</h5>
                            <p class="text-muted small mb-0">আবেদনটি এখনও পর্যালোচনা করা হয়নি</p>
                        <?php elseif($application->status == 'reviewed'): ?>
                            <div class="avatar avatar-xl bg-info bg-opacity-10 text-info rounded-circle mb-3 mx-auto">
                                <i class='bx bx-check-circle fs-1'></i>
                            </div>
                            <h5 class="mb-1">পর্যালোচনা করা হয়েছে</h5>
                            <p class="text-muted small mb-0">আবেদনটি পর্যালোচনা করা হয়েছে</p>
                        <?php elseif($application->status == 'interview'): ?>
                            <div class="avatar avatar-xl bg-primary bg-opacity-10 text-primary rounded-circle mb-3 mx-auto">
                                <i class='bx bx-user-voice fs-1'></i>
                            </div>
                            <h5 class="mb-1">সাক্ষাৎকার</h5>
                            <p class="text-muted small mb-0">সাক্ষাৎকারের জন্য নির্ধারিত</p>
                        <?php elseif($application->status == 'accepted'): ?>
                            <div class="avatar avatar-xl bg-success bg-opacity-10 text-success rounded-circle mb-3 mx-auto">
                                <i class='bx bx-badge-check fs-1'></i>
                            </div>
                            <h5 class="mb-1">গৃহীত</h5>
                            <p class="text-muted small mb-0">আবেদনটি গৃহীত হয়েছে</p>
                        <?php elseif($application->status == 'rejected'): ?>
                            <div class="avatar avatar-xl bg-danger bg-opacity-10 text-danger rounded-circle mb-3 mx-auto">
                                <i class='bx bx-x-circle fs-1'></i>
                            </div>
                            <h5 class="mb-1">বাতিল</h5>
                            <p class="text-muted small mb-0">আবেদনটি বাতিল করা হয়েছে</p>
                        <?php else: ?>
                            <div class="avatar avatar-xl bg-secondary bg-opacity-10 text-secondary rounded-circle mb-3 mx-auto">
                                <i class='bx bx-help-circle fs-1'></i>
                            </div>
                            <h5 class="mb-1"><?php echo e(ucfirst($application->status)); ?></h5>
                            <p class="text-muted small mb-0">অজানা স্ট্যাটাস</p>
                        <?php endif; ?>
                        
                        <!-- Payment Status Indicator -->
                        <?php if($application->payment_status == 'paid'): ?>
                            <div class="mt-3">
                                <span class="badge bg-success bg-opacity-10 text-success">
                                    <i class='bx bx-credit-card me-1'></i>পেইড
                                </span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Application Details Card -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex align-items-center">
                        <div class="avatar avatar-lg bg-success bg-opacity-10 text-success rounded me-3">
                            <i class='bx bx-file fs-4'></i>
                        </div>
                        <h5 class="mb-0">আবেদন তথ্য</h5>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-12">
                            <p class="mb-1 small text-muted">আবেদন আইডি</p>
                            <p class="mb-0">
                                <span class="badge bg-secondary bg-opacity-10 text-secondary"><?php echo e($application->application_id); ?></span>
                            </p>
                        </div>
                        <?php if($application->form_title): ?>
                        <div class="col-12">
                            <p class="mb-1 small text-muted">ফরমের নাম</p>
                            <p class="mb-0">
                                <span class="badge bg-secondary bg-opacity-10 text-secondary"><?php echo e($application->form_title); ?></span>
                            </p>
                        </div>
                        <?php endif; ?>
                        <?php if(!empty($application->data['last_class_or_year']) || !empty($application->academic_class)): ?>
                        <div class="col-12">
                            <p class="mb-1 small text-muted">শ্রেণি/বিভাগ</p>
                            <p class="mb-0">
                                <?php if(!empty($application->data['last_class_or_year'])): ?>
                                    <span class="badge bg-info bg-opacity-10 text-info"><?php echo e($application->data['last_class_or_year']); ?></span>
                                <?php elseif(!empty($application->academic_class)): ?>
                                    <span class="badge bg-info bg-opacity-10 text-info"><?php echo e($application->academic_class); ?></span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <?php endif; ?>
                        <div class="col-12">
                            <p class="mb-1 small text-muted">আবেদনের তারিখ</p>
                            <p class="mb-0"><?php echo e($application->created_at->format('d/m/Y H:i:s')); ?></p>
                        </div>
                        <div class="col-12">
                            <p class="mb-1 small text-muted">আপডেটের তারিখ</p>
                            <p class="mb-0"><?php echo e($application->updated_at->format('d/m/Y H:i:s')); ?></p>
                        </div>
                        <?php if($application->reference): ?>
                        <div class="col-12">
                            <p class="mb-1 small text-muted">রেফারেন্স</p>
                            <p class="mb-0"><?php echo e($application->reference); ?></p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Fee Details Card -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex align-items-center">
                        <div class="avatar avatar-lg bg-warning bg-opacity-10 text-warning rounded me-3">
                            <i class='bx bx-credit-card fs-4'></i>
                        </div>
                        <h5 class="mb-0">ফি বিবরণ</h5>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-12">
                            <p class="mb-1 small text-muted">মোট ফি</p>
                            <p class="mb-0">
                                <?php if($application->total_fee): ?>
                                    <span class="fs-5 fw-bold text-success">৳<?php echo e(number_format($application->total_fee, 2)); ?></span>
                                <?php else: ?>
                                    <span class="text-muted">N/A</span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="col-12">
                            <p class="mb-1 small text-muted">পেমেন্ট স্ট্যাটাস</p>
                            <p class="mb-0">
                                <?php if($application->payment_status == 'paid'): ?>
                                    <span class="badge bg-success bg-opacity-10 text-success">পেইড</span>
                                <?php elseif($application->payment_status == 'pending'): ?>
                                    <span class="badge bg-warning bg-opacity-10 text-warning">পেন্ডিং</span>
                                <?php elseif($application->payment_status == 'unpaid'): ?>
                                    <span class="badge bg-danger bg-opacity-10 text-danger">আনপেইড</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary bg-opacity-10 text-secondary">N/A</span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <?php if($application->paid_at): ?>
                        <div class="col-12">
                            <p class="mb-1 small text-muted">পেমেন্টের তারিখ</p>
                            <p class="mb-0"><?php echo e($application->paid_at->format('d/m/Y H:i:s')); ?></p>
                        </div>
                        <?php endif; ?>
                        <?php if($application->payment_due_at): ?>
                        <div class="col-12">
                            <p class="mb-1 small text-muted">পেমেন্টের শেষ তারিখ</p>
                            <p class="mb-0"><?php echo e($application->payment_due_at->format('d/m/Y H:i:s')); ?></p>
                        </div>
                        <?php endif; ?>
                        <?php if($application->payment_gateway): ?>
                        <div class="col-12">
                            <p class="mb-1 small text-muted">পেমেন্ট গেটওয়ে</p>
                            <p class="mb-0">
                                <span class="badge bg-info bg-opacity-10 text-info"><?php echo e(ucfirst($application->payment_gateway)); ?></span>
                            </p>
                        </div>
                        <?php endif; ?>
                        <?php if($application->internal_invoice): ?>
                        <div class="col-12">
                            <p class="mb-1 small text-muted">ইন্টারনাল ইনভয়েস</p>
                            <p class="mb-0"><?php echo e($application->internal_invoice); ?></p>
                        </div>
                        <?php endif; ?>
                        <?php if($application->payment_attempt_token): ?>
                        <div class="col-12">
                            <p class="mb-1 small text-muted">ট্রানজেকশন আইডি</p>
                            <p class="mb-0">
                                <span class="badge bg-light text-muted"><?php echo e(substr($application->payment_attempt_token, 0, 10)); ?>...</span>
                            </p>
                        </div>
                        <?php endif; ?>
                        <?php if(!empty($application->phone) || !empty($application->data['student_mobile_number'])): ?>
                        <div class="col-12">
                            <p class="mb-1 small text-muted">ফোন নম্বর</p>
                            <p class="mb-0">
                                <?php if(!empty($application->data['student_mobile_number'])): ?>
                                    <?php echo e($application->data['student_mobile_number']); ?>

                                <?php else: ?>
                                    <?php echo e($application->phone); ?>

                                <?php endif; ?>
                            </p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Subject Selection Card -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex align-items-center">
                        <div class="avatar avatar-lg bg-info bg-opacity-10 text-info rounded me-3">
                            <i class='bx bx-book fs-4'></i>
                        </div>
                        <h5 class="mb-0">ভর্তিচ্ছু বিষয়</h5>
                    </div>
                </div>
                <div class="card-body">
                    <div>
                        <?php echo format_subjects_display($application->subject ?? '', $subjectNames); ?>

                    </div>
                </div>
            </div>

            <!-- Status Update Card -->
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex align-items-center">
                        <div class="avatar avatar-lg bg-danger bg-opacity-10 text-danger rounded me-3">
                            <i class='bx bx-cog fs-4'></i>
                        </div>
                        <h5 class="mb-0">স্ট্যাটাস আপডেট করুন</h5>
                    </div>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('admin.applications.update-status', $application)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-3">
                            <label class="form-label small">নতুন স্ট্যাটাস</label>
                            <select name="status" class="form-select" required>
                                <option value="">স্ট্যাটাস নির্বাচন করুন</option>
                                <?php $__currentLoopData = application_status_options(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>" <?php echo e($application->status == $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">
                            <i class='bx bx-save me-1'></i>আপডেট করুন
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Animations */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .fade-in {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    .fade-in:nth-child(1) { animation-delay: 0.1s; }
    .fade-in:nth-child(2) { animation-delay: 0.2s; }
    .fade-in:nth-child(3) { animation-delay: 0.3s; }
    
    /* Avatar styling */
    .avatar {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .avatar-lg {
        width: 3.5rem;
        height: 3.5rem;
    }
    
    .avatar-xl {
        width: 5rem;
        height: 5rem;
    }
    
    /* Card styling */
    .card {
        transition: all 0.3s ease;
        border-radius: 0.75rem;
    }
    
    .card:hover {
        transform: translateY(-3px);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1) !important;
    }
    
    /* Border bottom */
    .border-bottom {
        border-bottom: 1px solid #e9ecef !important;
    }
    
    /* Badge styling */
    .badge {
        font-size: 0.75em;
        padding: 0.5em 0.75em;
    }
    
    /* Breadcrumb styling */
    .breadcrumb {
        background-color: transparent;
        padding: 0;
        font-size: 0.875rem;
    }
    
    /* Dark mode specific styles */
    :root.dark-mode .card {
        background-color: #1e293b;
        border-color: #334155;
    }
    
    :root.dark-mode .border-bottom {
        border-bottom: 1px solid #334155 !important;
    }
    
    :root.dark-mode .form-control,
    :root.dark-mode .form-select {
        background-color: #1e293b;
        border-color: #334155;
        color: #f1f5f9;
    }
    
    :root.dark-mode .form-control:focus,
    :root.dark-mode .form-select:focus {
        background-color: #1e293b;
        border-color: #38bdf8;
        color: #f1f5f9;
        box-shadow: 0 0 0 0.25rem rgba(56, 189, 248, 0.25);
    }
    
    /* Responsive improvements */
    @media (max-width: 992px) {
        .col-lg-8, .col-lg-4 {
            flex: 0 0 100%;
            max-width: 100%;
        }
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/saimumba/shilpigosthi.com/resources/views/admin/applications/show.blade.php ENDPATH**/ ?>