

<?php $__env->startSection('title', 'ড্যাশবোর্ড - সাইমুম শিল্পীগোষ্ঠী'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex align-items-center mb-4 fade-in">
        <div>
            <h4 class="mb-1">ড্যাশবোর্ড</h4>
            <p class="mb-0 text-muted">সাইমুম শিল্পীগোষ্ঠী প্রশাসন প্যানেল</p>
        </div>
        <div class="ms-auto d-flex align-items-center">
            <div class="me-3">
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0">
                        <i class='bx bx-search'></i>
                    </span>
                    <input type="text" class="form-control border-start-0" placeholder="অনুসন্ধান করুন..." style="min-width: 200px;">
                </div>
            </div>
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">হোম</a></li>
                <li class="breadcrumb-item active" aria-current="page">ড্যাশবোর্ড</li>
            </ol>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="row">
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 fade-in">
            <div class="stats-card primary text-white">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-white text-primary rounded">
                            <i class='bx bx-file'></i>
                        </div>
                        <div class="stats-info ms-3">
                            <h5 class="text-white mb-1"><?php echo e($totalApplications); ?></h5>
                            <p class="mb-0">মোট আবেদন</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 fade-in">
            <div class="stats-card warning text-white">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-white text-warning rounded">
                            <i class='bx bx-time'></i>
                        </div>
                        <div class="stats-info ms-3">
                            <h5 class="text-white mb-1"><?php echo e($pendingApplications); ?></h5>
                            <p class="mb-0">অপেক্ষমান</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 fade-in">
            <div class="stats-card success text-white">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-white text-success rounded">
                            <i class='bx bx-check-circle'></i>
                        </div>
                        <div class="stats-info ms-3">
                            <h5 class="text-white mb-1"><?php echo e($approvedApplications); ?></h5>
                            <p class="mb-0">গৃহীত</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 fade-in">
            <div class="stats-card danger text-white">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-white text-danger rounded">
                            <i class='bx bx-x-circle'></i>
                        </div>
                        <div class="stats-info ms-3">
                            <h5 class="text-white mb-1"><?php echo e($rejectedApplications); ?></h5>
                            <p class="mb-0">প্রত্যাখ্যাত</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Form Stats Cards -->
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 fade-in">
            <div class="stats-card info text-white">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-white text-info rounded">
                            <i class='bx bx-spreadsheet'></i>
                        </div>
                        <div class="stats-info ms-3">
                            <h5 class="text-white mb-1"><?php echo e($totalForms); ?></h5>
                            <p class="mb-0">মোট ফর্ম</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 fade-in">
            <div class="stats-card primary text-white">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="stats-icon bg-white text-primary rounded">
                            <i class='bx bx-check-square'></i>
                        </div>
                        <div class="stats-info ms-3">
                            <h5 class="text-white mb-1"><?php echo e($activeForms); ?></h5>
                            <p class="mb-0">সক্রিয় ফর্ম</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts Row -->
    <div class="row">
        <!-- Application Trends Chart -->
        <div class="col-xl-8 col-lg-12 col-md-12 fade-in">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">আবেদন প্রবণতা</h5>
                    <div class="dropdown">
                        <button class="btn btn-sm btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                            গত 7 দিন
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#">গত 7 দিন</a></li>
                            <li><a class="dropdown-item" href="#">গত 30 দিন</a></li>
                            <li><a class="dropdown-item" href="#">গত 90 দিন</a></li>
                        </ul>
                    </div>
                </div>
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-center" style="height: 300px;">
                        <div class="text-center">
                            <i class='bx bx-bar-chart-alt-2 bx-lg text-muted mb-3'></i>
                            <h5 class="text-muted">চার্ট প্রদর্শন করার জন্য চার্ট.js লাইব্রেরি প্রয়োজন</h5>
                            <p class="text-muted mb-0">ড্যাশবোর্ডে চার্ট যুক্ত করতে চার্ট.js ইনস্টল করুন</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="col-xl-4 col-lg-12 col-md-12 fade-in">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">সাম্প্রতিক কার্যক্রম</h5>
                    <a href="#" class="btn btn-sm btn-outline-primary">সব দেখুন</a>
                </div>
                <div class="card-body">
                    <div class="activity-timeline">
                        <div class="timeline-item d-flex mb-4 fade-in">
                            <div class="timeline-icon bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px; min-width: 40px;">
                                <i class='bx bx-file'></i>
                            </div>
                            <div class="timeline-content ms-3">
                                <h6 class="mb-1">নতুন আবেদন জমা হয়েছে</h6>
                                <p class="mb-1 text-muted">জনাব আবদুল হামিদ একটি নতুন আবেদন জমা দিয়েছেন</p>
                                <small class="text-muted">2 মিনিট আগে</small>
                            </div>
                        </div>
                        <div class="timeline-item d-flex mb-4 fade-in">
                            <div class="timeline-icon bg-success text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px; min-width: 40px;">
                                <i class='bx bx-check-circle'></i>
                            </div>
                            <div class="timeline-content ms-3">
                                <h6 class="mb-1">আবেদন অনুমোদিত</h6>
                                <p class="mb-1 text-muted">জনাব মোস্তফিজুর রহমান-এর আবেদন অনুমোদিত হয়েছে</p>
                                <small class="text-muted">1 ঘন্টা আগে</small>
                            </div>
                        </div>
                        <div class="timeline-item d-flex mb-4 fade-in">
                            <div class="timeline-icon bg-warning text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px; min-width: 40px;">
                                <i class='bx bx-time'></i>
                            </div>
                            <div class="timeline-content ms-3">
                                <h6 class="mb-1">আবেদন পর্যালোচনাধীন</h6>
                                <p class="mb-1 text-muted">জনাব আলমগীর হোসেন-এর আবেদন পর্যালোচনাধীন</p>
                                <small class="text-muted">3 ঘন্টা আগে</small>
                            </div>
                        </div>
                        <div class="timeline-item d-flex fade-in">
                            <div class="timeline-icon bg-danger text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px; min-width: 40px;">
                                <i class='bx bx-x-circle'></i>
                            </div>
                            <div class="timeline-content ms-3">
                                <h6 class="mb-1">আবেদন প্রত্যাখ্যাত</h6>
                                <p class="mb-1 text-muted">জনাব মো. আকবর আলী-এর আবেদন প্রত্যাখ্যাত হয়েছে</p>
                                <small class="text-muted">5 ঘন্টা আগে</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Applications -->
    <div class="row">
        <div class="col-12 fade-in">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">সাম্প্রতিক আবেদনসমূহ</h5>
                    <a href="<?php echo e(route('admin.applications.index')); ?>" class="btn btn-primary btn-sm">সব আবেদন দেখুন</a>
                </div>
                <div class="card-body">
                    <?php if(isset($recentApplications) && $recentApplications->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>নাম</th>
                                        <th>ইমেইল</th>
                                        <th>ফোন</th>
                                        <th>অবস্থা</th>
                                        <th>তৈরির তারিখ</th>
                                        <th>কার্যক্রম</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $recentApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="fade-in">
                                            <td><?php echo e($application->name); ?></td>
                                            <td><?php echo e($application->email); ?></td>
                                            <td><?php echo e($application->phone); ?></td>
                                            <td>
                                                <?php if($application->status == 'pending'): ?>
                                                    <span class="badge bg-warning">অপেক্ষমান</span>
                                                <?php elseif($application->status == 'accepted'): ?>
                                                    <span class="badge bg-success">অনুমোদিত</span>
                                                <?php elseif($application->status == 'rejected'): ?>
                                                    <span class="badge bg-danger">প্রত্যাখ্যাত</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary"><?php echo e(ucfirst($application->status)); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($application->created_at->format('d M, Y')); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('admin.applications.show', $application)); ?>" class="btn btn-sm btn-primary">দেখুন</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5 fade-in">
                            <i class='bx bx-file bx-lg text-muted mb-3'></i>
                            <h5 class="text-muted">কোন আবেদন পাওয়া যায়নি</h5>
                            <p class="text-muted mb-0">এখনও কোন আবেদন জমা হয়নি।</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    /* Add specific animations for dashboard elements */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .fade-in {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    .stats-card {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    .stats-card:nth-child(1) { animation-delay: 0.1s; }
    .stats-card:nth-child(2) { animation-delay: 0.2s; }
    .stats-card:nth-child(3) { animation-delay: 0.3s; }
    .stats-card:nth-child(4) { animation-delay: 0.4s; }
    .stats-card:nth-child(5) { animation-delay: 0.5s; }
    .stats-card:nth-child(6) { animation-delay: 0.6s; }
    
    .fade-in:nth-child(1) { animation-delay: 0.1s; }
    .fade-in:nth-child(2) { animation-delay: 0.2s; }
    .fade-in:nth-child(3) { animation-delay: 0.3s; }
    .fade-in:nth-child(4) { animation-delay: 0.4s; }
    
    /* Ensure dashboard table rows have proper fade-in */
    .table tbody tr.fade-in {
        animation: fadeInUp 0.6s ease forwards;
    }
    
    .table tbody tr.fade-in:nth-child(1) { animation-delay: 0.1s; }
    .table tbody tr.fade-in:nth-child(2) { animation-delay: 0.2s; }
    .table tbody tr.fade-in:nth-child(3) { animation-delay: 0.3s; }
    .table tbody tr.fade-in:nth-child(4) { animation-delay: 0.4s; }
    .table tbody tr.fade-in:nth-child(5) { animation-delay: 0.5s; }
    
    /* Timeline Styles */
    .activity-timeline .timeline-item {
        position: relative;
    }
    
    .activity-timeline .timeline-item:not(:last-child)::after {
        content: '';
        position: absolute;
        top: 40px;
        left: 20px;
        height: calc(100% - 20px);
        width: 2px;
        background-color: var(--border-color);
    }
    
    /* Chart placeholder styles */
    .chart-placeholder {
        background: linear-gradient(135deg, rgba(74, 144, 226, 0.05), rgba(74, 144, 226, 0.1));
        border-radius: 12px;
        height: 300px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    /* Responsive improvements for dashboard */
    @media (max-width: 1400px) {
        .stats-card .stats-info h5 {
            font-size: 1.75rem;
        }
    }
    
    @media (max-width: 1200px) {
        .stats-card .stats-info h5 {
            font-size: 1.5rem;
        }
    }
    
    @media (max-width: 992px) {
        .stats-card .stats-info h5 {
            font-size: 1.75rem;
        }
        
        /* Stack charts and activity on mobile */
        .row .col-xl-8, .row .col-xl-4 {
            flex: 0 0 100%;
            max-width: 100%;
        }
    }
    
    @media (max-width: 768px) {
        .stats-card .stats-info h5 {
            font-size: 1.5rem;
        }
        
        .page-header {
            flex-direction: column;
            align-items: flex-start !important;
        }
        
        .page-header .ms-auto {
            margin-left: 0 !important;
            margin-top: 1rem;
        }
        
        .page-header .me-3 {
            margin-right: 1rem !important;
        }
    }
    
    @media (max-width: 576px) {
        .stats-card .stats-info h5 {
            font-size: 1.25rem;
        }
        
        .stats-card .stats-icon {
            width: 50px;
            height: 50px;
            font-size: 1.25rem;
        }
        
        .activity-timeline .timeline-item:not(:last-child)::after {
            top: 35px;
            left: 15px;
        }
        
        .page-header .me-3 {
            display: none;
        }
    }
    
    /* Dropdown menu improvements */
    .dropdown-menu.dropdown-menu-lg {
        min-width: 350px;
        max-width: 350px;
    }
    
    @media (max-width: 576px) {
        .dropdown-menu.dropdown-menu-lg {
            min-width: 300px;
            max-width: 300px;
            right: 0 !important;
            left: auto !important;
        }
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\All Project\1V2\saium-shilpigosthi\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>