<?php $__env->startSection('title', 'আবেদনের স্ট্যাটাস - সাইমুম শিল্পীগোষ্ঠী'); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <h1 class="section-title">আবেদনের স্ট্যাটাস</h1>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h3 class="mb-0">আবেদন স্ট্যাটাস চেক করুন</h3>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('application-status.check')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="application_id" class="form-label">আবেদন আইডি অথবা ইমেইল</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['application_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="application_id" name="application_id" placeholder="আপনার আবেদন আইডি অথবা ইমেইল দিন" value="<?php echo e(old('application_id')); ?>">
                            <?php $__errorArgs = ['application_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" class="btn btn-info">স্ট্যাটাস চেক করুন</button>
                    </form>
                </div>
            </div>

            <?php if(isset($application)): ?>
            <div class="card mt-4">
                <div class="card-header">
                    <h4>আবেদন স্ট্যাটাস</h4>
                </div>
                <div class="card-body">
                    <?php if($application->status == 'pending'): ?>
                        <div class="alert alert-warning" role="alert">
                            <h4 class="alert-heading">আবেদন পর্যালোচনাধীন!</h4>
                            <p>আপনার আবেদন এখনও পর্যালোচনাধীন রয়েছে। আমাদের টিম শীঘ্রই আপনার সাথে যোগাযোগ করবে।</p>
                            <hr>
                            <p class="mb-0">আবেদন আইডি: <?php echo e($application->application_id); ?></p>
                        </div>
                    <?php elseif($application->status == 'reviewed'): ?>
                        <div class="alert alert-info" role="alert">
                            <h4 class="alert-heading">আবেদন পর্যালোচনা করা হয়েছে!</h4>
                            <p>আপনার আবেদন পর্যালোচনা করা হয়েছে। শীঘ্রই সাক্ষাৎকারের জন্য আপনার সাথে যোগাযোগ করা হবে।</p>
                            <hr>
                            <p class="mb-0">আবেদন আইডি: <?php echo e($application->application_id); ?></p>
                        </div>
                    <?php elseif($application->status == 'interview'): ?>
                        <div class="alert alert-primary" role="alert">
                            <h4 class="alert-heading">সাক্ষাৎকারের জন্য নির্বাচিত!</h4>
                            <p>অভিনন্দন! আপনি সাক্ষাৎকারের জন্য নির্বাচিত হয়েছেন। আমাদের টিম শীঘ্রই আপনার সাথে যোগাযোগ করবে।</p>
                            <hr>
                            <p class="mb-0">আবেদন আইডি: <?php echo e($application->application_id); ?></p>
                        </div>
                    <?php elseif($application->status == 'accepted'): ?>
                        <div class="alert alert-success" role="alert">
                            <h4 class="alert-heading">আবেদন গৃহীত!</h4>
                            <p>অভিনন্দন! আপনার আবেদন গৃহীত হয়েছে। আমাদের টিম শীঘ্রই আপনার সাথে যোগাযোগ করবে।</p>
                            <hr>
                            <p class="mb-0">আবেদন আইডি: <?php echo e($application->application_id); ?></p>
                        </div>
                    <?php elseif($application->status == 'rejected'): ?>
                        <div class="alert alert-danger" role="alert">
                            <h4 class="alert-heading">আবেদন বাতিল!</h4>
                            <p>দুঃখিত, আপনার আবেদন বাতিল করা হয়েছে। আপনি পরবর্তীতে আবার আবেদন করতে পারবেন।</p>
                            <hr>
                            <p class="mb-0">আবেদন আইডি: <?php echo e($application->application_id); ?></p>
                        </div>
                    <?php endif; ?>

                    <?php if(config('payment.enabled')): ?>
                        <hr>
                        <h5 class="mt-3">পেমেন্ট স্ট্যাটাস</h5>
                        <?php if($application->payment_status === 'paid'): ?>
                            <div class="alert alert-success py-2 mb-2">
                                ফি পরিশোধ হয়েছে।
                                <?php if($application->public_application_code): ?>
                                    <div class="small mt-1">পাবলিক কোড: <strong><?php echo e($application->public_application_code); ?></strong></div>
                                <?php endif; ?>
                                <?php if($application->internal_invoice): ?>
                                    <div class="small">ইনভয়েস: <?php echo e($application->internal_invoice); ?></div>
                                <?php endif; ?>
                            </div>
                            <a href="<?php echo e(route('forms.payment.success', $application)); ?>" class="btn btn-outline-success btn-sm">পেমেন্ট রসিদ দেখুন</a>
                        <?php elseif(in_array($application->payment_status, ['pending_unpaid','pending'])): ?>
                            <?php if($application->payment_due_at && $application->payment_due_at->isPast()): ?>
                                <div class="alert alert-danger py-2">পেমেন্টের সময়সীমা অতিক্রান্ত হয়েছে। নতুন করে আবেদন করতে হবে।</div>
                            <?php else: ?>
                                <div class="alert alert-info py-2">আপনি এখনো ফি পরিশোধ করেননি। অনুগ্রহ করে সময়সীমার মধ্যে পরিশোধ করুন।</div>
                                <a href="<?php echo e(route('forms.payment.decision', $application)); ?>" class="btn btn-primary">পেমেন্ট করুন</a>
                            <?php endif; ?>
                        <?php elseif($application->payment_status === 'expired_unpaid'): ?>
                            <div class="alert alert-danger py-2">পেমেন্টের সময়সীমা অতিক্রান্ত (Expired)।</div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
            <?php else: ?>
            <div class="card mt-4">
                <div class="card-header">
                    <h4>আবেদন স্ট্যাটাস</h4>
                </div>
                <div class="card-body">
                    <div class="alert alert-info" role="alert">
                        আবেদন স্ট্যাটাস দেখতে উপরের ফর্মটি পূরণ করুন।
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="row mt-5">
        <div class="col-12">
            <h3 class="section-title">আবেদন প্রক্রিয়া</h3>
            <div class="row">
                <div class="col-md-3 mb-3">
                    <div class="card text-center h-100">
                        <div class="card-body">
                            <div class="rounded-circle bg-primary text-white mx-auto mb-3" style="width: 50px; height: 50px; display: flex; align-items: center; justify-content: center;">
                                1
                            </div>
                            <h5>আবেদন</h5>
                            <p class="card-text">অনলাইনে আবেদন ফর্ম পূরণ করুন</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card text-center h-100">
                        <div class="card-body">
                            <div class="rounded-circle bg-secondary text-white mx-auto mb-3" style="width: 50px; height: 50px; display: flex; align-items: center; justify-content: center;">
                                2
                            </div>
                            <h5>প্রাথমিক পর্যালোচনা</h5>
                            <p class="card-text">আমাদের টিম আপনার আবেদন পর্যালোচনা করবে</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card text-center h-100">
                        <div class="card-body">
                            <div class="rounded-circle bg-secondary text-white mx-auto mb-3" style="width: 50px; height: 50px; display: flex; align-items: center; justify-content: center;">
                                3
                            </div>
                            <h5>সাক্ষাৎকার</h5>
                            <p class="card-text">প্রয়োজনে সাক্ষাৎকার নেওয়া হবে</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card text-center h-100">
                        <div class="card-body">
                            <div class="rounded-circle bg-secondary text-white mx-auto mb-3" style="width: 50px; height: 50px; display: flex; align-items: center; justify-content: center;">
                                4
                            </div>
                            <h5>চূড়ান্ত সিদ্ধান্ত</h5>
                            <p class="card-text">আপনার আবেদনের চূড়ান্ত সিদ্ধান্ত জানানো হবে</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\All Project\1V2\saium-shilpigosthi\resources\views/application-status.blade.php ENDPATH**/ ?>