<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Application>
 */
class ApplicationFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            'name' => $this->faker->name(),
            'email' => $this->faker->unique()->safeEmail(),
            'phone' => $this->faker->phoneNumber(),
            'address' => $this->faker->address(),
            'date_of_birth' => $this->faker->date(),
            'occupation' => $this->faker->jobTitle(),
            'skills' => $this->faker->sentence(),
            'experience' => $this->faker->paragraph(),
            'motivation' => $this->faker->paragraph(),
            'reference' => $this->faker->name(),
            'application_id' => 'APP-' . date('Y') . '-' . strtoupper(Str::random(6)),
            'status' => $this->faker->randomElement(['pending', 'reviewed', 'interview', 'accepted', 'rejected']),
        ];
    }
}