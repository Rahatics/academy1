<?php

namespace Database\Factories;

use App\Models\Payment;
use App\Models\Application;
use Illuminate\Database\Eloquent\Factories\Factory;

class PaymentFactory extends Factory
{
    protected $model = Payment::class;

    public function definition(): array
    {
        return [
            'application_id' => Application::factory(),
            'gateway' => $this->faker->randomElement(['dummy','bkash']),
            'status' => $this->faker->randomElement(['initiated','executed','success','failed']),
            'amount' => $this->faker->numberBetween(100, 2000),
            'currency' => 'BDT',
            'meta' => ['factory' => true]
        ];
    }
}
