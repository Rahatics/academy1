<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Application;
use Illuminate\Support\Str;

class ApplicationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Create sample applications
        Application::create([
            'name' => 'মোহাম্মদ আলী',
            'email' => 'ali@example.com',
            'phone' => '01712345678',
            'address' => 'ঢাকা, বাংলাদেশ',
            'date_of_birth' => '1995-05-15',
            'occupation' => 'ছাত্র',
            'skills' => 'গান, নাটক',
            'experience' => 'বিগত ২ বছর ধরে বিভিন্ন সাংস্কৃতিক কার্যক্রমে অংশ নিয়েছি',
            'motivation' => 'ইসলামী সংস্কৃতি ছড়িয়ে দিতে চাই',
            'reference' => 'আব্দুল কাদের',
            'application_id' => 'APP-' . date('Y') . '-SAMPLE1',
            'status' => 'accepted'
        ]);
        
        Application::create([
            'name' => 'ফাতেমা আক্তার',
            'email' => 'fatema@example.com',
            'phone' => '01812345678',
            'address' => 'চট্টগ্রাম, বাংলাদেশ',
            'date_of_birth' => '1998-08-22',
            'occupation' => 'প্রকৌশলী',
            'skills' => 'আলোচনা, গান',
            'experience' => 'বিভিন্ন মাহফিলে আলোচনা করেছি',
            'motivation' => 'সমাজে ইতিবাচক প্রভাব ফেলতে চাই',
            'reference' => null,
            'application_id' => 'APP-' . date('Y') . '-SAMPLE2',
            'status' => 'pending'
        ]);
    }
}