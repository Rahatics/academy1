<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UpdateFormsWithPaymentAmountSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Get all forms that have paymentRequired set to true but no paymentAmount
        $forms = DB::table('forms')
            ->whereJsonContains('fields->settings->paymentRequired', true)
            ->get();

        foreach ($forms as $form) {
            $fields = json_decode($form->fields, true);
            
            // If paymentAmount is not set, add a default value
            if (!isset($fields['settings']['paymentAmount'])) {
                $fields['settings']['paymentAmount'] = 500; // Default payment amount of 500 BDT
                
                // Update the form with the new fields data
                DB::table('forms')
                    ->where('id', $form->id)
                    ->update(['fields' => json_encode($fields)]);
            }
        }
    }
}