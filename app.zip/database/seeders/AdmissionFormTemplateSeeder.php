<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Form;
use App\Models\Admin;

class AdmissionFormTemplateSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Get the first admin user or create one if none exists
        $admin = Admin::first();
        if (!$admin) {
            $admin = Admin::create([
                'name' => 'System Admin',
                'email' => 'admin@example.com',
                'password' => bcrypt('password'),
            ]);
        }

        // Create admission form template
        $admissionForm = Form::create([
            'name' => 'ভর্তি ফর্ম',
            'description' => 'শিল্পীগোষ্ঠীতে ভর্তির জন্য আবেদন ফর্ম',
            'status' => 'active',
            'created_by' => $admin->id,
            'template' => 'admission_form',
            'fields' => [
                [
                    'id' => 'element_' . time() . '_1',
                    'type' => 'file',
                    'label' => 'ছবি সংযুক্ত করার বক্স',
                    'fieldName' => 'student_photo',
                    'required' => true,
                    'options' => []
                ],
                // Personal Information Section
                [
                    'id' => 'element_' . time() . '_2',
                    'type' => 'section',
                    'label' => 'ব্যক্তিগত তথ্য',
                    'fieldName' => 'personal_information',
                    'required' => false,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_3',
                    'type' => 'text',
                    'label' => 'শিক্ষার্থীর নাম (বাংলায়)',
                    'fieldName' => 'student_name_bengali',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_4',
                    'type' => 'text',
                    'label' => 'শিক্ষার্থীর নাম (ইংরেজিতে, বড় হাতের অক্ষরে)',
                    'fieldName' => 'student_name_english',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_5',
                    'type' => 'text',
                    'label' => 'পিতার নাম (বাংলায়)',
                    'fieldName' => 'father_name_bengali',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_6',
                    'type' => 'text',
                    'label' => 'পিতার নাম (ইংরেজিতে, বড় হাতের অক্ষরে)',
                    'fieldName' => 'father_name_english',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_7',
                    'type' => 'text',
                    'label' => 'পিতার পেশা',
                    'fieldName' => 'father_occupation',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_8',
                    'type' => 'text',
                    'label' => 'পিতার মোবাইল নম্বর',
                    'fieldName' => 'father_mobile_number',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_9',
                    'type' => 'text',
                    'label' => 'মাতার নাম (বাংলায়)',
                    'fieldName' => 'mother_name_bengali',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_10',
                    'type' => 'text',
                    'label' => 'মাতার নাম (ইংরেজিতে, বড় হাতের অক্ষরে)',
                    'fieldName' => 'mother_name_english',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_11',
                    'type' => 'text',
                    'label' => 'মাতার পেশা',
                    'fieldName' => 'mother_occupation',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_12',
                    'type' => 'text',
                    'label' => 'মাতার মোবাইল নম্বর',
                    'fieldName' => 'mother_mobile_number',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_13',
                    'type' => 'text',
                    'label' => 'জাতীয় পরিচয়পত্র / জন্ম নিবন্ধন নম্বর',
                    'fieldName' => 'nid_or_birth_certificate_no',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_14',
                    'type' => 'date',
                    'label' => 'জন্ম তারিখ (দিন/মাস/বছর)',
                    'fieldName' => 'date_of_birth',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_15',
                    'type' => 'select',
                    'label' => 'ধর্ম',
                    'fieldName' => 'religion',
                    'required' => true,
                    'options' => ['ইসলাম', 'হিন্দু', 'খ্রিস্টান', 'বৌদ্ধ', 'অন্যান্য']
                ],
                [
                    'id' => 'element_' . time() . '_16',
                    'type' => 'select',
                    'label' => 'লিঙ্গ',
                    'fieldName' => 'gender',
                    'required' => true,
                    'options' => ['পুরুষ', 'মহিলা', 'অন্যান্য']
                ],
                [
                    'id' => 'element_' . time() . '_17',
                    'type' => 'text',
                    'label' => 'জাতীয়তা',
                    'fieldName' => 'nationality',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_18',
                    'type' => 'select',
                    'label' => 'রক্তের গ্রুপ',
                    'fieldName' => 'blood_group',
                    'required' => true,
                    'options' => ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
                ],
                // Address Section
                [
                    'id' => 'element_' . time() . '_19',
                    'type' => 'section',
                    'label' => 'ঠিকানা',
                    'fieldName' => 'address',
                    'required' => false,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_20',
                    'type' => 'section',
                    'label' => 'বর্তমান ঠিকানা (Present Address)',
                    'fieldName' => 'present_address',
                    'required' => false,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_21',
                    'type' => 'text',
                    'label' => 'গ্রাম/মহল্লা',
                    'fieldName' => 'present_address_village',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_22',
                    'type' => 'text',
                    'label' => 'বাসা/হোল্ডিং নং',
                    'fieldName' => 'present_address_holding_no',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_23',
                    'type' => 'text',
                    'label' => 'সড়ক নং',
                    'fieldName' => 'present_address_road_no',
                    'required' => false,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_24',
                    'type' => 'text',
                    'label' => 'ডাকঘর',
                    'fieldName' => 'present_address_post_office',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_25',
                    'type' => 'text',
                    'label' => 'উপজেলা/থানা',
                    'fieldName' => 'present_address_upazila',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_26',
                    'type' => 'text',
                    'label' => 'জেলা',
                    'fieldName' => 'present_address_district',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_27',
                    'type' => 'checkbox',
                    'label' => 'বর্তমান ও স্থায়ী ঠিকানা একই হলে টিক দিন',
                    'fieldName' => 'is_permanent_address_same_as_present',
                    'required' => false,
                    'options' => ['ঠিকানা একই']
                ],
                [
                    'id' => 'element_' . time() . '_28',
                    'type' => 'section',
                    'label' => 'স্থায়ী ঠিকানা (Permanent Address)',
                    'fieldName' => 'permanent_address',
                    'required' => false,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_29',
                    'type' => 'text',
                    'label' => 'গ্রাম/মহল্লা',
                    'fieldName' => 'permanent_address_village',
                    'required' => false,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_30',
                    'type' => 'text',
                    'label' => 'বাসা/হোল্ডিং নং',
                    'fieldName' => 'permanent_address_holding_no',
                    'required' => false,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_31',
                    'type' => 'text',
                    'label' => 'সড়ক নং',
                    'fieldName' => 'permanent_address_road_no',
                    'required' => false,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_32',
                    'type' => 'text',
                    'label' => 'ডাকঘর',
                    'fieldName' => 'permanent_address_post_office',
                    'required' => false,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_33',
                    'type' => 'text',
                    'label' => 'উপজেলা/থানা',
                    'fieldName' => 'permanent_address_upazila',
                    'required' => false,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_34',
                    'type' => 'text',
                    'label' => 'জেলা',
                    'fieldName' => 'permanent_address_district',
                    'required' => false,
                    'options' => []
                ],
                // Workshop & Admission Information
                [
                    'id' => 'element_' . time() . '_35',
                    'type' => 'section',
                    'label' => 'কর্মশালা ও ভর্তি সংক্রান্ত তথ্য',
                    'fieldName' => 'workshop_admission_info',
                    'required' => false,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_36',
                    'type' => 'date',
                    'label' => 'কর্মশালায় উত্তীর্ণের তারিখ',
                    'fieldName' => 'workshop_passing_date',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_37',
                    'type' => 'text',
                    'label' => 'কর্মশালায় উত্তীর্ণের বিষয়',
                    'fieldName' => 'workshop_passing_subject',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_38',
                    'type' => 'text',
                    'label' => 'কর্মশালার রেজিস্ট্রেশন নম্বর',
                    'fieldName' => 'workshop_registration_no',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_39',
                    'type' => 'text',
                    'label' => 'ভর্তিচ্ছু বিষয়',
                    'fieldName' => 'desired_subject',
                    'required' => true,
                    'options' => []
                ],
                // Last Educational Qualification
                [
                    'id' => 'element_' . time() . '_40',
                    'type' => 'section',
                    'label' => 'সর্বশেষ শিক্ষাগত যোগ্যতা',
                    'fieldName' => 'last_educational_qualification',
                    'required' => false,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_41',
                    'type' => 'text',
                    'label' => 'শিক্ষা প্রতিষ্ঠানের নাম',
                    'fieldName' => 'last_educational_institute',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_42',
                    'type' => 'text',
                    'label' => 'শ্রেণি/বর্ষ',
                    'fieldName' => 'last_class_or_year',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_43',
                    'type' => 'text',
                    'label' => 'বোর্ড রোল / আইডি নং',
                    'fieldName' => 'last_board_roll_or_id',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_44',
                    'type' => 'text',
                    'label' => 'বিভাগ/বিষয়',
                    'fieldName' => 'last_department_or_subject',
                    'required' => true,
                    'options' => []
                ],
                // Contact Information
                [
                    'id' => 'element_' . time() . '_45',
                    'type' => 'section',
                    'label' => 'যোগাযোগের তথ্য',
                    'fieldName' => 'contact_information',
                    'required' => false,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_46',
                    'type' => 'text',
                    'label' => 'মোবাইল নম্বর (শিক্ষার্থীর)',
                    'fieldName' => 'student_mobile_number',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_47',
                    'type' => 'text',
                    'label' => 'মোবাইল নম্বর (অভিভাবকের)',
                    'fieldName' => 'guardian_mobile_number',
                    'required' => true,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_48',
                    'type' => 'text',
                    'label' => 'ই-মেইল ঠিকানা',
                    'fieldName' => 'email_address',
                    'required' => false,
                    'options' => []
                ],
                [
                    'id' => 'element_' . time() . '_49',
                    'type' => 'text',
                    'label' => 'ফেসবুক আইডি (যদি থাকে)',
                    'fieldName' => 'facebook_id',
                    'required' => false,
                    'options' => []
                ]
            ]
        ]);
    }
}
