<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Subject;

class SubjectSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $subjects = [
            [
                'name' => 'কিরাত',
                'code' => 'QIR101',
                'description' => 'শুদ্ধ তিলাওয়াত ও কিরাত প্রশিক্ষণ',
                'fee' => 500.00,
                'is_active' => true,
            ],
            [
                'name' => 'গান',
                'code' => 'MUS101',
                'description' => 'গান শিক্ষা এবং প্রশিক্ষণ',
                'fee' => 600.00,
                'is_active' => true,
            ],
            [
                'name' => 'অভিনয়',
                'code' => 'ACT101',
                'description' => 'অভিনয়ের মৌলিক ও অগ্রসর অনুশীলন',
                'fee' => 700.00,
                'is_active' => true,
            ],
            [
                'name' => 'আবৃত্তি ও উপস্থাপনা',
                'code' => 'PRC101',
                'description' => 'আবৃত্তি ও মঞ্চ/ইভেন্ট উপস্থাপনা দক্ষতা উন্নয়ন',
                'fee' => 550.00,
                'is_active' => true,
            ],
        ];

        foreach ($subjects as $subject) {
            Subject::firstOrCreate(
                ['code' => $subject['code']],
                $subject
            );
        }
    }
}