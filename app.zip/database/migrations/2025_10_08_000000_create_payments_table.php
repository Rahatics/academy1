<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->string('gateway')->default('bkash');
            $table->string('intent')->nullable(); // sale, authorization
            $table->string('invoice_number')->nullable();
            $table->string('payer_reference')->nullable();
            $table->string('transaction_id')->nullable()->index();
            $table->string('payment_id')->nullable()->index();
            $table->string('merchant_invoice_number')->nullable()->index();
            $table->string('status')->default('initiated'); // initiated, created, executed, failed, refunded
            $table->decimal('amount', 15, 2)->nullable();
            $table->string('currency')->default('BDT');
            $table->json('meta')->nullable();
            $table->timestamp('executed_at')->nullable();
            $table->timestamps();
            $table->index(['gateway','status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payments');
    }
};
