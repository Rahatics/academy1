<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('payment_gateway_settings', function (Blueprint $table) {
            $table->id();
            $table->string('gateway')->index(); // e.g. bkash
            $table->boolean('active')->default(false);
            $table->string('mode')->default('sandbox');
            $table->string('app_key')->nullable();
            $table->text('app_secret')->nullable(); // sensitive
            $table->string('username')->nullable();
            $table->string('password')->nullable();
            $table->string('callback_url')->nullable();
            $table->json('extra')->nullable(); // extensibility for other gateways
            $table->timestamps();
            $table->unique(['gateway']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payment_gateway_settings');
    }
};
