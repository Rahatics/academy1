<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('applications', function (Blueprint $table) {
            $table->string('subject')->nullable()->after('reference');
            $table->string('academic_class')->nullable()->after('subject');
            $table->string('gender')->nullable()->after('academic_class');
            $table->string('form_title')->nullable()->after('status');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('applications', function (Blueprint $table) {
            $table->dropColumn(['subject', 'academic_class', 'gender', 'form_title']);
        });
    }
};