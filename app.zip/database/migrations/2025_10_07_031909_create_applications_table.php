<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('applications', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email');
            $table->string('phone');
            $table->text('address');
            $table->date('date_of_birth');
            $table->string('occupation');
            $table->text('skills')->nullable();
            $table->text('experience')->nullable();
            $table->text('motivation');
            $table->string('reference')->nullable();
            $table->string('application_id')->unique();
            $table->string('status')->default('pending'); // pending, reviewed, interview, accepted, rejected
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('applications');
    }
};