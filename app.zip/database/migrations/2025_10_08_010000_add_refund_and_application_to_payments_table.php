<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('payments', function (Blueprint $table) {
            $table->unsignedBigInteger('application_id')->nullable()->after('id');
            $table->string('refund_transaction_id')->nullable()->after('transaction_id');
            $table->decimal('refunded_amount', 15, 2)->nullable()->after('amount');
            $table->timestamp('refunded_at')->nullable()->after('executed_at');
            $table->string('refund_status')->nullable()->after('status');
            $table->json('refund_meta')->nullable()->after('meta');
            $table->index('application_id');
        });
    }

    public function down(): void
    {
        Schema::table('payments', function (Blueprint $table) {
            $table->dropColumn([
                'application_id',
                'refund_transaction_id',
                'refunded_amount',
                'refunded_at',
                'refund_status',
                'refund_meta',
            ]);
        });
    }
};
