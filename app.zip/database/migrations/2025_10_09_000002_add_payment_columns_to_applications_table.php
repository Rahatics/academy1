<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('applications', function (Blueprint $table) {
            if(!Schema::hasColumn('applications','total_fee')) {
                $table->decimal('total_fee', 10, 2)->default(0)->after('subject');
            }
            if(!Schema::hasColumn('applications','payment_status')) {
                $table->string('payment_status')->default('pending_unpaid')->after('total_fee');
            }
            if(!Schema::hasColumn('applications','payment_due_at')) {
                $table->timestamp('payment_due_at')->nullable()->after('payment_status');
            }
            if(!Schema::hasColumn('applications','paid_at')) {
                $table->timestamp('paid_at')->nullable()->after('payment_due_at');
            }
            if(!Schema::hasColumn('applications','internal_invoice')) {
                $table->string('internal_invoice')->nullable()->unique()->after('paid_at');
            }
        });
    }

    public function down(): void
    {
        Schema::table('applications', function (Blueprint $table) {
            foreach(['internal_invoice','paid_at','payment_due_at','payment_status','total_fee'] as $col) {
                if(Schema::hasColumn('applications',$col)) {
                    $table->dropColumn($col);
                }
            }
        });
    }
};
