<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // No schema changes needed since fields is JSON column
        // We'll update existing forms to include paymentAmount in settings if paymentRequired is true but paymentAmount is missing
        DB::table('forms')->whereJsonContains('fields->settings->paymentRequired', true)
            ->whereRaw("JSON_EXTRACT(fields, '$.settings.paymentAmount') IS NULL")
            ->update([
                'fields' => DB::raw("JSON_SET(fields, '$.settings.paymentAmount', 500)")
            ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // We can't easily reverse this migration, but it's not critical
    }
};