<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('payment_gateway_settings', function (Blueprint $table) {
            // Add fields specific to Easypay
            $table->string('merchant_id')->nullable()->after('gateway');
        });
    }

    public function down(): void
    {
        Schema::table('payment_gateway_settings', function (Blueprint $table) {
            $table->dropColumn('merchant_id');
        });
    }
};