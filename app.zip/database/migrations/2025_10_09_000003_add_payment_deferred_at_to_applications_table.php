<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('applications', function (Blueprint $table) {
            if (!Schema::hasColumn('applications', 'payment_deferred_at')) {
                $table->timestamp('payment_deferred_at')->nullable()->after('payment_due_at');
            }
            if (!Schema::hasColumn('applications', 'payment_gateway')) {
                $table->string('payment_gateway')->nullable()->after('payment_deferred_at');
            }
        });
    }

    public function down(): void
    {
        Schema::table('applications', function (Blueprint $table) {
            if (Schema::hasColumn('applications', 'payment_gateway')) {
                $table->dropColumn('payment_gateway');
            }
            if (Schema::hasColumn('applications', 'payment_deferred_at')) {
                $table->dropColumn('payment_deferred_at');
            }
        });
    }
};
