<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Saimum Shilpigosthi Configuration
    |--------------------------------------------------------------------------
    |
    | This file contains configuration options for the Saimum Shilpigosthi website.
    |
    */
    
    'organization' => [
        'name' => 'সাইমুম শিল্পীগোষ্ঠী',
        'founded' => 1978,
        'mission' => 'ইসলামী সংস্কৃতি ছড়িয়ে দিচ্ছি বাংলাদেশ জুড়ে',
        'address' => 'ঢাকা, বাংলাদেশ',
        'email' => 'info@saimum.org',
        'phone' => '+880-XXXXXXXXXX',
    ],
    
    'application' => [
        'status_options' => [
            'reviewed' => 'পর্যালোচনা করা হয়েছে',
            'accepted' => 'গৃহীত',
            'rejected' => 'বাতিল',
        ],
    ],
    
    'social_media' => [
        'facebook' => 'https://www.facebook.com/saimumshilpigosthi',
        'instagram' => 'https://www.instagram.com/saimumshilpigosthi/',
        'twitter' => 'https://twitter.com/saimum1978',
    ],
];