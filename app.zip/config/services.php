<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
        'endpoint' => env('MAILGUN_ENDPOINT', 'api.mailgun.net'),
        'scheme' => 'https',
    ],

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'bkash' => [
        'base_url' => env('BKASH_BASE_URL', 'https://tokenized.sandbox.bka.sh/v1.2.0-beta'),
        'base_url_live' => env('BKASH_BASE_URL_LIVE', 'https://tokenized.pay.bka.sh/v1.2.0-beta'),
        'app_key' => env('BKASH_APP_KEY'),
        'app_secret' => env('BKASH_APP_SECRET'),
        'username' => env('BKASH_USERNAME'),
        'password' => env('BKASH_PASSWORD'),
        'callback_url' => env('BKASH_CALLBACK_URL', env('APP_URL').'/payment/bkash/callback'),
        'mode' => env('BKASH_MODE', 'sandbox'), // sandbox|live
    ],

    'easypay' => [
        'base_url' => env('EASYPAY_BASE_URL', 'https://easypay.shilpigosthi.com'),
        'key' => env('EASYPAY_KEY'),
        'secret' => env('EASYPAY_SECRET'),
        'merchant_id' => env('EASYPAY_MERCHANT_ID'),
    ],

];
