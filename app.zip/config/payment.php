<?php

return [
    'enabled' => env('PAYMENT_FEATURE_ENABLED', false),
    'decision_screen' => true,
    'invoice_prefix' => 'SAIUM',
    'invoice_sequence_pad' => 4,
    // Public code (revealed post-payment) settings
    'public_code_prefix' => 'PUB',
    'public_code_sequence_pad' => 4,
    'unpaid_expiry_hours' => 24,
    'purge_enabled' => true,
    // Ordered gateway preference list; presence controls UI radio options
    'gateways' => [
        'dummy', // instant internal success (testing)
        'easypay', // external redirect flow
    ],
];