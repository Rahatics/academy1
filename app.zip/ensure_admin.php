<?php
// Ensure admin user exists
echo "Ensuring admin user exists...\n";

// Get database config from .env file
$env = file('.env');
$config = [];
foreach ($env as $line) {
    if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
        list($key, $value) = explode('=', trim($line), 2);
        $config[$key] = trim($value, '"\'');
    }
}

try {
    $dsn = "mysql:host={$config['DB_HOST']};port={$config['DB_PORT']};dbname={$config['DB_DATABASE']}";
    $pdo = new PDO($dsn, $config['DB_USERNAME'], $config['DB_PASSWORD']);
    echo "Database connection successful!\n";
    
    // Check if admins table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'admins'");
    $tables = $stmt->fetchAll();
    
    if (empty($tables)) {
        echo "Admins table does not exist! Please run migrations.\n";
        exit;
    }
    
    echo "Admins table exists.\n";
    
    // Check if admin user exists
    $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ?");
    $stmt->execute(['admin@saimum.org']);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($admin) {
        echo "Admin user already exists:\n";
        echo "Email: " . $admin['email'] . "\n";
        echo "Name: " . $admin['name'] . "\n";
    } else {
        echo "Admin user does not exist. Creating...\n";
        
        // Create admin user
        $hashedPassword = password_hash('password123', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO admins (name, email, password, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())");
        $stmt->execute(['Admin User', 'admin@saimum.org', $hashedPassword]);
        
        echo "Admin user created successfully!\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}