<?php

namespace Tests\Feature;

use App\Models\Form;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdvancedAddressRenderingTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function advanced_address_mode_does_not_duplicate_address_fields()
    {
        $form = Form::create([
            'name' => 'Admission',
            'status' => 'active',
            'fields' => [
                'elements' => [
                    [ 'type' => 'section', 'label' => 'ঠিকানা', 'fieldName' => 'address' ],
                    [ 'type' => 'select', 'label' => 'বর্তমান ঠিকানা - বিভাগ', 'fieldName' => 'division', 'required' => true ],
                    [ 'type' => 'select', 'label' => 'বর্তমান ঠিকানা - জেলা', 'fieldName' => 'district', 'required' => true ],
                    [ 'type' => 'select', 'label' => 'বর্তমান ঠিকানা - উপজেলা', 'fieldName' => 'upazila', 'required' => true ],
                    [ 'type' => 'text', 'label' => 'বর্তমান ঠিকানা - গ্রাম', 'fieldName' => 'address_details', 'required' => true ],
                    [ 'type' => 'checkbox', 'label' => 'বর্তমান ও স্থায়ী ঠিকানা একই হলে টিক দিন', 'fieldName' => 'is_permanent_address_same_as_present' ],
                    [ 'type' => 'select', 'label' => 'স্থায়ী ঠিকানা - বিভাগ', 'fieldName' => 'permanent_division' ],
                    [ 'type' => 'select', 'label' => 'স্থায়ী ঠিকানা - জেলা', 'fieldName' => 'permanent_district' ],
                    [ 'type' => 'select', 'label' => 'স্থায়ী ঠিকানা - উপজেলা', 'fieldName' => 'permanent_upazila' ],
                    [ 'type' => 'text', 'label' => 'স্থায়ী ঠিকানা - গ্রাম', 'fieldName' => 'permanent_address_details' ],
                ]
            ],
        ]);

        $resp = $this->get(route('forms.show', $form));
        $resp->assertStatus(200);

        // Ensure advanced present/permanent headings exist
        $resp->assertSee('বর্তমান ঠিকানা');
        $resp->assertSee('স্থায়ী ঠিকানা');

        // Ensure the address section heading appears exactly once now (we render it inline before the custom blocks)
        $html = $resp->getContent();
        $this->assertEquals(1, substr_count($html, 'border-bottom pb-2">ঠিকানা</h5>'));
        // The individual dynamic select labels should still be suppressed (we replace with custom UI headings)
        $resp->assertDontSee('বর্তমান ঠিকানা - বিভাগ');
        $resp->assertDontSee('স্থায়ী ঠিকানা - বিভাগ');
    }
}