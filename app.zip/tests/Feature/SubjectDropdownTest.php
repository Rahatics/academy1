<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\Admin;
use App\Models\Subject;

class SubjectDropdownTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_displays_dropdown_menu_correctly()
    {
        // Create admin user
        $admin = Admin::factory()->create();
        $this->actingAs($admin, 'admin');

        // Create subjects
        $subject1 = Subject::factory()->create([
            'name' => 'কিরাত',
            'code' => 'QIR101'
        ]);

        $subject2 = Subject::factory()->create([
            'name' => 'গান',
            'code' => 'MUS101'
        ]);

        // Visit subjects index page
        $response = $this->get(route('admin.subjects.index'));
        $response->assertStatus(200);
        
        // Check that dropdown buttons are present
        $response->assertSee('bx-dots-vertical-rounded');
        
        // Check that dropdown menu items are present
        $response->assertSee('সম্পাদনা');
        $response->assertSee('মুছুন');
    }

    /** @test */
    public function it_shows_fee_setting_option_for_subjects_with_forms()
    {
        // Create admin user
        $admin = Admin::factory()->create();
        $this->actingAs($admin, 'admin');

        // Create subject
        $subject = Subject::factory()->create([
            'name' => 'কিরাত',
            'code' => 'QIR101'
        ]);

        // Visit subjects index page
        $response = $this->get(route('admin.subjects.index'));
        $response->assertStatus(200);
        
        // Check that fee setting option is present (even if disabled)
        $response->assertSee('ফি সেটিং');
    }
}