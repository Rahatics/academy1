<?php

namespace Tests\Feature;

use App\Models\Application;
use App\Models\Payment;
use App\Services\PaymentService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Config;
use Tests\TestCase;

class BkashCallbackIdempotencyTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function executing_success_settlement_twice_does_not_duplicate_changes()
    {
        Config::set('payment.enabled', true);
        $app = Application::factory()->create([
            'payment_status' => 'pending_unpaid',
            'total_fee' => 150,
            'payment_due_at' => now()->addHour(),
        ]);

        // Simulate a bKash executed payment record (status executed)
        $payment = Payment::create([
            'application_id' => $app->id,
            'gateway' => 'bkash',
            'status' => 'executed',
            'amount' => 150,
            'currency' => 'BDT',
            'meta' => ['trxID' => 'TST123']
        ]);

        $service = app(PaymentService::class);
        $service->settleApplicationFromPayment($payment);
        $firstInvoice = $app->fresh()->internal_invoice;
        $firstPaidAt = $app->fresh()->paid_at;
        $firstPublic = $app->fresh()->public_application_code;

        // Second call should not change invoice or create duplicates
        $service->settleApplicationFromPayment($payment);
        $app->refresh();
        $this->assertEquals('paid', $app->payment_status);
        $this->assertEquals($firstInvoice, $app->internal_invoice);
        $this->assertEquals($firstPaidAt, $app->paid_at);
        $this->assertEquals($firstPublic, $app->public_application_code);
    }
}
