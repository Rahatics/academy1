<?php

namespace Tests\Feature;

use App\Models\Application;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Config;
use Tests\TestCase;

class NagadGatewaySkeletonTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function nagad_flow_marks_application_paid_and_executed_payment()
    {
        Config::set('payment.enabled', true);
        $app = Application::factory()->create([
            'payment_status' => 'pending_unpaid',
            'total_fee' => 250,
            'payment_due_at' => now()->addHour(),
        ]);
        session(['recent_application_id' => $app->id, 'recent_fee_breakdown' => []]);

        $resp = $this->post(route('forms.payment.pay_now', $app), ['gateway' => 'nagad']);
        $resp->assertRedirect(route('forms.payment.success', $app));
        $app->refresh();
        $this->assertEquals('paid', $app->payment_status);
        $payment = $app->payments()->where('gateway','nagad')->first();
        $this->assertNotNull($payment);
        $this->assertEquals('executed', $payment->status);
    }
}
