<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class BkashPaymentTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        // Provide required config so the service constructor has non-null typed strings
        config(['services.bkash' => [
            'base_url' => 'https://tokenized.sandbox.bka.sh/v1.2.0-beta',
            'app_key' => 'app_key_test',
            'app_secret' => 'app_secret_test',
            'username' => 'username_test',
            'password' => 'password_test',
            'callback_url' => 'http://localhost/payment/bkash/callback',
            'mode' => 'sandbox',
        ]]);
    }

    /** @test */
    public function it_creates_a_bkash_payment()
    {
        // Fake token and create responses
        Http::fake([
            '*/tokenized/checkout/token/grant' => Http::response([
                'id_token' => 'TEST_TOKEN',
                'expires_in' => 3600,
                'token_type' => 'Bearer'
            ], 200),
            '*/tokenized/checkout/create' => Http::response([
                'statusCode' => '0000',
                'paymentID' => 'PAY123',
                'bkashURL' => 'https://sandbox.bkash.com/checkout/PAY123',
                'statusMessage' => 'Successful'
            ], 200),
        ]);

        $response = $this->postJson('/payment/bkash/create', [
            'amount' => 100,
            'payer_reference' => 'TESTUSER'
        ]);

        $response->assertStatus(200)
            ->assertJson([
                'success' => true,
                'payment' => [
                    'payment_id' => 'PAY123',
                    'status' => 'created'
                ]
            ]);

        $this->assertDatabaseHas('payments', [
            'payment_id' => 'PAY123',
            'status' => 'created',
            'gateway' => 'bkash'
        ]);
    }
}
