<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class SimpleSubjectTest extends TestCase
{
    /** @test */
    public function it_can_access_the_subjects_page()
    {
        // Just check if the route exists
        $this->assertTrue(true); // Placeholder test
    }
}