<?php

namespace Tests\Feature;

use App\Models\Application;
use App\Models\Subject;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Illuminate\Support\Facades\Config;

class PaymentFlowTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        Config::set('payment.enabled', true);
        Subject::factory()->create(['code' => 'subj1', 'name' => 'Subject 1', 'fee' => 500]);
    }

    private function makeApplication(): Application
    {
        return Application::create([
            'name' => 'Test User',
            'email' => 'user@example.com',
            'phone' => '0123456789',
            'address' => 'Some address',
            'date_of_birth' => '2000-01-01',
            'occupation' => 'Student',
            'motivation' => 'Because I love it',
            'application_id' => 'APP-'.uniqid(),
            'total_fee' => 500,
            'payment_status' => 'pending_unpaid',
            'payment_due_at' => now()->addHours(24),
            'data' => ['desired_subject' => ['subj1']]
        ]);
    }

    public function test_pay_now_marks_application_paid_and_generates_invoice()
    {
    $app = $this->makeApplication();
    session(['recent_application_id' => $app->id, 'recent_fee_breakdown' => ['subj1' => ['name' => 'Subject 1','fee' => 500]]]);
        $response = $this->post(route('forms.payment.pay_now', $app));
        $response->assertRedirect(route('forms.payment.success', $app));
        $app->refresh();
        $this->assertEquals('paid', $app->payment_status);
        $this->assertNotNull($app->internal_invoice);
        $this->assertNotNull($app->paid_at);
        $this->assertDatabaseCount('payments', 1);
        $this->assertDatabaseHas('payments', [
            'application_id' => $app->id,
            'status' => 'success'
        ]);
    }

    public function test_pay_later_keeps_status_pending()
    {
    $app = $this->makeApplication();
    session(['recent_application_id' => $app->id, 'recent_fee_breakdown' => ['subj1' => ['name' => 'Subject 1','fee' => 500]]]);
        $response = $this->post(route('forms.payment.pay_later', $app));
        $response->assertRedirect(route('forms.payment.decision', $app));
        $app->refresh();
        $this->assertEquals('pending_unpaid', $app->payment_status);
        $this->assertNull($app->paid_at);
        $this->assertDatabaseCount('payments', 0);
    }
}
