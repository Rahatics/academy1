<?php

namespace Tests\Feature;

use App\Models\Application;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Config;
use Tests\TestCase;

class PaymentExpiryTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        Config::set('payment.enabled', true);
    }

    private function makeExpiredApplication(): Application
    {
        return Application::create([
            'name' => 'Expired User',
            'email' => 'exp@example.com',
            'phone' => '0123456789',
            'address' => 'Addr',
            'date_of_birth' => '2000-01-01',
            'occupation' => 'Student',
            'motivation' => 'Motivation',
            'application_id' => 'APP-'.uniqid(),
            'total_fee' => 500,
            'payment_status' => 'pending_unpaid',
            'payment_due_at' => now()->subMinutes(5),
        ]);
    }

    public function test_cannot_pay_after_expiry_dummy()
    {
        $app = $this->makeExpiredApplication();
        session(['recent_application_id' => $app->id]);
        $resp = $this->post(route('forms.payment.pay_now', $app));
        $resp->assertRedirect(route('forms.payment.decision', $app));
        $app->refresh();
        $this->assertEquals('expired_unpaid', $app->payment_status);
        $this->assertDatabaseCount('payments', 0);
    }
}
