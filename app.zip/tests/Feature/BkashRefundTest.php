<?php

namespace Tests\Feature;

use App\Models\Payment;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Tests\TestCase;

class BkashRefundTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        config(['services.bkash' => [
            'base_url' => 'https://tokenized.sandbox.bka.sh/v1.2.0-beta',
            'app_key' => 'app_key_test',
            'app_secret' => 'app_secret_test',
            'username' => 'username_test',
            'password' => 'password_test',
            'callback_url' => 'http://localhost/payment/bkash/callback',
            'mode' => 'sandbox',
        ]]);
    }

    /** @test */
    public function it_refunds_a_bkash_payment()
    {
        // Arrange: create an executed payment record
        $payment = Payment::create([
            'gateway' => 'bkash',
            'payment_id' => 'PAYEXEC123',
            'transaction_id' => 'TRX123',
            'amount' => 500.00,
            'currency' => 'BDT',
            'status' => 'executed',
            'payer_reference' => 'TESTUSER'
        ]);

        // Fake token and refund responses
        Http::fake([
            '*/tokenized/checkout/token/grant' => Http::response([
                'id_token' => 'TEST_TOKEN',
                'expires_in' => 3600,
                'token_type' => 'Bearer'
            ], 200),
            '*/tokenized/checkout/payment/refund' => Http::response([
                'statusCode' => '0000',
                'paymentID' => 'PAYEXEC123',
                'trxID' => 'TRX123',
                'originalTrxID' => 'TRX123',
                'refundTrxID' => 'RTRX999',
                'transactionStatus' => 'Completed',
                'amount' => '200',
                'currency' => 'BDT'
            ], 200),
        ]);

        // Act: attempt partial refund of 200
        $response = $this->postJson('/payment/bkash/refund', [
            'payment_id' => 'PAYEXEC123',
            'amount' => 200,
            'reason' => 'Customer Request'
        ]);

        // Assert response
        $response->assertStatus(200)
            ->assertJson([
                'success' => true,
            ]);
        $this->assertEquals('RTRX999', $response->json('payment.refund_transaction_id'));
        $this->assertEquals(200.0, (float)$response->json('payment.refunded_amount'));
    $this->assertEquals('Completed', $response->json('payment.refund_status'));

        // Assert database updated
        $this->assertDatabaseHas('payments', [
            'payment_id' => 'PAYEXEC123',
            'refunded_amount' => 200.0,
            'refund_transaction_id' => 'RTRX999',
        ]);

        // Act again: refund remaining 300
        Http::fake([
            '*/tokenized/checkout/token/grant' => Http::response([
                'id_token' => 'TEST_TOKEN',
                'expires_in' => 3600,
                'token_type' => 'Bearer'
            ], 200),
            '*/tokenized/checkout/payment/refund' => Http::response([
                'statusCode' => '0000',
                'paymentID' => 'PAYEXEC123',
                'trxID' => 'TRX123',
                'originalTrxID' => 'TRX123',
                'refundTrxID' => 'RTRX1000',
                'transactionStatus' => 'Completed',
                'amount' => '300',
                'currency' => 'BDT'
            ], 200),
        ]);

        $response2 = $this->postJson('/payment/bkash/refund', [
            'payment_id' => 'PAYEXEC123',
            'amount' => 300,
            'reason' => 'Customer Request'
        ]);

        $response2->assertStatus(200)
            ->assertJson([
                'success' => true,
            ]);
        $this->assertEquals(500.0, (float)$response2->json('payment.refunded_amount'));

        $this->assertDatabaseHas('payments', [
            'payment_id' => 'PAYEXEC123',
            'refunded_amount' => 500.0,
            'refund_status' => 'Completed'
        ]);
    }
}
