<?php

namespace Tests\Feature;

use App\Models\Application;
use App\Models\Payment;
use App\Services\PaymentService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PaymentStatusTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function application_status_is_automatically_set_to_reviewed_when_payment_is_marked_as_paid()
    {
        // Create an application with pending status
        $application = Application::factory()->create([
            'status' => 'pending',
            'payment_status' => 'unpaid'
        ]);

        // Create a payment for the application
        $payment = Payment::factory()->create([
            'application_id' => $application->id,
            'status' => 'initiated'
        ]);

        // Verify initial status
        $this->assertEquals('pending', $application->fresh()->status);
        $this->assertEquals('unpaid', $application->fresh()->payment_status);

        // Mark payment as successful
        $paymentService = new PaymentService();
        $paymentService->markSuccess($payment);

        // Verify that application status is now reviewed and payment status is paid
        $this->assertEquals('reviewed', $application->fresh()->status);
        $this->assertEquals('paid', $application->fresh()->payment_status);
    }

    /** @test */
    public function application_status_is_not_changed_if_already_reviewed_when_payment_is_marked_as_paid()
    {
        // Create an application with accepted status
        $application = Application::factory()->create([
            'status' => 'accepted',
            'payment_status' => 'unpaid'
        ]);

        // Create a payment for the application
        $payment = Payment::factory()->create([
            'application_id' => $application->id,
            'status' => 'initiated'
        ]);

        // Verify initial status
        $this->assertEquals('accepted', $application->fresh()->status);
        $this->assertEquals('unpaid', $application->fresh()->payment_status);

        // Mark payment as successful
        $paymentService = new PaymentService();
        $paymentService->markSuccess($payment);

        // Verify that application status remains accepted and payment status is paid
        $this->assertEquals('accepted', $application->fresh()->status);
        $this->assertEquals('paid', $application->fresh()->payment_status);
    }

    /** @test */
    public function application_with_paid_payment_in_review_status_remains_unchanged_when_payment_is_settled()
    {
        // Create an application with reviewed status and paid payment
        $application = Application::factory()->create([
            'status' => 'reviewed',
            'payment_status' => 'paid'
        ]);

        // Create a payment for the application
        $payment = Payment::factory()->create([
            'application_id' => $application->id,
            'status' => 'success'
        ]);

        // Verify initial status
        $this->assertEquals('reviewed', $application->fresh()->status);
        $this->assertEquals('paid', $application->fresh()->payment_status);

        // Settle application from payment (should not change status)
        $paymentService = new PaymentService();
        $paymentService->settleApplicationFromPayment($payment);

        // Verify that application status remains reviewed and payment status is still paid
        $this->assertEquals('reviewed', $application->fresh()->status);
        $this->assertEquals('paid', $application->fresh()->payment_status);
    }
}