<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\Form;
use App\Models\Admin;
use App\Models\Subject;

class SubjectEditFormFeeSettingsTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_displays_form_fee_settings_on_edit_page()
    {
        // Create admin user
        $admin = Admin::factory()->create();
        $this->actingAs($admin, 'admin');

        // Create subject
        $subject = Subject::factory()->create([
            'code' => 'QIR101',
            'fee' => 500,
            'is_active' => true
        ]);

        // Create form that uses the subject
        $form = Form::create([
            'name' => 'Test Form',
            'description' => 'Test form for subject fees',
            'status' => 'active',
            'created_by' => $admin->id,
            'fields' => [
                'elements' => [[
                    'id' => 'e1',
                    'type' => 'text',
                    'label' => 'ভর্তিচ্ছু বিষয়',
                    'fieldName' => 'desired_subject',
                    'required' => true,
                    'order' => 0
                ]]
            ]
        ]);

        // Visit subject edit page
        $response = $this->get(route('admin.subjects.edit', $subject));
        $response->assertStatus(200);
        $response->assertSee('ফর্ম ফি সেটিং');
        $response->assertSee($form->name);
    }

    /** @test */
    public function it_can_save_form_fees_from_edit_page()
    {
        // Create admin user
        $admin = Admin::factory()->create();
        $this->actingAs($admin, 'admin');

        // Create subject
        $subject = Subject::factory()->create([
            'code' => 'QIR101',
            'fee' => 500,
            'is_active' => true
        ]);

        // Create form
        $form = Form::create([
            'name' => 'Test Form',
            'description' => 'Test form for subject fees',
            'status' => 'active',
            'created_by' => $admin->id,
            'fields' => [
                'elements' => [[
                    'id' => 'e1',
                    'type' => 'text',
                    'label' => 'ভর্তিচ্ছু বিষয়',
                    'fieldName' => 'desired_subject',
                    'required' => true,
                    'order' => 0
                ]]
            ]
        ]);

        // Save form-specific fee via AJAX
        $response = $this->postJson(route('admin.subjects.save-form-fees', $subject), [
            'form_fees' => [
                $form->id => 600
            ]
        ]);

        $response->assertJson(['success' => true]);

        // Verify the fee was saved
        $updatedForm = Form::find($form->id);
        $this->assertEquals(600, $updatedForm->fields['subject_fees']['QIR101']);
    }
}