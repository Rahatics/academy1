<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\Form;
use App\Models\Admin;
use Illuminate\Support\Facades\Config;

class FormPaymentTest extends TestCase
{
    use RefreshDatabase;

    protected $admin;

    protected function setUp(): void
    {
        parent::setUp();
        $this->admin = Admin::factory()->create();
    }

    /** @test */
    public function form_with_fixed_payment_amount_redirects_to_payment_page()
    {
        // Enable payment feature
        Config::set('payment.enabled', true);
        
        // Create a form with payment required and fixed amount
        $form = Form::create([
            'name' => 'Test Form with Fixed Payment',
            'description' => 'A test form with fixed payment amount',
            'status' => 'active',
            'created_by' => $this->admin->id,
            'fields' => [
                'elements' => [
                    [
                        'id' => 'element_1',
                        'type' => 'text',
                        'label' => 'Full Name',
                        'fieldName' => 'name',
                        'required' => true,
                        'options' => []
                    ],
                    [
                        'id' => 'element_2',
                        'type' => 'text',
                        'label' => 'Email',
                        'fieldName' => 'email',
                        'required' => true,
                        'options' => []
                    ]
                ],
                'settings' => [
                    'paymentRequired' => true,
                    'paymentAmount' => 1000 // 1000 BDT fixed payment
                ]
            ]
        ]);

        // Submit the form with valid data
        $response = $this->post(route('forms.submit', $form), [
            'name' => 'John Doe',
            'email' => 'john@example.com'
        ]);

        // Check that we're redirected to the payment decision page
        $response->assertStatus(302);
        
        // Get the application from database
        $application = \App\Models\Application::where('form_id', $form->id)->first();
        $this->assertNotNull($application);
        
        // Check that we're redirected to payment decision page
        $response->assertRedirect(route('forms.payment.decision', $application));
        
        // Check that the application has the correct total fee
        $this->assertEquals(1000, $application->total_fee);
        $this->assertEquals('pending_unpaid', $application->payment_status);
    }

    /** @test */
    public function form_without_payment_required_does_not_redirect_to_payment_page()
    {
        // Enable payment feature
        Config::set('payment.enabled', true);
        
        // Create a form without payment required
        $form = Form::create([
            'name' => 'Test Form without Payment',
            'description' => 'A test form without payment requirement',
            'status' => 'active',
            'created_by' => $this->admin->id,
            'fields' => [
                'elements' => [
                    [
                        'id' => 'element_1',
                        'type' => 'text',
                        'label' => 'Full Name',
                        'fieldName' => 'name',
                        'required' => true,
                        'options' => []
                    ],
                    [
                        'id' => 'element_2',
                        'type' => 'text',
                        'label' => 'Email',
                        'fieldName' => 'email',
                        'required' => true,
                        'options' => []
                    ]
                ],
                'settings' => [
                    'paymentRequired' => false
                ]
            ]
        ]);

        // Submit the form with valid data
        $response = $this->post(route('forms.submit', $form), [
            'name' => 'John Doe',
            'email' => 'john@example.com'
        ]);

        // Check that we're redirected back with success message
        $response->assertStatus(302);
        $response->assertSessionHas('success');
        
        // Get the application from database
        $application = \App\Models\Application::where('form_id', $form->id)->first();
        $this->assertNotNull($application);
        
        // Check that the application is marked as paid (no payment required)
        $this->assertEquals(0, $application->total_fee);
        $this->assertEquals('paid', $application->payment_status);
    }
}