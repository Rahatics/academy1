<?php

namespace Tests\Feature;

use App\Models\Form;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class NoAddressAutoRenderTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function form_without_address_fields_does_not_render_address_ui()
    {
        $form = Form::create([
            'name' => 'Simple',
            'status' => 'active',
            'fields' => [
                'elements' => [
                    ['type' => 'text', 'label' => 'নাম', 'fieldName' => 'name', 'required' => true],
                    ['type' => 'email', 'label' => 'ইমেইল', 'fieldName' => 'email', 'required' => true],
                ]
            ],
        ]);

        $resp = $this->get(route('forms.show', $form));
        $resp->assertStatus(200);

        $html = $resp->getContent();
        // Ensure selects for division/district/upazila not present
        $this->assertStringNotContainsString('name="division"', $html);
        $this->assertStringNotContainsString('name="district"', $html);
        $this->assertStringNotContainsString('name="upazila"', $html);
        // Ensure the address heading label not auto injected
        $this->assertStringNotContainsString('ঠিকানা *', $html);
    }
}
