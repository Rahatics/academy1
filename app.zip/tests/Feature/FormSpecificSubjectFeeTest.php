<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\Form;
use App\Models\Admin;
use App\Models\Subject;
use App\Services\PricingService;

class FormSpecificSubjectFeeTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_uses_form_specific_fee_when_available()
    {
        config(['payment.enabled' => true]);
        
        // Seed subjects with fees
        $subject1 = Subject::factory()->create(['code' => 'QIR101', 'fee' => 500, 'is_active' => true]);
        $subject2 = Subject::factory()->create(['code' => 'ACT101', 'fee' => 700, 'is_active' => true]);

        $admin = Admin::factory()->create();
        
        // Create a form with custom subject fees
        $form = Form::create([
            'name' => 'Fee Form',
            'description' => 'Test',
            'status' => 'active',
            'created_by' => $admin->id,
            'fields' => [
                'elements' => [[
                    'id' => 'e1',
                    'type' => 'text',
                    'label' => 'ভর্তিচ্ছু বিষয়',
                    'fieldName' => 'desired_subject',
                    'required' => true,
                    'order' => 0
                ]],
                'subject_fees' => [
                    'QIR101' => 600, // Custom fee for QIR101 in this form
                    'ACT101' => 800  // Custom fee for ACT101 in this form
                ]
            ]
        ]);

        // Test with form-specific fees
        $service = new PricingService();
        $result = $service->calculate(['QIR101', 'ACT101'], $form);
        
        // Should use form-specific fees
        $this->assertEquals(1400.00, $result['total']);
        $this->assertEquals(600.00, $result['breakdown']['QIR101']['fee']);
        $this->assertEquals(800.00, $result['breakdown']['ACT101']['fee']);
    }

    /** @test */
    public function it_uses_default_subject_fee_when_no_form_specific_fee()
    {
        config(['payment.enabled' => true]);
        
        // Seed subjects with fees
        $subject1 = Subject::factory()->create(['code' => 'QIR101', 'fee' => 500, 'is_active' => true]);
        $subject2 = Subject::factory()->create(['code' => 'ACT101', 'fee' => 700, 'is_active' => true]);

        $admin = Admin::factory()->create();
        
        // Create a form without custom subject fees
        $form = Form::create([
            'name' => 'Fee Form',
            'description' => 'Test',
            'status' => 'active',
            'created_by' => $admin->id,
            'fields' => [
                'elements' => [[
                    'id' => 'e1',
                    'type' => 'text',
                    'label' => 'ভর্তিচ্ছু বিষয়',
                    'fieldName' => 'desired_subject',
                    'required' => true,
                    'order' => 0
                ]]
                // No subject_fees defined
            ]
        ]);

        // Test with default fees
        $service = new PricingService();
        $result = $service->calculate(['QIR101', 'ACT101'], $form);
        
        // Should use default subject fees
        $this->assertEquals(1200.00, $result['total']);
        $this->assertEquals(500.00, $result['breakdown']['QIR101']['fee']);
        $this->assertEquals(700.00, $result['breakdown']['ACT101']['fee']);
    }
}