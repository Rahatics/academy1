<?php

namespace Tests\Feature;

use App\Models\Application;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class PaymentGatewaySelectionTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        Config::set('payment.enabled', true);
        Config::set('payment.gateways', ['dummy','bkash']);
        Config::set('services.bkash', [
            'base_url' => 'https://tokenized.sandbox.bka.sh/v1.2.0-beta',
            'app_key' => 'app_key_test',
            'app_secret' => 'app_secret_test',
            'username' => 'username_test',
            'password' => 'password_test',
            'callback_url' => 'http://localhost/payment/bkash/callback',
            'mode' => 'sandbox',
        ]);
    }

    private function makeApplication(): Application
    {
        return Application::create([
            'name' => 'Test User',
            'email' => 'user@example.com',
            'phone' => '0123456789',
            'address' => 'Some address',
            'date_of_birth' => '2000-01-01',
            'occupation' => 'Student',
            'motivation' => 'Because I love it',
            'application_id' => 'APP-'.uniqid(),
            'total_fee' => 500,
            'payment_status' => 'pending_unpaid',
            'payment_due_at' => now()->addHours(24),
        ]);
    }

    public function test_bkash_gateway_initiation_redirects_to_bkash_url()
    {
        Http::fake([
            '*/tokenized/checkout/token/grant' => Http::response([
                'id_token' => 'TEST_TOKEN',
                'expires_in' => 3600,
                'token_type' => 'Bearer'
            ], 200),
            '*/tokenized/checkout/create' => Http::response([
                'statusCode' => '0000',
                'paymentID' => 'PAYBK123',
                'bkashURL' => 'https://sandbox.bkash.com/checkout/PAYBK123',
                'statusMessage' => 'Successful'
            ], 200),
        ]);

        $app = $this->makeApplication();
        session(['recent_application_id' => $app->id, 'recent_fee_breakdown' => []]);

        $response = $this->post(route('forms.payment.pay_now', $app), [
            'gateway' => 'bkash'
        ]);

        $response->assertRedirect('https://sandbox.bkash.com/checkout/PAYBK123');
        $this->assertDatabaseHas('payments', [
            'gateway' => 'bkash',
            'payment_id' => 'PAYBK123',
            'status' => 'created'
        ]);
    }
}
