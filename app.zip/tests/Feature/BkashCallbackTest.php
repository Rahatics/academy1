<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\Application;
use App\Models\Payment;

class BkashCallbackTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function callback_executes_payment_and_marks_application_paid()
    {
        // Enable payment feature
        config(['payment.enabled' => true]);

        $app = Application::factory()->create([
            'payment_status' => 'pending_unpaid',
            'total_fee' => 1500,
        ]);

        // Pre-create payment in created state (simulating create API call earlier)
        $payment = Payment::create([
            'application_id' => $app->id,
            'gateway' => 'bkash',
            'status' => 'created',
            'amount' => 1500,
            'currency' => 'BDT',
            'payment_id' => 'PAYMENT123',
            'meta' => ['phase' => 'created']
        ]);

        $payload = [
            'paymentID' => 'PAYMENT123',
            'trxID' => 'TRX999ABC'
        ];

        $response = $this->postJson(route('bkash.callback'), $payload);
        $response->assertStatus(200)->assertJson(['success' => true]);

        $payment->refresh();
        $app->refresh();

        $this->assertEquals('executed', $payment->status, 'Payment should be executed by callback');
        $this->assertEquals('TRX999ABC', $payment->transaction_id);
        $this->assertEquals('paid', $app->payment_status, 'Application should be settled');
        $this->assertNotNull($app->internal_invoice, 'Invoice should be generated');

        // Second callback idempotent
        $response2 = $this->postJson(route('bkash.callback'), $payload);
        $response2->assertStatus(200)->assertJson(['success' => true, 'idempotent' => true]);
    }
}
