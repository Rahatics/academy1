<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\Form;
use App\Models\Admin;

class LegacyDesiredSubjectFieldTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function legacy_field_name_is_mapped_to_new_name_in_render()
    {
        // Create a subject to ensure the subject selection UI is rendered
        $subject = \App\Models\Subject::factory()->create([
            'name' => 'Test Subject',
            'code' => 'TEST001',
            'fee' => 500
        ]);

        $admin = Admin::factory()->create();

        $form = Form::create([
            'name' => 'Legacy Desired Subject Form',
            'description' => 'Form with legacy field name',
            'status' => 'active',
            'created_by' => $admin->id,
            'template' => 'legacy_test',
            'fields' => [
                'elements' => [
                    [
                        'id' => 'element_1',
                        'type' => 'text',
                        'label' => 'ভর্তিচ্ছু বিষয়/বিভাগ',
                        'fieldName' => 'desired_subject_or_department',
                        'required' => true,
                        'order' => 1,
                    ],
                ],
            ],
        ]);

        $response = $this->get(route('forms.show', $form));
        $response->assertStatus(200);
        // The rendered HTML should contain the input with name="desired_subject[]" after mapping
        // Check for a part of the string that won't be affected by encoding
        $response->assertSee('desired_subject[]');
        // Should not contain the legacy field name attribute
        $response->assertDontSee('desired_subject_or_department');
    }
}