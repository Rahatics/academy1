<?php

namespace Tests\Feature;

use Tests\TestCase;

class HomePageTest extends TestCase
{
    /** @test */
    public function home_page_get_request_returns_success()
    {
        $response = $this->get('/');
        $response->assertStatus(200);
        $response->assertSee('সাইমুম শিল্পীগোষ্ঠী');
    }

    /** @test */
    public function home_page_head_request_returns_success()
    {
        $response = $this->call('HEAD', '/');
        $response->assertStatus(200);
    }
}
