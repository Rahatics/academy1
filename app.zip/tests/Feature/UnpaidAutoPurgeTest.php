<?php

namespace Tests\Feature;

use App\Models\Application;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Artisan;
use Tests\TestCase;

class UnpaidAutoPurgeTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function command_purges_only_expired_unpaid_applications()
    {
        $expired = Application::factory()->create([
            'payment_status' => 'pending_unpaid',
            'payment_due_at' => now()->subHours(2),
        ]);
        $future = Application::factory()->create([
            'payment_status' => 'pending_unpaid',
            'payment_due_at' => now()->addHours(2),
        ]);
        $paid = Application::factory()->create([
            'payment_status' => 'paid',
            'payment_due_at' => now()->subHours(5),
            'paid_at' => now()->subHours(4)
        ]);

        Artisan::call('applications:purge-expired');

        $this->assertDatabaseMissing('applications', ['id' => $expired->id]);
        $this->assertDatabaseHas('applications', ['id' => $future->id]);
        $this->assertDatabaseHas('applications', ['id' => $paid->id]);
    }

    /** @test */
    public function dry_run_does_not_delete()
    {
        $expired = Application::factory()->create([
            'payment_status' => 'pending_unpaid',
            'payment_due_at' => now()->subHour(),
        ]);
        Artisan::call('applications:purge-expired', ['--dry-run' => true]);
        $this->assertDatabaseHas('applications', ['id' => $expired->id]);
    }
}
