<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\Payment;
use App\Models\Application;
use Carbon\Carbon;

class PaymentReportingTest extends TestCase
{
    use RefreshDatabase;

    protected function seedPayments()
    {
        $app = Application::factory()->create(['total_fee' => 1000, 'payment_status' => 'paid']);
        Payment::factory()->create([
            'application_id' => $app->id,
            'gateway' => 'dummy',
            'status' => 'success',
            'amount' => 1000,
        ]);
        Payment::factory()->create([
            'status' => 'failed',
            'amount' => 500,
            'gateway' => 'dummy'
        ]);
    }

    /** @test */
    public function daily_summary_command_outputs_metrics()
    {
        Carbon::setTestNow(Carbon::create(2025,10,9,12,0,0));
        $this->seedPayments();
        $this->artisan('payments:daily-summary', ['date' => '2025-10-09'])
            ->assertExitCode(0)
            ->expectsOutputToContain('Payments Summary for 2025-10-09')
            ->expectsOutputToContain('Gross Collected')
            ->expectsOutputToContain('1000');
    }

    /** @test */
    public function csv_export_returns_csv_headers()
    {
        $this->seedPayments();
        $response = $this->get(route('admin.payments.export'));
        $response->assertStatus(200);
        $this->assertStringContainsString('text/csv', $response->headers->get('Content-Type'));
        $this->assertStringContainsString('id,application_id', $response->getContent());
    }
}
