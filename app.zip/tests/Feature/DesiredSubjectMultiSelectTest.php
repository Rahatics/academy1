<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\Form;
use App\Models\Admin;
use App\Models\Subject;

class DesiredSubjectMultiSelectTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function user_can_submit_multiple_desired_subject_codes()
    {
        // Seed subjects
        Subject::factory()->create(['name' => 'কিরাত', 'code' => 'QIR101']);
        Subject::factory()->create(['name' => 'গান', 'code' => 'MUS101']);
        Subject::factory()->create(['name' => 'অভিনয়', 'code' => 'ACT101']);

        $admin = Admin::factory()->create();

        $form = Form::create([
            'name' => 'Multi Subject Form',
            'description' => 'Test form',
            'status' => 'active',
            'created_by' => $admin->id,
            'template' => 'multi_subject_test',
            'fields' => [
                'elements' => [
                    [
                        'id' => 'element_1',
                        'type' => 'text',
                        'label' => 'ভর্তিচ্ছু বিষয়',
                        'fieldName' => 'desired_subject',
                        'required' => true,
                        'order' => 1,
                    ],
                ],
            ],
        ]);

        $response = $this->post(route('forms.submit', $form), [
            'name' => 'Test User',
            'email' => 'test@example.com',
            'phone' => '01234567890',
            'address' => 'Some address',
            'desired_subject' => ['QIR101','MUS101','ACT101'],
        ]);

        $response->assertRedirect();
        $this->assertDatabaseHas('applications', [
            'subject' => 'QIR101,MUS101,ACT101'
        ]);

        $app = \App\Models\Application::first();
        $this->assertIsArray($app->data['desired_subject']);
        $this->assertEquals(['QIR101','MUS101','ACT101'], $app->data['desired_subject']);
    }
}
