<?php

namespace Tests\Feature;

use App\Models\Application;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class BkashEndToEndPaymentTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        Config::set('payment.enabled', true);
        Config::set('payment.gateways', ['dummy','bkash']);
        Config::set('services.bkash', [
            'base_url' => 'https://tokenized.sandbox.bka.sh/v1.2.0-beta',
            'app_key' => 'app_key_test',
            'app_secret' => 'app_secret_test',
            'username' => 'username_test',
            'password' => 'password_test',
            'callback_url' => 'http://localhost/payment/bkash/callback',
            'mode' => 'sandbox',
        ]);
    }

    private function makeApplication(): Application
    {
        return Application::create([
            'name' => 'Test User',
            'email' => 'user@example.com',
            'phone' => '0123456789',
            'address' => 'Some address',
            'date_of_birth' => '2000-01-01',
            'occupation' => 'Student',
            'motivation' => 'Because I love it',
            'application_id' => 'APP-'.uniqid(),
            'total_fee' => 500,
            'payment_status' => 'pending_unpaid',
            'payment_due_at' => now()->addHours(24),
        ]);
    }

    public function test_full_bkash_flow_marks_application_paid()
    {
        Http::fake([
            '*/tokenized/checkout/token/grant' => Http::response([
                'id_token' => 'TEST_TOKEN',
                'expires_in' => 3600,
                'token_type' => 'Bearer'
            ], 200),
            '*/tokenized/checkout/create' => Http::response([
                'statusCode' => '0000',
                'paymentID' => 'PAYFLOW1',
                'bkashURL' => 'https://sandbox.bkash.com/checkout/PAYFLOW1',
                'statusMessage' => 'Successful'
            ], 200),
            '*/tokenized/checkout/execute' => Http::response([
                'statusCode' => '0000',
                'trxID' => 'TRX123',
                'paymentID' => 'PAYFLOW1'
            ], 200),
        ]);

        $app = $this->makeApplication();
        session(['recent_application_id' => $app->id]);

        // Initiate (redirect to bKash)
        $init = $this->post(route('forms.payment.pay_now', $app), ['gateway' => 'bkash']);
        $init->assertRedirect('https://sandbox.bkash.com/checkout/PAYFLOW1');
        $this->assertDatabaseHas('payments', [
            'payment_id' => 'PAYFLOW1',
            'status' => 'created'
        ]);

        // Simulate bKash returning user with payment_id
        $return = $this->get(route('forms.payment.bkash.return', [$app, 'payment_id' => 'PAYFLOW1']));
        $return->assertStatus(200)->assertSee('পেমেন্ট এক্সিকিউট');

        // Execute
        $exec = $this->post(route('forms.payment.bkash.execute', $app), ['payment_id' => 'PAYFLOW1']);
        $exec->assertRedirect(route('forms.payment.success', $app));
        $app->refresh();
        $this->assertEquals('paid', $app->payment_status);
        $this->assertNotNull($app->paid_at);
    }
}
