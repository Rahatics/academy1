<?php

namespace Tests\Feature;

use App\Models\Application;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Config;
use Tests\TestCase;

class StatusCheckPayNowTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function unpaid_future_application_shows_pay_now_button()
    {
        Config::set('payment.enabled', true);
        $app = Application::factory()->create([
            'payment_status' => 'pending_unpaid',
            'total_fee' => 500,
            'payment_due_at' => now()->addHours(5),
        ]);

        $resp = $this->post('/application-status', ['application_id' => $app->application_id]);
        $resp->assertStatus(200)
            ->assertSee('পেমেন্ট করুন');

        // Session primed for payment decision
        $this->assertEquals($app->id, session('recent_application_id'));
    }

    /** @test */
    public function expired_application_does_not_show_pay_now_button()
    {
        Config::set('payment.enabled', true);
        $app = Application::factory()->create([
            'payment_status' => 'pending_unpaid',
            'total_fee' => 500,
            'payment_due_at' => now()->subHour(),
        ]);

        $resp = $this->post('/application-status', ['application_id' => $app->application_id]);
        $resp->assertStatus(200)
            ->assertDontSee('পেমেন্ট করুন')
            ->assertSee('অতিক্রান্ত');
    }
}
