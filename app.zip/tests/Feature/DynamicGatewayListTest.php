<?php

namespace Tests\Feature;

use App\Models\PaymentGatewaySetting;
use App\Models\Application;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Config;
use Tests\TestCase;

class DynamicGatewayListTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function only_active_gateways_are_listed()
    {
        Config::set('payment.enabled', true);
        // Baseline config includes dummy & bkash
        PaymentGatewaySetting::create(['gateway' => 'dummy','active' => true,'mode' => 'sandbox']);
        PaymentGatewaySetting::create(['gateway' => 'bkash','active' => false,'mode' => 'sandbox']);
        PaymentGatewaySetting::create(['gateway' => 'nagad','active' => true,'mode' => 'sandbox']);

        $app = Application::factory()->create([
            'payment_status' => 'pending_unpaid',
            'payment_due_at' => now()->addHours(2),
            'total_fee' => 0,
        ]);
        session(['recent_application_id' => $app->id, 'recent_fee_breakdown' => []]);

        $resp = $this->get(route('forms.payment.decision', $app));
        $resp->assertStatus(200);
        // Should see dummy and nagad, not bkash (inactive)
        $resp->assertSee('value="dummy"', false);
        $resp->assertSee('value="nagad"', false);
        $resp->assertDontSee('value="bkash"', false);
    }
}
