<?php

namespace Tests\Feature;

use App\Models\Form;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PersonalInfoDeduplicationTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function dynamic_personal_info_fields_prevent_static_duplicates()
    {
        $form = Form::create([
            'name' => 'Admission',
            'status' => 'active',
            'fields' => [
                'elements' => [
                    ['type' => 'text', 'label' => 'নাম', 'fieldName' => 'name', 'required' => true],
                    ['type' => 'email', 'label' => 'ইমেইল', 'fieldName' => 'email', 'required' => true],
                    ['type' => 'text', 'label' => 'ফোন নম্বর', 'fieldName' => 'phone', 'required' => true],
                ]
            ],
        ]);

        $resp = $this->get(route('forms.show', $form));
        $resp->assertStatus(200);

        // Should only appear once each (dynamic). We ensure static fallback markup not duplicated by checking input count via substr count roughly.
        $html = $resp->getContent();
        $this->assertEquals(1, substr_count($html, 'id="name"'));
        $this->assertEquals(1, substr_count($html, 'id="email"'));
        $this->assertEquals(1, substr_count($html, 'id="phone"'));
    }
}
