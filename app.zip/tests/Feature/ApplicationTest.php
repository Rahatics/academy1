<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\Application;

class ApplicationTest extends TestCase
{
    use RefreshDatabase;
    
    /** @test */
    public function it_can_create_an_application()
    {
        $data = [
            'name' => 'মোহাম্মদ আলী',
            'email' => 'ali@example.com',
            'phone' => '01712345678',
            'address' => 'ঢাকা, বাংলাদেশ',
            'dob' => '1995-05-15',
            'occupation' => 'ছাত্র',
            'skills' => 'গান, নাটক',
            'experience' => 'বিগত ২ বছর ধরে বিভিন্ন সাংস্কৃতিক কার্যক্রমে অংশ নিয়েছি',
            'motivation' => 'ইসলামী সংস্কৃতি ছড়িয়ে দিতে চাই',
            'reference' => 'আব্দুল কাদের',
        ];
        
        $response = $this->post('/application', $data);
        
        $response->assertStatus(302); // Redirect back
        $this->assertDatabaseHas('applications', [
            'email' => 'ali@example.com',
            'status' => 'pending'
        ]);
    }
    
    /** @test */
    public function it_can_check_application_status_by_id()
    {
        // Create a sample application
        $application = Application::factory()->create([
            'application_id' => 'APP-2025-TEST01',
            'email' => 'test@example.com',
            'status' => 'accepted'
        ]);
        
        $response = $this->post('/application-status', [
            'application_id' => $application->application_id
        ]);
        
        $response->assertStatus(200);
        $response->assertSee($application->application_id);
        $response->assertSee('আবেদন গৃহীত!');
    }
    
    /** @test */
    public function it_can_check_application_status_by_email()
    {
        // Create a sample application
        $application = Application::factory()->create([
            'application_id' => 'APP-2025-TEST02',
            'email' => 'test2@example.com',
            'status' => 'pending'
        ]);
        
        $response = $this->post('/application-status', [
            'application_id' => $application->email
        ]);
        
        $response->assertStatus(200);
        $response->assertSee($application->application_id);
        $response->assertSee('আবেদন পর্যালোচনাধীন!');
    }
}