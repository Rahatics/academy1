<?php

namespace Tests\Feature;

use App\Models\Form;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class FormShowDivisionsTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function active_form_show_page_displays_division_options()
    {
        // Arrange: create an active form
        $form = Form::create([
            'name' => 'Public Form',
            'description' => 'Testing divisions',
            'status' => 'active',
            'fields' => [
                'elements' => [
                    // Include at least one base address field so address UI renders under gating rules
                    ['type' => 'section', 'label' => 'ঠিকানা', 'fieldName' => 'address'],
                    ['type' => 'select', 'label' => 'বর্তমান ঠিকানা - বিভাগ', 'fieldName' => 'division', 'required' => true],
                ]
            ],
        ]);

        // Act: hit the show route
        $response = $this->get(route('forms.show', $form));

        // Assert: page loads
        $response->assertStatus(200);

        // Basic heuristic: expect at least one known division name from locations.json (e.g., বরিশাল)
        $response->assertSee('বরিশাল');
    }

    /** @test */
    public function inactive_form_returns_404()
    {
        $form = Form::create([
            'name' => 'Inactive Form',
            'status' => 'inactive',
        ]);

        $this->get(route('forms.show', $form))->assertStatus(404);
    }
}
