<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\Form;
use App\Models\Admin;
use App\Models\Subject;

class ImprovedSubjectsPageTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_displays_subjects_with_improved_ui()
    {
        // Create admin user
        $admin = Admin::factory()->create();
        $this->actingAs($admin, 'admin');

        // Create subjects
        $subject1 = Subject::factory()->create([
            'name' => 'কিরাত',
            'code' => 'QIR101',
            'fee' => 500,
            'is_active' => true
        ]);

        $subject2 = Subject::factory()->create([
            'name' => 'গান',
            'code' => 'MUS101',
            'fee' => 500,
            'is_active' => false
        ]);

        // Visit subjects index page
        $response = $this->get(route('admin.subjects.index'));
        $response->assertStatus(200);
        
        // Check that subjects are displayed with improved UI
        $response->assertSee('কিরাত');
        $response->assertSee('QIR101');
        $response->assertSee('500.00৳');
        $response->assertSee('সক্রিয়');
        $response->assertSee('গান');
        $response->assertSee('MUS101');
        $response->assertSee('নিষ্ক্রিয়');
    }

    /** @test */
    public function it_shows_button_group_for_actions()
    {
        // Create admin user
        $admin = Admin::factory()->create();
        $this->actingAs($admin, 'admin');

        // Create subject
        $subject = Subject::factory()->create([
            'name' => 'কিরাত',
            'code' => 'QIR101',
            'fee' => 500,
            'is_active' => true
        ]);

        // Visit subjects index page
        $response = $this->get(route('admin.subjects.index'));
        $response->assertStatus(200);
        
        // Check that button group is present
        $response->assertSee('btn-group');
        // Check that individual action buttons are present
        $response->assertSee('bx-edit');
        $response->assertSee('bx-cog');
        $response->assertSee('bx-trash');
    }

    /** @test */
    public function it_filters_subjects_by_search()
    {
        // Create admin user
        $admin = Admin::factory()->create();
        $this->actingAs($admin, 'admin');

        // Create subjects
        $subject1 = Subject::factory()->create([
            'name' => 'কিরাত',
            'code' => 'QIR101'
        ]);

        $subject2 = Subject::factory()->create([
            'name' => 'গান',
            'code' => 'MUS101'
        ]);

        // Visit subjects index page
        $response = $this->get(route('admin.subjects.index'));
        $response->assertStatus(200);
    }
}