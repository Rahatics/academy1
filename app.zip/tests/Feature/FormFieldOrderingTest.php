<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\Form;

class FormFieldOrderingTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function reordered_fields_render_in_new_order()
    {
        // Create form with two text fields A then B
        $form = Form::create([
            'name' => 'Ordering',
            'status' => 'active',
            'fields' => [
                'elements' => [
                    [ 'type' => 'text', 'label' => 'Field A', 'fieldName' => 'field_a', 'required' => false, 'order' => 0 ],
                    [ 'type' => 'text', 'label' => 'Field B', 'fieldName' => 'field_b', 'required' => false, 'order' => 1 ],
                ]
            ],
        ]);

        // Assert initial order A before B
        $resp = $this->get(route('forms.show', $form));
        $resp->assertStatus(200);
        $html = $resp->getContent();
        $this->assertTrue(strpos($html, 'Field A') < strpos($html, 'Field B'));

        // Simulate builder reordering: B then A via update-fields route
        $payload = [
            'fields' => [
                'elements' => [
                    [ 'type' => 'text', 'label' => 'Field B', 'fieldName' => 'field_b', 'required' => false ],
                    [ 'type' => 'text', 'label' => 'Field A', 'fieldName' => 'field_a', 'required' => false ],
                ]
            ],
            'name' => $form->name,
            'description' => $form->description,
        ];

        $this->postJson(route('admin.forms.update-fields', $form), $payload)
            ->assertStatus(200)
            ->assertJson(['success' => true]);

        $form->refresh();

        // Fetch show page again and ensure order flipped
        $resp2 = $this->get(route('forms.show', $form));
        $resp2->assertStatus(200);
        $html2 = $resp2->getContent();
        $this->assertTrue(strpos($html2, 'Field B') < strpos($html2, 'Field A'));
    }
}
