<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\Form;
use App\Models\Admin;
use App\Models\Subject;
use App\Services\PricingService;

class ApplicationFeeCaptureTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_stores_total_fee_on_submit_when_feature_enabled()
    {
        config(['payment.enabled' => true]);
        // Seed subjects with fees
    Subject::factory()->create(['code' => 'QIR101','fee' => 500,'is_active' => true]);
    Subject::factory()->create(['code' => 'ACT101','fee' => 700,'is_active' => true]);

        $admin = Admin::factory()->create();
        $form = Form::create([
            'name' => 'Fee Form',
            'description' => 'Test',
            'status' => 'active',
            'created_by' => $admin->id,
            'fields' => [
                'elements' => [[
                    'id' => 'e1',
                    'type' => 'text',
                    'label' => 'ভর্তিচ্ছু বিষয়',
                    'fieldName' => 'desired_subject',
                    'required' => true,
                    'order' => 0
                ]]
            ]
        ]);

        $response = $this->post(route('forms.submit', $form), [
            'name' => 'Test User',
            'email' => 'test@example.com',
            'phone' => '01700000000',
            'address' => 'X',
            'desired_subject' => ['QIR101','ACT101']
        ]);

        $response->assertRedirect();
        $app = \App\Models\Application::first();
        $this->assertEquals(1200.00, (float)$app->total_fee);
        $this->assertEquals('pending_unpaid', $app->payment_status);
    }
}
