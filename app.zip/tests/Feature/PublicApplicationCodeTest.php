<?php

namespace Tests\Feature;

use App\Models\Application;
use App\Models\Payment;
use App\Services\PaymentService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PublicApplicationCodeTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function public_code_is_generated_only_after_payment_success()
    {
        $application = Application::factory()->create([
            'total_fee' => 1000,
            'payment_status' => 'pending_unpaid',
            'public_application_code' => null,
        ]);

        $this->assertNull($application->public_application_code, 'Code should be null before payment');

        $payment = Payment::create([
            'application_id' => $application->id,
            'gateway' => 'dummy',
            'status' => 'initiated',
            'amount' => 1000,
            'currency' => 'BDT',
        ]);

        $service = app(PaymentService::class);
        $service->markSuccess($payment);

        $application->refresh();
        $this->assertNotNull($application->public_application_code, 'Code should be generated after payment');
        $this->assertMatchesRegularExpression('/^APP-\d{8}-\d{4}$/', $application->public_application_code);
    }
}
