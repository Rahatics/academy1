<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Models\Admin;
use App\Models\Subject;

class SubjectTest extends TestCase
{
    use RefreshDatabase;

    protected $admin;

    protected function setUp(): void
    {
        parent::setUp();
        $this->admin = Admin::factory()->create();
    }

    /** @test */
    public function admin_can_view_subjects_index()
    {
        $response = $this->actingAs($this->admin, 'admin')
                         ->get(route('admin.subjects.index'));

        $response->assertStatus(200);
        $response->assertViewIs('admin.subjects.index');
    }

    /** @test */
    public function admin_can_create_subject()
    {
        $subjectData = [
            'name' => 'গান',
            'code' => 'MUS101',
            'description' => 'গান শিক্ষা এবং প্রশিক্ষণ',
            'is_active' => true
        ];

        $response = $this->actingAs($this->admin, 'admin')
                         ->post(route('admin.subjects.store'), $subjectData);

        $response->assertRedirect(route('admin.subjects.index'));
        $this->assertDatabaseHas('subjects', $subjectData);
    }

    /** @test */
    public function admin_can_update_subject()
    {
        $subject = Subject::factory()->create();
        $updatedData = [
            'name' => 'নাটক',
            'code' => 'ACT101',
            'description' => 'নাট্য শিক্ষা এবং প্রশিক্ষণ',
            'is_active' => false
        ];

        $response = $this->actingAs($this->admin, 'admin')
                         ->put(route('admin.subjects.update', $subject), $updatedData);

        $response->assertRedirect(route('admin.subjects.index'));
        $this->assertDatabaseHas('subjects', $updatedData);
    }

    /** @test */
    public function admin_can_delete_subject()
    {
        $subject = Subject::factory()->create();

        $response = $this->actingAs($this->admin, 'admin')
                         ->delete(route('admin.subjects.destroy', $subject));

        $response->assertRedirect(route('admin.subjects.index'));
        $this->assertDatabaseMissing('subjects', ['id' => $subject->id]);
    }

    /** @test */
    public function admin_can_update_subject_status()
    {
        $subject = Subject::factory()->create(['is_active' => true]);

        $response = $this->actingAs($this->admin, 'admin')
                         ->putJson(route('admin.subjects.update-status', $subject), [
                             'is_active' => false
                         ]);

        $response->assertJson(['success' => true]);
        $this->assertFalse($subject->fresh()->is_active);
    }
}