<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\Admin;
use App\Models\Subject;

class SubjectButtonGroupTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_displays_button_group_correctly()
    {
        // Create admin user
        $admin = Admin::factory()->create();
        $this->actingAs($admin, 'admin');

        // Create subjects
        $subject1 = Subject::factory()->create([
            'name' => 'কিরাত',
            'code' => 'QIR101'
        ]);

        $subject2 = Subject::factory()->create([
            'name' => 'গান',
            'code' => 'MUS101'
        ]);

        // Visit subjects index page
        $response = $this->get(route('admin.subjects.index'));
        $response->assertStatus(200);
        
        // Check that individual buttons are present
        $response->assertSee('bx-edit');
        $response->assertSee('bx-cog');
        $response->assertSee('bx-trash');
        
        // Check that button group structure is present
        $response->assertSee('btn-group');
    }

    /** @test */
    public function it_shows_disabled_fee_button_for_subjects_without_forms()
    {
        // Create admin user
        $admin = Admin::factory()->create();
        $this->actingAs($admin, 'admin');

        // Create subject
        $subject = Subject::factory()->create([
            'name' => 'কিরাত',
            'code' => 'QIR101'
        ]);

        // Visit subjects index page
        $response = $this->get(route('admin.subjects.index'));
        $response->assertStatus(200);
        
        // Check that fee button is present but disabled
        $response->assertSee('btn-secondary');
        $response->assertSee('ফি সেটিং (কোন ফর্ম নেই)');
    }
}