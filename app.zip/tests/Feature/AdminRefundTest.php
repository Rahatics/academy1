<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Payment;
use App\Models\Application;
use Illuminate\Foundation\Testing\RefreshDatabase;

class AdminRefundTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_processes_a_full_refund_for_dummy_gateway()
    {
        $app = Application::factory()->create([
            'payment_status' => 'paid',
            'total_fee' => 500,
        ]);

        $payment = Payment::factory()->create([
            'application_id' => $app->id,
            'gateway' => 'dummy',
            'status' => 'executed',
            'amount' => 500,
            'refunded_amount' => null,
        ]);

        $resp = $this->post(route('admin.payments.refund', $payment), [
            'amount' => 500,
            'reason' => 'Test full refund'
        ]);

        $resp->assertRedirect();
        $payment->refresh();
        $this->assertEquals(500, (float)$payment->refunded_amount);
        $this->assertEquals('refunded', $payment->refund_status);
        $this->assertNotNull($payment->refunded_at);
    }

    /** @test */
    public function it_prevents_over_refund()
    {
        $app = Application::factory()->create([
            'payment_status' => 'paid',
            'total_fee' => 400,
        ]);
        $payment = Payment::factory()->create([
            'application_id' => $app->id,
            'gateway' => 'dummy',
            'status' => 'executed',
            'amount' => 400,
        ]);

        $this->post(route('admin.payments.refund', $payment), [
            'amount' => 300,
        ])->assertRedirect();

        $payment->refresh();
        $this->assertEquals(300, (float)$payment->refunded_amount);
        $this->assertEquals('partially_refunded', $payment->refund_status);

        // Attempt to over-refund (remaining 100, attempt 150)
        $this->post(route('admin.payments.refund', $payment), [
            'amount' => 150,
        ])->assertRedirect();

        $payment->refresh();
        // Should remain unchanged second time
        $this->assertEquals(300, (float)$payment->refunded_amount);
    }

    /** @test */
    public function it_rejects_refund_for_non_executed_payment()
    {
        $payment = Payment::factory()->create([
            'status' => 'initiated',
            'amount' => 200,
        ]);

        $resp = $this->post(route('admin.payments.refund', $payment), [
            'amount' => 50,
        ]);
        $resp->assertRedirect();
        $payment->refresh();
        $this->assertNull($payment->refunded_amount);
    }
}
