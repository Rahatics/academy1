<?php

namespace Tests\Feature;

use App\Models\Application;
use App\Models\Payment;
use App\Services\PaymentService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Config;
use Tests\TestCase;

class PublicApplicationCodeVisibilityTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function decision_page_shows_placeholder_until_paid_then_success_page_shows_code()
    {
        Config::set('payment.enabled', true);

        $app = Application::factory()->create([
            'total_fee' => 500,
            'payment_status' => 'pending_unpaid',
            'public_application_code' => null,
            'payment_due_at' => now()->addHours(24),
        ]);

        // Simulate recent application session guard
        session(['recent_application_id' => $app->id, 'recent_fee_breakdown' => []]);

        // Decision page before payment: placeholder visible, no code
        $resp = $this->get(route('forms.payment.decision', $app));
        $resp->assertStatus(200);
        $resp->assertSee('পেমেন্টের পর প্রদান');
        $resp->assertDontSee('APP-'); // public code pattern prefix

        // Create and succeed a dummy payment
        $payment = Payment::create([
            'application_id' => $app->id,
            'gateway' => 'dummy',
            'status' => 'initiated',
            'amount' => 500,
            'currency' => 'BDT'
        ]);
        app(PaymentService::class)->markSuccess($payment);
        $app->refresh();
        $this->assertNotNull($app->public_application_code);

        // Success page now shows code
        $resp2 = $this->get(route('forms.payment.success', $app));
        $resp2->assertStatus(200);
        $resp2->assertSee($app->public_application_code);
        $resp2->assertDontSee('পেমেন্টের পর দেখাবে');
    }
}
