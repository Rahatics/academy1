<?php

namespace Tests\Feature;

use App\Models\Application;
use App\Models\Payment;
use App\Services\PaymentReportService;
use App\Services\PaymentService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Config;
use Tests\TestCase;

class RefundReportingIntegrityTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function net_collected_equals_gross_minus_refunds()
    {
        Config::set('payment.enabled', true);
        $svc = app(PaymentService::class);
        // Create 2 paid applications
        $apps = Application::factory()->count(2)->create([
            'payment_status' => 'pending_unpaid',
            'total_fee' => 500,
            'payment_due_at' => now()->addHour(),
        ]);
        $gross = 0;
        foreach($apps as $a) {
            $p = $a->payments()->create([
                'gateway' => 'dummy',
                'status' => 'initiated',
                'amount' => 500,
                'currency' => 'BDT'
            ]);
            $svc->markSuccess($p);
            $a->refresh();
            $gross += 500;
        }
        // Refund 200 from first payment
        $firstPayment = $apps[0]->payments()->first();
        $svc->refund($firstPayment, 200, 'partial test');

        $report = app(PaymentReportService::class)->dailySummary(now());
        $this->assertEquals($gross, $report['gross_collected']);
        $this->assertEquals(200.0, $report['total_refunded']);
        $this->assertEquals($gross - 200.0, $report['net_collected']);
    }

    /** @test */
    public function refund_cannot_exceed_paid_amount_and_reporting_reflects_partial()
    {
        Config::set('payment.enabled', true);
        $svc = app(PaymentService::class);
        $app = Application::factory()->create([
            'payment_status' => 'pending_unpaid',
            'total_fee' => 300,
            'payment_due_at' => now()->addHour(),
        ]);
        $p = $app->payments()->create([
            'gateway' => 'dummy',
            'status' => 'initiated',
            'amount' => 300,
            'currency' => 'BDT'
        ]);
        $svc->markSuccess($p);
        // Partial refund 100
        $svc->refund($p, 100, 'first');
        // Attempt invalid over-refund (will throw)
        $this->expectException(\RuntimeException::class);
        $svc->refund($p, 500, 'over');
    }
}
