<?php

namespace Tests\Feature;

use App\Models\Application;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class EasypayPaymentTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        Config::set('payment.enabled', true);
        Config::set('payment.gateways', ['dummy', 'easypay']);
        Config::set('services.easypay', [
            'base_url' => 'https://easypay.shilpigosthi.com',
            'key' => 'ak_60R1Ur1bq7UKT03Al0MpdSQC5ZSWRrri',
            'secret' => 'sk_zaEtNJYtxImfCPfRVxjfF71hBN3uaJOHXfcWReVtJ1vgyCNpqHkQEe9cCMEZ5ZIL',
            'merchant_id' => 'mer_68fe94981cecd',
        ]);
    }

    private function makeApplication(): Application
    {
        return Application::create([
            'name' => 'Test User',
            'email' => 'user@example.com',
            'phone' => '0123456789',
            'address' => 'Some address',
            'date_of_birth' => '2000-01-01',
            'occupation' => 'Student',
            'motivation' => 'Because I love it',
            'application_id' => 'APP-'.uniqid(),
            'total_fee' => 500,
            'payment_status' => 'pending_unpaid',
            'payment_due_at' => now()->addHours(24),
        ]);
    }

    public function test_easypay_gateway_initiation_redirects_to_easypay_url()
    {
        Http::fake([
            'https://easypay.shilpigosthi.com/api/payment/process' => Http::response([
                'checkout_url' => 'https://easypay.shilpigosthi.com/checkout/TEST123',
                'payment_id' => 'PAYEASY123',
                'status' => 'success'
            ], 200),
        ]);

        $app = $this->makeApplication();
        session(['recent_application_id' => $app->id, 'recent_fee_breakdown' => []]);

        $response = $this->post(route('forms.payment.pay_now', $app), [
            'gateway' => 'easypay'
        ]);

        $response->assertRedirect('https://easypay.shilpigosthi.com/checkout/TEST123');
        $this->assertDatabaseHas('payments', [
            'gateway' => 'easypay',
            'status' => 'initiated'
        ]);
    }
}