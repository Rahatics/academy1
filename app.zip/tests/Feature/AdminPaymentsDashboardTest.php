<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\Application;
use App\Models\Payment;

class AdminPaymentsDashboardTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_lists_payments_with_filters()
    {
        $app1 = Application::factory()->create(['total_fee' => 1000, 'payment_status' => 'paid']);
        $app2 = Application::factory()->create(['total_fee' => 500, 'payment_status' => 'pending_unpaid']);

        Payment::factory()->create([ 'application_id' => $app1->id, 'gateway' => 'bkash', 'status' => 'executed', 'amount' => 1000, 'currency' => 'BDT' ]);
        Payment::factory()->create([ 'application_id' => $app2->id, 'gateway' => 'dummy', 'status' => 'initiated', 'amount' => 500, 'currency' => 'BDT' ]);

    $resp = $this->get(route('admin.payments.index', ['gateway' => 'bkash']));
    $resp->assertStatus(200)->assertSee('bkash');
    // Ensure the dummy payment table cell isn't present (select options may contain 'Dummy')
    $resp->assertDontSee('<td class="px-3 py-2">dummy</td>', false);
    }

    /** @test */
    public function it_shows_payment_detail()
    {
        $app = Application::factory()->create(['total_fee' => 1200]);
        $payment = Payment::factory()->create([
            'application_id' => $app->id,
            'gateway' => 'bkash',
            'status' => 'executed',
            'amount' => 1200,
            'currency' => 'BDT',
            'transaction_id' => 'TRX123'
        ]);

        $resp = $this->get(route('admin.payments.show', $payment));
        $resp->assertStatus(200)->assertSee('TRX123')->assertSee((string)$payment->id);
    }
}
