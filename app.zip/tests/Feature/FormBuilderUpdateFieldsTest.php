<?php

namespace Tests\Feature;

use App\Models\Admin;
use App\Models\Form;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class FormBuilderUpdateFieldsTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        // Minimal admin user creation if factory exists, else inline create
        $admin = Admin::factory()->create();
        $this->be($admin, 'admin');
    }

    /** @test */
    public function it_updates_form_fields_via_builder_endpoint()
    {
        $form = Form::create([
            'name' => 'Test Form',
            'description' => 'Desc',
            'status' => 'active',
            'created_by' => auth('admin')->id(),
        ]);

        $payload = [
            'fields' => [
                'elements' => [
                    [
                        'id' => 'element_1',
                        'type' => 'text',
                        'label' => 'Your Name',
                        'fieldName' => 'your_name',
                        'required' => true,
                        'options' => []
                    ],
                    [
                        'id' => 'element_2',
                        'type' => 'radio',
                        'label' => 'Gender',
                        'fieldName' => 'gender',
                        'required' => false,
                        'options' => ['Male','Female']
                    ]
                ],
                'settings' => [
                    'appIdPrefix' => 'T-',
                    'idRange' => ['start' => 1, 'end' => 100],
                    'paymentRequired' => false,
                    'activeDate' => null
                ]
            ],
            'name' => 'Test Form Updated',
            'description' => 'New Desc'
        ];

        $response = $this->postJson(route('admin.forms.update-fields', $form), $payload);

        $response->assertStatus(200)->assertJson(['success' => true]);

        $this->assertDatabaseHas('forms', [
            'id' => $form->id,
            'name' => 'Test Form Updated'
        ]);

        $form->refresh();
        $this->assertIsArray($form->fields);
        $this->assertEquals('Your Name', $form->fields['elements'][0]['label']);
        $this->assertEquals('Gender', $form->fields['elements'][1]['label']);
    }
}
