<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\Admin;
use App\Models\Subject;

class SubjectRoutesTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_can_access_subjects_index_page()
    {
        // Create admin user
        $admin = Admin::factory()->create();
        $this->actingAs($admin, 'admin');

        // Visit subjects index page
        $response = $this->get(route('admin.subjects.index'));
        $response->assertStatus(200);
    }

    /** @test */
    public function it_can_access_subject_create_page()
    {
        // Create admin user
        $admin = Admin::factory()->create();
        $this->actingAs($admin, 'admin');

        // Visit subject create page
        $response = $this->get(route('admin.subjects.create'));
        $response->assertStatus(200);
    }

    /** @test */
    public function it_can_access_subject_edit_page()
    {
        // Create admin user
        $admin = Admin::factory()->create();
        $this->actingAs($admin, 'admin');

        // Create subject
        $subject = Subject::factory()->create();

        // Visit subject edit page
        $response = $this->get(route('admin.subjects.edit', $subject));
        $response->assertStatus(200);
    }

    /** @test */
    public function it_returns_404_for_non_existent_subject()
    {
        // Create admin user
        $admin = Admin::factory()->create();
        $this->actingAs($admin, 'admin');

        // Try to access edit page for non-existent subject
        $response = $this->get(route('admin.subjects.edit', 999999));
        $response->assertStatus(404);
    }
}