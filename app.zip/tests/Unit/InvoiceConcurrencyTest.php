<?php

namespace Tests\Unit;

use App\Models\Application;
use App\Models\Payment;
use App\Services\PaymentService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Config;
use Tests\TestCase;

class InvoiceConcurrencyTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function multiple_success_mark_calls_generate_unique_invoices_and_public_codes()
    {
        Config::set('payment.enabled', true);
        $service = app(PaymentService::class);

        $apps = Application::factory()->count(10)->create([
            'payment_status' => 'pending_unpaid',
            'total_fee' => 100,
            'payment_due_at' => now()->addHour(),
        ]);

        $invoices = [];
        $publicCodes = [];

        foreach($apps as $app) {
            $payment = Payment::create([
                'application_id' => $app->id,
                'gateway' => 'dummy',
                'status' => 'initiated',
                'amount' => 100,
                'currency' => 'BDT'
            ]);
            // Simulate possible race by calling markSuccess twice quickly
            $service->markSuccess($payment);
            $service->markSuccess($payment); // idempotent second call
            $app->refresh();
            $invoices[] = $app->internal_invoice;
            $publicCodes[] = $app->public_application_code;
        }

        $this->assertCount(10, array_unique($invoices), 'Invoices must all be unique');
        $this->assertCount(10, array_unique($publicCodes), 'Public codes must all be unique');
    }
}
