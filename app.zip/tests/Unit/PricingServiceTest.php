<?php

namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\Subject;
use App\Services\PricingService;

class PricingServiceTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_calculates_total_and_breakdown()
    {
    Subject::factory()->create(['code' => 'QIR101', 'fee' => 500, 'is_active' => true]);
    Subject::factory()->create(['code' => 'MUS101', 'fee' => 500, 'is_active' => true]);
    Subject::factory()->create(['code' => 'ACT101', 'fee' => 700, 'is_active' => true]);

        $service = new PricingService();
        $result = $service->calculate(['QIR101','ACT101','ACT101']); // duplicate ACT101 ignored

        $this->assertEquals(1200.0, $result['total']);
    $this->assertEquals(500.0, $result['breakdown']['QIR101']['fee']);
    $this->assertEquals(700.0, $result['breakdown']['ACT101']['fee']);
    $this->assertArrayHasKey('name', $result['breakdown']['QIR101']);
    }

    /** @test */
    public function empty_input_returns_zero()
    {
        $service = new PricingService();
        $result = $service->calculate([]);
        $this->assertSame(0.0, $result['total']);
    $this->assertSame([], $result['breakdown']);
    }
}
