<?php

namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\Application;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class InvoiceSequenceTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_generates_sequential_invoices_per_day()
    {
        Config::set('payment.enabled', true);
        Carbon::setTestNow(Carbon::create(2025,10,9,10,0,0));

        $codes = [];
        for($i=0;$i<5;$i++) {
            // create application ready for pay now
            $app = Application::factory()->create([
                'total_fee' => 100,
                'payment_status' => 'pending_unpaid'
            ]);
            session(['recent_application_id' => $app->id, 'recent_fee_breakdown' => []]);
            $this->post(route('forms.payment.pay_now', $app))->assertRedirect();
            $app->refresh();
            $this->assertNotNull($app->internal_invoice);
            $codes[] = $app->internal_invoice;
        }

        // Assert uniqueness
        $this->assertCount(5, array_unique($codes));
        // Assert ordered suffix increments (may have gaps due to shared sequence with public codes)
        $suffixes = array_map(function($code){ return (int)substr($code, -4); }, $codes);
        // Check that suffixes are in ascending order (may not be consecutive due to shared sequence)
        $sortedSuffixes = $suffixes;
        sort($sortedSuffixes);
        $this->assertTrue($suffixes === array_unique($suffixes) && $suffixes === $sortedSuffixes, 'Suffixes should be in ascending order');
    }
}
