# সাইমুম শিল্পীগোষ্ঠী ওয়েবসাইট

এটি সাইমুম শিল্পীগোষ্ঠীর জন্য তৈরি একটি ওয়েবসাইট। এই ওয়েবসাইটটি Laravel PHP ফ্রেমওয়ার্ক ব্যবহার করে তৈরি করা হয়েছে।

## মেনু আইটেমসমূহ

- হোম
- আমাদের সম্পর্কে
- নোটিস
- আবেদন
- আবেদনের স্ট্যাটাস
- যোগাযোগ
- সাইন ইন

## ফিচারসমূহ

1. **আবেদন সিস্টেম**: নতুন সদস্যদের জন্য অনলাইন আবেদন ফরম
2. **আবেদন স্ট্যাটাস**: আবেদনকারীরা তাদের আবেদনের স্ট্যাটাস চেক করতে পারবে
3. **অ্যাডমিন প্যানেল**: অ্যাডমিনরা আবেদনসমূহ ম্যানেজ করতে পারবে
4. **নোটিস সেকশন**: গুরুত্বপূর্ণ নোটিসসমূহ প্রদর্শন
5. **বাংলা ভাষা সাপোর্ট**: পুরো ওয়েবসাইট বাংলায়

## ইনস্টলেশন

1. Clone the repository
2. Run `composer install`
3. Run `npm install` (if using frontend assets)
4. Copy `.env.example` to `.env` and configure database settings
5. Run `php artisan key:generate`
6. Run `php artisan migrate --seed`
7. Run `php artisan serve` to start the development server

## ডেভেলপমেন্ট সার্ভার

লারাভেল ডেভেলপমেন্ট সার্ভার শুরু করতে:
```bash
php artisan serve
```

## কনফিগারেশন

ওয়েবসাইটের কনফিগারেশন `config/saimum.php` ফাইলে রয়েছে।

## ডেটাবেস

- **মাইগ্রেশন**: `database/migrations/` ডিরেক্টরিতে
- **সিডার**: `database/seeders/` ডিরেক্টরিতে

## কন্ট্রোলার

- **পেজ কন্ট্রোলার**: `app/Http/Controllers/PageController.php`
- **আবেদন কন্ট্রোলার**: `app/Http/Controllers/ApplicationController.php`
- **অ্যাডমিন কন্ট্রোলার**: `app/Http/Controllers/Admin/` ডিরেক্টরিতে

## ভিউস

- **পাবলিক ভিউস**: `resources/views/` ডিরেক্টরিতে
- **অ্যাডমিন ভিউস**: `resources/views/admin/` ডিরেক্টরিতে

## রাউটসমূহ

রাউটসমূহ `routes/web.php` ফাইলে রয়েছে।

## লাইসেন্স

এই প্রজেক্টটি একটি কাস্টম লাইসেন্সের অধীনে লাইসেন্সকৃত।